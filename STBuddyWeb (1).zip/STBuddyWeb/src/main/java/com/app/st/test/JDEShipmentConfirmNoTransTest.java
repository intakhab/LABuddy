package com.app.st.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.ResponseDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDEShipmentConfirmNoTransTest {


	private Logger logger = LogManager.getLogger(JDEShipmentConfirmNoTransTest.class);

	private WebDriver driver;

	
	@Autowired
	private Environment env;
	
	
	@Autowired
	private CommonTestUtilService commonTestUtilService;

	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto doShipmentConfir(WebDriver driver,ResponseDto responseDto) {

		try {
			AppUtil.pauseInSecond(1);
			logger.info("Shipment Confirm no transaction running");
			String location="";
			String lot="";
			logger.info("Type::"+responseDto.getTypeTest());
			if(responseDto.getTypeTest().equals("SI")) {
				 location=responseDto.getSiExcelColumnNameDto().getLocation();
				 lot=responseDto.getSiExcelColumnNameDto().getLot();
			}else {
				 location=responseDto.getStExcelColumnNameDto().getLocation();
				 lot=responseDto.getStExcelColumnNameDto().getLot();
			}
			logger.info("Location ::"+location);
			logger.info("Lot:: "+lot);
			AppUtil.pauseInSecond(1);
			driver.switchTo().parentFrame();
			commonTestUtilService.commonMenu(driver, env);
			driver.findElement(By.xpath(env.getProperty("so.warehouse.key"))).click();
			AppUtil.pauseInSecond(1);
            driver.findElement(By.xpath(env.getProperty("so.warehouse.outbound.key"))).click();
            AppUtil.pauseInSecond(1);
            driver.findElement(By.xpath(env.getProperty("so.shimpent.confirm.key"))).click();
            AppUtil.pauseInSecond(1);
            driver.findElement(By.xpath(env.getProperty("so.shipment.no.confirm.key"))).click(); 
            // Page  Confirm Shipment - No Transportation - Work with Shipment Confirmation 
            driver.switchTo().frame(env.getProperty("so.create.iframe1.key"));
            AppUtil.pauseInSecond(1);
            driver.findElement(By.xpath(env.getProperty("so.order.box.key"))).clear();
            AppUtil.pauseInSecond(1);
            logger.info("Putting order no: "+responseDto.getOrderNo());
            
           // driver.findElement(By.xpath(env.getProperty("so.order.box.key"))).sendKeys(responseDto.getOrderNo());
            
            commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.order.box.key"), responseDto.getOrderNo());
            AppUtil.pauseInSecond(1);
            logger.info(" Type : " + responseDto.getTypeTest());
    		
			/*if(commonTestUtilService.checkResultAvailableOrNot(driver, 
					env.getProperty("so.create.save.btn.link.key"))) {
				commonTestUtilService.clearTextAndsendKeys(driver, 
						env.getProperty("so.create.save.btn.link.key"), responseDto.getTypeTest());
			}*/
			//*[@id="C0_20"]
			 AppUtil.pauseInSecond(1);
            driver.findElement(By.xpath(env.getProperty("so.create.order.lookup.order.key"))).click();
            AppUtil.pauseInSecond(1);
            List<WebElement> checkBoxList = driver
                             .findElements(By.xpath("//*[@id='jdeGridData0_1.0']/tbody/tr"));
            
            for (int i = 0; i < checkBoxList.size(); i++) {
                String path="//*[@id='G0_1_R"+i+"']/td[1]/div/input";
                driver.findElement(By.xpath(path)).click();
                AppUtil.pauseInSecond(1);
                driver.findElement(By.xpath(env.getProperty("so.create.order.lookup.order.key"))).click();
                AppUtil.pauseInSecond(1);
                driver.findElement(By.xpath(path)).click();
                AppUtil.pauseInSecond(1);
                driver.findElement(By.xpath(path)).sendKeys(lot);
                AppUtil.pauseInSecond(1);
                driver.findElement(By.xpath(path)).sendKeys(location);
                AppUtil.pauseInSecond(1);
         }
			
            logger.info("Shipment Confirm no transaction finished");  
			
		} catch (NoSuchElementException e) {
			logger.error("******************************* JDEShipment Confirmation No Trans Reports  Failed *********************************");
			logger.error("Error {} ", e.getMessage());
			responseDto.setReasonFail(e.getMessage());

		} finally {
			quit();
		}
		return responseDto;

	}

	public void quit() {
		driver.close();
		driver.quit();
	}

	



}
