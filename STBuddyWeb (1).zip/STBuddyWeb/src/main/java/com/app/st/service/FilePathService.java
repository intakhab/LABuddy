package com.app.st.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
/***
 * 
 * @author ISIDDIQUI
 *
 */
@Service
public class FilePathService {
	@Autowired
	Environment env;

	/**
	 * 
	 * @return {@link InputStream}
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public InputStream loadFile() throws URISyntaxException, IOException {
		return Files.newInputStream(Paths.get(env.getProperty("xsl_file_path")), StandardOpenOption.READ);
	}
	
	
	public InputStream loadFile(String fileName) throws URISyntaxException, IOException {
		return Files.newInputStream(Paths.get(fileName), StandardOpenOption.READ);
	}

	/***
	 * 
	 * @return {@link Path}
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public  Path getXSLPath() throws URISyntaxException, IOException {
		return Paths.get(env.getProperty("xsl_file_path"));
	}

	/**
	 * 
	 * @return  {@link Path}
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public  Path getExtendConfigPath() throws URISyntaxException, IOException {
		return Paths.get(FilePathService.class.getClassLoader().getResource(env.getProperty("report_config_path")).toURI());
	}
}