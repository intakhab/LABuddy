package com.app.st.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SFExcelColumnNameDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDESFOrderTest {

	private Logger logger = LogManager.getLogger(JDESFOrderTest.class);

	WebDriver driver;

	/*@Autowired
	private JDESFExcelReaderService excelReaderService;*/
	SFExcelColumnNameDto sfExcelDto;
	@Autowired
	Environment env;

	@Autowired
	JDEStatusCheckTest statusReports;

	@Autowired
	JDEOMRReportsTest omrReportsTest;
	@Autowired
	JDELoginTest commonLoginTest;
	
	@Autowired
	CommonTestUtilService commonTestUtilService;
	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto createSF(ResponseDto responseDto) {

		try {

			logger.info("******************************* Login SF Starting*********************************");
			//sfExcelDto = excelReaderService.getExcelData(responseDto.getFileName()).get(0);
			sfExcelDto = responseDto.getSfExcelColumnNameDto();
			
			driver = commonLoginTest.login();

			logger.info("******************************* Create SF Starting*********************************");
			AppUtil.pauseInSecond(2);

			commonTestUtilService.commonMenu(driver,env);

			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("sf.create.url.link.1.key"))).click();

			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("sf.create.url.link.2.key"))).click();
			AppUtil.pauseInSecond(2);
			// Switch to
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			AppUtil.pauseInSecond(10);

			driver.findElement(By.xpath(env.getProperty("so.create.add.link.key"))).click();

			AppUtil.pauseInSecond(2);

			logger.info("Ship To:" + sfExcelDto.getShipTo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sf.create.ship.to.key"), sfExcelDto.getShipTo());

			AppUtil.pauseInSecond(2);
			logger.info("Plant/Branch Id : " + sfExcelDto.getPlantId());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sf.create.branch.plantid.key"),
					sfExcelDto.getPlantId());

			AppUtil.pauseInSecond(2);
			logger.info("Cust PO : " + sfExcelDto.getCustPo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sf.create.cust.po.key"), sfExcelDto.getCustPo());

			AppUtil.pauseInSecond(2);

			List<String> orderQntyList = sfExcelDto.getOrderQntyList();
			List<String> itemNoList = sfExcelDto.getItemList();

			logger.info("Order Qnty size : " + orderQntyList.size());
			logger.info("Item No size : " + itemNoList.size());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("scroll(0,500);");
			if (orderQntyList.size() == itemNoList.size()) {

				for (int i = 0; i < orderQntyList.size(); i++) {

					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sf.create.qnty.key"),
							sfExcelDto.getOrderQntyList().get(i));

					AppUtil.pauseInSecond(2);

					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sf.create.uom.key"),
							sfExcelDto.getUomList().get(i));

					AppUtil.pauseInSecond(2);
					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sf.create.item.key"),
							sfExcelDto.getItemList().get(i));

					AppUtil.pauseInSecond(2);
					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sf.create.cust.item.key"),
							sfExcelDto.getCustItemList().get(i));

					AppUtil.pauseInSecond(2);
					driver.findElement(By.xpath(env.getProperty("sf.create.cust.item.key"))).sendKeys(Keys.ENTER);
					AppUtil.pauseInSecond(2);
				}
			}

			js.executeScript("scroll(0,-450);");
			AppUtil.pauseInSecond(2);

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("sf.create.click.btn.key"))) {
				driver.findElement(By.xpath(env.getProperty("sf.create.click.btn.key"))).click();
				AppUtil.pauseInSecond(2);
			}

			AppUtil.pauseInSecond(2);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("sf.create.click.btn.key"))) {
				driver.findElement(By.xpath(env.getProperty("sf.create.click.btn.key"))).click();
			}

			AppUtil.pauseInSecond(2);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("sf.create.click.btn.key"))) {
				driver.findElement(By.xpath(env.getProperty("sf.create.click.btn.key"))).click();
			}

			AppUtil.pauseInSecond(2);
			String sfOrder = "";

			AppUtil.pauseInSecond(2);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("sf.create.order2.no.key"))) {
				sfOrder = driver.findElement(By.xpath(env.getProperty("sf.create.order2.no.key")))
						.getAttribute("value");
			}

			AppUtil.pauseInSecond(2);
			logger.info("SF Order no: " + sfOrder);
			if (sfOrder != null && !sfOrder.isEmpty()) {
				responseDto.setOrderNo(sfOrder);
				responseDto.setRestorePoint("SF Created");
				logger.info("******************************* Running OMR for SF *********************************");

				omrReportsTest.runOmr(sfOrder, driver, env, sfExcelDto.getOmrBatchVal(),sfExcelDto.getOmrVersionVal(),"notomr");
				AppUtil.pauseInSecond(2);
				responseDto.setRestorePoint("SF Batch-1");
				responseDto.setRunStatus(true);
				logger.info("******************************* Create SF completed *********************************");
				AppUtil.pauseInSecond(2);
				logger.info("******************************* Running Reports for SF ******************************");
				String status = statusReports.commonReports(driver, env, sfOrder, "SF");
				responseDto.setCurrentStatus(status);
				responseDto.setRestorePoint("SF Completed");
			} else {
				responseDto.setRunStatus(false);
				logger.info(
						"*******************************  SF Creation Failed, Please see the input values *********************************");
			}
			AppUtil.pauseInSecond(5);
			
		} catch (NoSuchElementException e) {
			responseDto.setRunStatus(false);
			responseDto.setReasonFail(e.getMessage());
			logger.error("******************************* SF Creation Failed *********************************");
			logger.error("Error {} ", e.getMessage());

		} finally {
			commonTestUtilService.quit(driver);
		}
		return responseDto;

	}

	


}
