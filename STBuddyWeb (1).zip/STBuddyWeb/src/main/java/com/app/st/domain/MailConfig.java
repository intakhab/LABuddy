package com.app.st.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * @author intakhabalam.s@hcl.com Mail Confi
 */
@Entity
@Table(name = "MAIL_CONFIG")

public class MailConfig {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private long id;
	@Column(name = "HOST")
	private String host = "";
	@Column(name = "PORT")
	private int port;
	@Column(name = "USER_NAME")
	private String username = "";
	@Column(name = "PASSWORD")
	private String password = "";
	@Column(name = "DEBUG_MAIL")
	private boolean debugMail = false;

	//
	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isDebugMail() {
		return debugMail;
	}

	public void setDebugMail(boolean debugMail) {
		this.debugMail = debugMail;
	}
}
