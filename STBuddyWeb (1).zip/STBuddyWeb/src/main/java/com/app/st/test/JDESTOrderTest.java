package com.app.st.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.STExcelColumnNameDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDESTOrderTest {

	private Logger logger = LogManager.getLogger(JDESTOrderTest.class);

	@Autowired
	private CommonTestUtilService commonTestUtilService;
	
	private WebDriver driver;
	
	
	private STExcelColumnNameDto stExcelDto;
	
	@Autowired
	private Environment env;
	
	@Autowired
	private JDEStatusCheckTest commonReportTest;
	
	@Autowired
	private JDEOMRReportsTest omrReportsTest;
	
	@Autowired
	private JDELoginTest commonLoginTest;
	
	@Autowired
	private JDAAutoPlanOptTest autoPlan;
	
	@Autowired
	private JDESpeedStatusTest speedStatusTest;
	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto createST(ResponseDto responseDto) {

		try {

			logger.info("******************************* Login ST Starting*********************************");
			/*stExcelDto = excelReaderService.getExcelData(responseDto.getFileName()).get(0);*/
			 stExcelDto = responseDto.getStExcelColumnNameDto();
			 driver = commonLoginTest.login();
			logger.info("******************************* Create ST Starting*********************************");
			AppUtil.pauseInSecond(2);

			commonTestUtilService.commonMenu(driver,env );

			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("st.create.url.link.1.key"))).click();

			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("st.create.url.link.2.key"))).click();
			AppUtil.pauseInSecond(5);

			// Switch to
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			AppUtil.pauseInSecond(10);

			driver.findElement(By.xpath(env.getProperty("so.create.add.link.key"))).click();

			AppUtil.pauseInSecond(2);

			logger.info("From Branch Plant value : " + stExcelDto.getFromBranchPlantNo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("st.create.from.branch.plant.key"),
					stExcelDto.getFromBranchPlantNo());

			AppUtil.pauseInSecond(2);

			logger.info("TO Branch Plant value : " + stExcelDto.getToBranchPlantNo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("st.create.to.branch.plant.key"),
					stExcelDto.getToBranchPlantNo());

			AppUtil.pauseInSecond(2);

			List<String> orderQntyList = stExcelDto.getOrderQnty();
			List<String> itemNoList = stExcelDto.getItemNo();
			List<String> custItemNoList = stExcelDto.getCustItemNo();

			logger.info("Order Qnty size : " + stExcelDto.getOrderQnty().size());
			logger.info("Item No size : " + stExcelDto.getItemNo().size());
			logger.info("Cust Item size : " + stExcelDto.getCustItemNo().size());
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("scroll(0,400);");

			if (orderQntyList.size() == itemNoList.size() && orderQntyList.size() == custItemNoList.size()) {
				
				for (int i = 0; i < orderQntyList.size(); i++) {

					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("st.create.qnty1.key"),
							stExcelDto.getOrderQnty().get(i));
					AppUtil.pauseInSecond(2);

					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("st.create.item.key"),
							stExcelDto.getItemNo().get(i));
					AppUtil.pauseInSecond(2);

					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("st.create.cust.item.key"),
							stExcelDto.getCustItemNo().get(i));

					AppUtil.pauseInSecond(2);

					driver.findElement(By.xpath(env.getProperty("st.create.cust.item.key"))).sendKeys(Keys.ENTER);
					AppUtil.pauseInSecond(2);
				}
			}
			js.executeScript("scroll(0,-500);");
			AppUtil.pauseInSecond(2);

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
				AppUtil.pauseInSecond(2);
			}
			AppUtil.pauseInSecond(5);

			commonTestUtilService.checkError(driver, env); // Checking error

			AppUtil.pauseInSecond(5);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
				AppUtil.pauseInSecond(2);

			}
			AppUtil.pauseInSecond(5);

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("st.create.click.btn1.key"))) {
				driver.findElement(By.xpath(env.getProperty("st.create.click.btn1.key"))).click();
				AppUtil.pauseInSecond(2);

			}

			AppUtil.pauseInSecond(5);
			String stOrdeNo = "";

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("st.create.si.order.no.key"))) {
				stOrdeNo = driver.findElement(By.xpath(env.getProperty("st.create.si.order.no.key")))
						.getAttribute("value").toString();
			}

			AppUtil.pauseInSecond(2);

			logger.info("New ST Order Number is: " + stOrdeNo);
			//responseDto.setStOrdeNo(stOrdeNo);

			AppUtil.pauseInSecond(2);

			String otOrderNo = "";
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("st.create.oi.order.no.key"))) {
				otOrderNo = driver.findElement(By.xpath(env.getProperty("st.create.oi.order.no.key")))
						.getAttribute("value").toString();
			}
			AppUtil.pauseInSecond(2);

			logger.info("New OT Order Number is: " + otOrderNo);
			//responseDto.setOtOrderNo(otOrderNo);
			AppUtil.pauseInSecond(5);

			if (!stOrdeNo.isEmpty() && !otOrderNo.isEmpty()) {
				logger.info("******************************* Create ST completed *********************************");
				responseDto.setRunStatus(true);

				logger.info("******************************* Running OMR for ST *********************************");
				responseDto.setRestorePoint("ST Created");
				omrReportsTest.runOmr(stOrdeNo, driver, env, stExcelDto.getOmrBatchVal(),
						stExcelDto.getOmrVersionVal(),"notomr");
				AppUtil.pauseInSecond(10);
				responseDto.setRestorePoint("ST OMR");
				logger.info("*******************************Checking Status for ST *********************************");

				String status = commonReportTest.commonReports(driver, env, stOrdeNo,"ST");
				responseDto.setOrderNo(stOrdeNo);
				responseDto.setOrderNo1(otOrderNo);
				responseDto.setCurrentStatus(status);
				responseDto.setTmsOrder("ST"+stOrdeNo);
				responseDto.setRestorePoint("JDE Completed");
			} else {
				logger.info(
						"******************************* ST Test cases failed due to incorrect input *********************************");
				responseDto.setRunStatus(false);
			}

		} catch (NoSuchElementException e) {
			responseDto.setRunStatus(false);
			responseDto.setReasonFail(e.getMessage());
			logger.error("******************************* ST Creation Failed *********************************");
			logger.error("Error {} ", e.getMessage());

		} finally {
			commonTestUtilService.quit(driver);
			if ("JDE-JDA".equalsIgnoreCase(responseDto.getUntilId())) {
				// After quitting JDE, TMS Optimization will run
				logger.info("STBuddy will run till JDE-JDA {}");
				if (responseDto.getCurrentStatus().equals("530")) {
					autoPlan.autoPlanOpt(responseDto);
				} else {
					logger.info("Status not reached to 530 so autoPlanOpt wont run {}");
				}
				if ("535".equals(responseDto.getCurrentStatus())) {
					AppUtil.pauseInSecond(5);
					speedStatusTest.doSpeedStatus(responseDto);
					logger.info("Status reached to 535 so running speed status");
				} else {
					logger.info("Status not reached to 535 so doSpeedStatus wont run {}");
				}
			}else {
				logger.info("STBuddy will run till JDE {} ");
			}
		}
		return responseDto;

	}

	

	

}
