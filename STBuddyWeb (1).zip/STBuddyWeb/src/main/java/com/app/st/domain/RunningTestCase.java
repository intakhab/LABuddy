package com.app.st.domain;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@javax.persistence.Entity
@Table(name = "RUNNING_TEST_CASE")
public class RunningTestCase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "ORDER_NUMBER")
	private String orderNumber = "";
	
	@Column(name = "ORDER_NUMBER1")
	private String orderNumber1 = "";
	
	
	@Column(name = "RUN_STATUS", length = 10)
	private String runStatus = "false";
	
	@Column(name = "LAST_RUN_TIME", length = 20)
	private String lastRunningTime = "";
	
	@Column(name = "STATUS", length = 10)
	private String stauts = "false";
	
	@Column(name = "RUN_COUNT", length = 5)
	private String runCount = "0";
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "REG_TEST_ID", nullable = false)
	private RegisterTestCase registerTestCase;
	
	@Column(name = "AUTO_START", length = 10)
	private String autoStart = "false";
	
	@Column(name = "START", length = 10)
	private String start = "false";
	
	@Column(name = "REASON_FAIL", length = 255)
	private String reasonFail = "";
	
	@Column(name = "ENV_TYPE", length = 5)
	private String envType="DEV";
	
	@Column(name="RESTORE_POINT")
	private String restorePoint="";
	
	@Column(name="SUB_TEST_NAME")
	private String subTestName="";
	
	@Column(name="UNTIL_TEST_RUN")
	private String untilTestRunId="";
	
	
	public String getUntilTestRunId() {
		return untilTestRunId;
	}

	public void setUntilTestRunId(String untilTestRunId) {
		this.untilTestRunId = untilTestRunId;
	}

	public String getReasonFail() {
		return reasonFail;
	}

	public void setReasonFail(String reasonFail) {
		this.reasonFail = reasonFail;
	}


	public String getRestorePoint() {
		return restorePoint;
	}

	public void setRestorePoint(String restorePoint) {
		this.restorePoint = restorePoint;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getAutoStart() {
		return autoStart;
	}

	public void setAutoStart(String autoStart) {
		this.autoStart = autoStart;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getLastRunningTime() {
		return lastRunningTime;
	}

	public void setLastRunningTime(String lastRunningTime) {
		this.lastRunningTime = lastRunningTime;
	}

	public String getStauts() {
		return stauts;
	}

	public void setStauts(String stauts) {
		this.stauts = stauts;
	}

	public RegisterTestCase getRegisterTestCase() {
		return registerTestCase;
	}

	public void setRegisterTestCase(RegisterTestCase registerTestCase) {
		this.registerTestCase = registerTestCase;
	}

	public String getRunStatus() {
		return runStatus;
	}

	public void setRunStatus(String runStatus) {
		this.runStatus = runStatus;
	}

	public String getOrderNumber1() {
		return orderNumber1;
	}

	public void setOrderNumber1(String orderNumber1) {
		this.orderNumber1 = orderNumber1;
	}

	public String getRunCount() {
		return runCount;
	}

	public void setRunCount(String runCount) {
		this.runCount = runCount;
	}

	public String getEnvType() {
		return envType;
	}

	public void setEnvType(String envType) {
		this.envType = envType;
	}

	public String getSubTestName() {
		return subTestName;
	}

	public void setSubTestName(String subTestName) {
		this.subTestName = subTestName;
	}
}
