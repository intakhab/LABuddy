package com.app.st.common;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/***
 * 
 * @author intakhabalam.s@hcl.com
 */
public class AppUtil {

	static DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
	public static String EMPTY_STR="";

	/***
	 * @param listOfItems {@link List}
	 * @param separator {@link String}
	 * @return {@link String}
	 */
	public static String concatenate(List<String> listOfItems, String separator) {
		StringBuilder sb = new StringBuilder();
		Iterator<String> stit = listOfItems.iterator();

		while (stit.hasNext()) {
			sb.append(stit.next());
			if (stit.hasNext()) {
				sb.append(separator);
			}
		}

		return sb.toString();
	}
	
	
	/***
	 * Will print time
	 * @param fileTime {@link String}
	 * @return time {@link String}
	 */
	public String printFileTime(FileTime fileTime) {
		try {
			return dateFormat.format(fileTime.toMillis());
		} catch (Exception e) {
			return "" + System.currentTimeMillis();
		}
	}
	
	public static  String currentTime() {
		return dateFormat.format(new Date());
	}
	
	
	/**
	 * Checks if is collection empty.
	 * @param collection {@link Collection}
	 * @return {@link Boolean}
	 */
	private static boolean isCollectionEmpty(Collection<?> collection) {
		if (collection == null || collection.isEmpty()) {
			return true;
		}
		return false;
	}
	
	/**
	 * Checks if is object empty.
	 * @param object {@link Object}
	 * @return {@link Boolean}
	 */
	public static boolean isObjectEmpty(Object object) {
		if(object == null) return true;
		else if(object instanceof String) {
			if (((String)object).trim().length() == 0) {
				return true;
			}
		} else if(object instanceof Collection) {
			return isCollectionEmpty((Collection<?>)object);
		}
		return false;
	}
	
	/***
	 * @param fromDate
	 * @return {@link Long}
	 */
	public static long getDateDiff(String fromDate) {
		try {
	       LocalDate dateFrom = LocalDate.parse(fromDate,formatter);
		   LocalDate dateTo = LocalDate.now();
		   // Period intervalPeriod = Period.between(dateFrom, dateTo);
		    long intervalDays = ChronoUnit.DAYS.between(dateFrom, dateTo);
		    return intervalDays;
		    
		}catch (Exception e) {
			return 0;
		}
	}
	
	/***
	 * 
	 * @param seconds
	 */
	public static void pauseInSecond(int seconds) {
		try {
			Thread.sleep(1000 * seconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public static void pauseInMins(int seconds) {
		try {
			Thread.sleep(1000 * seconds * 60);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	
	/***
	 * 
	 * @param inputStream
	 * @param excelFilePath
	 * @return
	 * @throws IOException
	 */
	public static Workbook getWorkbook(InputStream inputStream, String excelFilePath) throws IOException {
		Workbook workbook = null;
		if (excelFilePath.endsWith("xlsx")) {
			workbook = new XSSFWorkbook(inputStream);
		} else if (excelFilePath.endsWith("xls")) {
			workbook = new HSSFWorkbook(inputStream);
		} else {
			throw new IllegalArgumentException("The specified file is not Excel file");
		}
		return workbook;
	}

	/**
	 * 
	 * @param cell
	 * @return
	 */
	public static Object getCellValue(Cell cell) {
		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue().trim();

		case BOOLEAN:
			return cell.getBooleanCellValue();

		case NUMERIC:
			return cell.getNumericCellValue();
		default:
			break;
		}
		return "";

	}
	
}
