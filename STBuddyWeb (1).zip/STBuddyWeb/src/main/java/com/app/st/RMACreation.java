package com.app.st;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RMACreation {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		Thread.sleep(5000);
		driver.navigate().to("http://jdedv92.cbrands.com/jde/E1Menu.maf");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='User']")).sendKeys("ss1");
		driver.findElement(By.xpath("//*[@id='Password']")).sendKeys("Lockit4Me!");
		Thread.sleep(3000);
		driver.findElement(By.xpath(
				"/html/body/div[1]/table/tbody/tr[2]/td/form/table/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[7]/td/input"))
				.click();
		driver.findElement(By.xpath("//*[@id='drop_mainmenu']")).click();
		driver.findElement(By.xpath("//span[text()='CBI Main Menu']")).click();
		driver.findElement(By.xpath("//span[text()='Order to Cash']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[text()='Sales Order Management']")).click();
		driver.findElement(By.xpath("//span[text()='Sales Order Management']")).click();
		driver.findElement(By.xpath("//span[text()='Credit & Return Processing']")).click();
		driver.findElement(By.xpath("//span[text()='JDE/WMS - RMA Processing']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[text()='RMA Type 1B - International - Order Co 301']")).click();
		driver.switchTo().frame("e1menuAppIframe");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='hc_Add']")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id='C0_133']")).clear();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='C0_133']")).sendKeys("301459");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='C0_47']")).sendKeys("2224429");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='C0_256']")).sendKeys("2224429");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='C0_270']")).sendKeys("XCXC1232");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='G0_1_R0']/td[3]/div/input")).sendKeys("CRR");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='G0_1_R0']/td[4]/div/input")).sendKeys("80019712");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='G0_1_R0']/td[6]/div/input")).sendKeys("12");
		Thread.sleep(4000);
		WebElement element = driver.findElement(By.id("jdeGridBack0_1")); // new
		// Actions(driver).moveToElement(element).click().perform();

		// ((JavascriptExecutor)
		// driver).executeScript("document.getElementById('text-8').scrollIntoView(true);");
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft += 5455", element);
		Thread.sleep(5000);
		if (checkResultAvailableOrNot(driver, "//*[@id='G0_1_R0']/td[9]/div/input")) {
			driver.findElement(By.xpath("//*[@id='G0_1_R0']/td[9]/div/input")).sendKeys("RMA");
		}
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='hc_OK']")).click();
		Thread.sleep(4000);
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//*[@id='drop_mainmenu']")).click();
		driver.findElement(By.xpath("//span[text()='CBI Main Menu']")).click();
		driver.findElement(By.xpath("//span[text()='Order to Cash']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[text()='Sales Order Management']")).click();
		driver.findElement(By.xpath("//span[text()='Sales Order Management']")).click();
		driver.findElement(By.xpath("//span[text()='Credit & Return Processing']")).click();
		driver.findElement(By.xpath("//span[text()='JDE/WMS - RMA Processing']")).click();

		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[text()='Sync RMA CO and OM']")).click();
		Thread.sleep(4000);
		driver.switchTo().frame("e1menuAppIframe");
		
		driver.findElement(By.xpath("//*[@id='C0_23']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc0']")).click();// *[@id="hc0"]
		Thread.sleep(2000);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='RightOperand3']")).sendKeys("Lit");// *[@id="e1ExternalAppIframe"]//*[@id="RightOperand3"]
		Thread.sleep(2000);

		// driver.findElement(By.xpath("//*[text()='Literal']")).click();
		// Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='LITtf']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='LITtf']")).sendKeys("11012312");// CO Order number
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_OK']")).click();
		Thread.sleep(2000);
		Thread.sleep(4000);
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//*[@id='drop_mainmenu']")).click();
		driver.findElement(By.xpath("//span[text()='CBI Main Menu']")).click();
		driver.findElement(By.xpath("//span[text()='Order to Cash']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[text()='Sales Order Management']")).click();
		driver.findElement(By.xpath("//span[text()='Sales Order Management']")).click();
		driver.findElement(By.xpath("//span[text()='Credit & Return Processing']")).click();
		driver.findElement(By.xpath("//span[text()='JDE/WMS - RMA Processing']")).click();

		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[text()='Proof Order Ackn (no default printer)']")).click();
		driver.switchTo().frame("e1menuAppIframe");
		driver.findElement(By.xpath("//*[@id='C0_23']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc0']")).click();// *[@id="hc0"]
		Thread.sleep(2000);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='RightOperand3']")).sendKeys("Lit");// *[@id="e1ExternalAppIframe"]//*[@id="RightOperand3"]
		Thread.sleep(2000);

		// driver.findElement(By.xpath("//*[text()='Literal']")).click();
		// Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='LITtf']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='LITtf']")).sendKeys("11012312");// CO Order Number
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_OK']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_OK']")).click();
		Thread.sleep(2000);
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//*[@id='drop_mainmenu']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='TE_FAST_PATH_BOX']")).sendKeys("BV");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='fastPathButton']")).click();
		Thread.sleep(2000);
		driver.switchTo().frame("e1menuAppIframe");
		driver.findElement(By.xpath("//*[@id='C0_11']")).sendKeys("R59X43500");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Find']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='qbeRow0_1']/td[2]/div/nobr/input")).sendKeys("CBI000015");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='hc_Find']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='G0_1_R0']/td[1]/div/input")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='C0_23']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc0']")).click();// *[@id="hc0"]
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='RightOperand3']")).sendKeys("Lit");// *[@id="e1ExternalAppIframe"]//*[@id="RightOperand3"]
		Thread.sleep(2000);

		// driver.findElement(By.xpath("//*[text()='Literal']")).click();
		// Thread.sleep(4000);
		driver.findElement(By.xpath("//*[@id='LITtf']")).clear();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='LITtf']")).sendKeys("11012312");// OM Order Number
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_OK']")).click();
		Thread.sleep(2000);// *[@id="hc_Select"]
		driver.switchTo().parentFrame();
		driver.findElement(By.xpath("//*[@id='drop_mainmenu']")).click();
		driver.findElement(By.xpath("//span[text()='CBI Main Menu']")).click();
		driver.findElement(By.xpath("//span[text()='Order to Cash']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[text()='Sales Order Management']")).click();
		driver.findElement(By.xpath("//span[text()='Sales Order Management']")).click();
		driver.findElement(By.xpath("//span[text()='Credit & Return Processing']")).click();
		driver.findElement(By.xpath("//span[text()='JDE/WMS - RMA Processing']")).click();

		Thread.sleep(4000);
		driver.findElement(By.xpath("//*[text()='Update F4301Z1 to Transmit Order to WMS/TMS']")).click();
		Thread.sleep(8000);
		driver.switchTo().frame("e1menuAppIframe");
		driver.findElement(By.xpath("//*[@id='C0_23']")).click();
		Thread.sleep(2000); // *[@id="C0_23"]
		driver.findElement(By.xpath("//*[@id='hc0']")).click();// *[@id="hc0"]
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_Select']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='hc_OK']")).click();
		Thread.sleep(2000);
	}

	public static boolean checkResultAvailableOrNot(WebDriver driver, String key) {
		// driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		boolean checkresultGrid;
		try {
			WebElement tf = driver.findElement(By.xpath(key));
			tf.isDisplayed();
			checkresultGrid = true;
		} catch (NoSuchElementException e) {
			checkresultGrid = false;
		} finally {
			// driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		}
		return checkresultGrid;
	}
}
