package com.app.st.service;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.EmailTemplate;
import com.app.st.dto.MailDto;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SOExcelColumnNameDto;
import com.mchange.v2.cfg.PropertiesConfig;
/***
 * Common Mail Services for watchdog  
 * @author intakhabalam.s@hcl.com
 * Provide the supports of mail
 * @see Service 
 * @see Environment
 * @see PropertiesConfig {@link PropertiesConfig}
 * @see EmailService {@link EmailService}
 */
@Service
public class PrepMailService{

	
	private final Logger logger = LogManager.getLogger(PrepMailService.class);
	@Autowired
	Environment env;
	
	@Autowired
	EmailService emailService;
	/**
	 * @param mailDto {@link MailDto}
	 * @throws Exception {@link Exception}
	 */
	public void sendEmailTemplate(MailDto mailDto) throws Exception {

		EmailTemplate template = new EmailTemplate(env.getProperty("email.template"));

		Map<String, String> replacements = new HashMap<String, String>();
		replacements.put("body", mailDto.getMessage());
		String tdy=String.valueOf(new Date());
		replacements.put("today", tdy);
		String message = template.getTemplate(replacements);
		//MailDto mailDto = new MailDto(from, to, subject, message,fileURL);
		mailDto.setMessage(message);
		mailDto.setHtml(true);
		emailService.send(mailDto);
		logger.info("Mail Sent Succesfully...");
	}
	
	
	/***
	 * This method will prepare the APIS mail
	 * @param apiDtoList {@link List}
	 */
	public void prepareAndSendAPIsMails(ResponseDto rdto,MailDto mailDto) {
		StringBuilder sb = new StringBuilder(AppUtil.EMPTY_STR);
		
		sb.append(
				"<table border='1' cellpadding='10' style='border: 1px solid #000080;' width='100%'><tr bgcolor='#A9A9A9'>"
				+ "<td> TEST NAME </td><td> ORDER_NO </td> <td> STATUS </td></tr>");
		//for(ResponseDto rdto:apiDtoList) {
			String toMailContent = "<tr><td>" + rdto.getTypeTest() + "</td><td>" + rdto.getOrderNo() + "</td><td>"+rdto.getCurrentStatus()+"</td></tr>";
			sb.append(toMailContent);
		//}
		
		
		sb.append("</table>");
		sb.append("<p></p>");
		sb.append("<p>Above SO order generated with below values</p>");
		sb.append(
				"<table border='1' cellpadding='10' style='border: 1px solid #000080;' width='100%'><tr bgcolor='#A9A9A9'>"
				+ "<td> SHIP_TO</td><td> CUSTOMER_PO </td> <td> BRANCH_PLANT </td><td>ORDER_QTY</td><td>ITEM_NO</td></tr>");
		
		//for(ResponseDto rdto:apiDtoList) {
		
			SOExcelColumnNameDto soDto=rdto.getSoExcelColumnNameDto();
			StringBuilder sbQnty=new StringBuilder("<ol>");
			for(int i=0;i<soDto.getOrderQty().size();i++) {
				sbQnty.append("<li>").append(soDto.getOrderQty().get(i)).append("</li>");
			}
			sbQnty.append("</ol>");
			//
			StringBuilder sbItem=new StringBuilder("<ol>");
			for(int i=0;i<soDto.getItemNumber().size();i++) {
				sbItem.append("<li>").append(soDto.getItemNumber().get(i)).append("</li>");
			}
			sbItem.append("</ol>");
			
			String toMailContent2 = "<tr>"
										+ "<td>" + soDto.getShipValue() + "</td>"
										+ "<td>" + soDto.getCustomerPoValue() + "</td>"
										+ "<td>" + soDto.getBranchId() + "</td>"
										+ "<td>" + sbQnty.toString()  +"</td>"
										+" <td>" + sbItem.toString()  +"</td>"
										 
								 + "</tr>";

			sb.append(toMailContent2);
			
			sb.append("</table>");
			sb.append("<p>Screenshot for above order</p>");
			
		//}
		
		mailDto.setMessage(sb.toString());
		mailDto.setSubject("STBuddy TC Notification");
		try {
			sendEmailTemplate(mailDto);
			//
		} catch (Exception e) {
			logger.error("Mail Sending problem {} "+e.getMessage());
		}
		
	}
  }

