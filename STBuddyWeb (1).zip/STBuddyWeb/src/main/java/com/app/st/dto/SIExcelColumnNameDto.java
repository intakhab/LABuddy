package com.app.st.dto;

import java.util.List;

public class SIExcelColumnNameDto {

	private String fromPlantId;
	private String toPlantId;
	private List<String> orderQnty;
	private List<String> itemNo;

	private String omrBatchVal;
	private String omrVersionVal;
	
	private String omarWarehoseBatchVal;
	private String omarWarehoseVersion;
	private String location;
	private String lot;
	private String sheetName;
	
	
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		this.lot = lot;
	}

	public String getOmarWarehoseBatchVal() {
		return omarWarehoseBatchVal;
	}

	public void setOmarWarehoseBatchVal(String omarWarehoseBatchVal) {
		this.omarWarehoseBatchVal = omarWarehoseBatchVal;
	}

	public String getOmarWarehoseVersion() {
		return omarWarehoseVersion;
	}

	public void setOmarWarehoseVersion(String omarWarehoseVersion) {
		this.omarWarehoseVersion = omarWarehoseVersion;
	}

	public String getOmrBatchVal() {
		return omrBatchVal;
	}

	public void setOmrBatchVal(String omrBatchVal) {
		this.omrBatchVal = omrBatchVal;
	}

	public String getOmrVersionVal() {
		return omrVersionVal;
	}

	public void setOmrVersionVal(String omrVersionVal) {
		this.omrVersionVal = omrVersionVal;
	}

	public String getFromPlantId() {
		return fromPlantId;
	}

	public void setFromPlantId(String fromPlantId) {
		this.fromPlantId = fromPlantId;
	}

	public String getToPlantId() {
		return toPlantId;
	}

	public void setToPlantId(String toPlantId) {
		this.toPlantId = toPlantId;
	}

	public List<String> getOrderQnty() {
		return orderQnty;
	}

	public void setOrderQnty(List<String> orderQnty) {
		this.orderQnty = orderQnty;
	}

	public List<String> getItemNo() {
		return itemNo;
	}

	public void setItemNo(List<String> itemNo) {
		this.itemNo = itemNo;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

}
