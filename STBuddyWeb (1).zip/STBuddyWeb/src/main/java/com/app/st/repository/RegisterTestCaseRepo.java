package com.app.st.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.st.domain.RegisterTestCase;

@Repository
public interface RegisterTestCaseRepo extends CrudRepository<RegisterTestCase, Long> {

	@Query("select t from RegisterTestCase t where t.testCaseType='JDE'")
	public Iterable<RegisterTestCase> findJDERegister();

	@Query("select t from RegisterTestCase t where t.testCaseType='JDA'")
	public Iterable<RegisterTestCase> findJDARegister();

	@Query("select t from RegisterTestCase t where t.testCaseType='WMS'")
	public Iterable<RegisterTestCase> findWMSRegister();

}
