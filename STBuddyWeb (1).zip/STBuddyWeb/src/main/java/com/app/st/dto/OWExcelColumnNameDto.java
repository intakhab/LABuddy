package com.app.st.dto;

import java.util.List;

/***
 * 
 * @author ISIDDIQUI
 *
 */
public class OWExcelColumnNameDto {

	private String plantId;
	private String supplier;
	private String shipTo;
	private List<String> qntyList;
	private List<String> itemList;
	private String sheetName;
	
	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public String getPlantId() {
		return plantId;
	}

	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}

	public String getShipTo() {
		return shipTo;
	}

	public void setShipTo(String shipTo) {
		this.shipTo = shipTo;
	}

	public List<String> getQntyList() {
		return qntyList;
	}

	public void setQntyList(List<String> qntyList) {
		this.qntyList = qntyList;
	}

	public List<String> getItemList() {
		return itemList;
	}

	public void setItemList(List<String> itemList) {
		this.itemList = itemList;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

}
