package com.app.st.dto;

public class JDEExcelDto {
	
	//OMR
	private String orderNo;
	private String plantId;
	private String itemNo;
	private String uomQnty;
	private String omrBatch1Val;
	private String omrBatch1Ver;
	private String omrBatch2Val;
	private String omrBatch2Ver;
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getPlantId() {
		return plantId;
	}
	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}
	public String getItemNo() {
		return itemNo;
	}
	public void setItemNo(String itemNo) {
		this.itemNo = itemNo;
	}
	public String getUomQnty() {
		return uomQnty;
	}
	public void setUomQnty(String uomQnty) {
		this.uomQnty = uomQnty;
	}
	public String getOmrBatch1Val() {
		return omrBatch1Val;
	}
	public void setOmrBatch1Val(String omrBatch1Val) {
		this.omrBatch1Val = omrBatch1Val;
	}
	public String getOmrBatch1Ver() {
		return omrBatch1Ver;
	}
	public void setOmrBatch1Ver(String omrBatch1Ver) {
		this.omrBatch1Ver = omrBatch1Ver;
	}
	public String getOmrBatch2Val() {
		return omrBatch2Val;
	}
	public void setOmrBatch2Val(String omrBatch2Val) {
		this.omrBatch2Val = omrBatch2Val;
	}
	public String getOmrBatch2Ver() {
		return omrBatch2Ver;
	}
	public void setOmrBatch2Ver(String omrBatch2Ver) {
		this.omrBatch2Ver = omrBatch2Ver;
	}
		
}
