package com.app.st.dto;

public class ResponseDto {

	private boolean isAutoStart=false;
	private boolean runStatus = false;
	private String orderNo = "";
	private String orderNo1="";
	private String currentStatus = "";
	private String fileName;
	private Long testRunId;
	private String currentRunninTime = "";
	private boolean stRunStatus=false;
	private String previousOrder="";
	private String loadId="";
	private String planId="";
	private boolean start=false;
	private String  tmsOrder;
	private boolean runReport=false;
	private String rmaCOStatus="";
	private String rmaOMStatus="";
	private String rmaCO="";
	private String rmaOM="";
	private String settingsId;
	private String reasonFail;
	private Long runningId;
	private String typeTest="";
	private String envType="DEV";
	//
	private String runCount="0";
	private SOExcelColumnNameDto soExcelColumnNameDto;
	private STExcelColumnNameDto stExcelColumnNameDto;
	private SIExcelColumnNameDto siExcelColumnNameDto;
	private SFExcelColumnNameDto sfExcelColumnNameDto;
	private SJExcelColumnNameDto sjExcelColumnNameDto;
	private OWExcelColumnNameDto owExcelColumnNameDto;
	private WOExcelColumnNameDto woExcelColumnNameDto;
	private RMAExcelColumnNameDto rmaExcelColumnNameDto;
	private String sheetName="";
	private String untilId="JDE";
	private String restorePoint="";
	
	private String captureScreenPath="";
	
	public SFExcelColumnNameDto getSfExcelColumnNameDto() {
		return sfExcelColumnNameDto;
	}

	public void setSfExcelColumnNameDto(SFExcelColumnNameDto sfExcelColumnNameDto) {
		this.sfExcelColumnNameDto = sfExcelColumnNameDto;
	}

	public SJExcelColumnNameDto getSjExcelColumnNameDto() {
		return sjExcelColumnNameDto;
	}

	public void setSjExcelColumnNameDto(SJExcelColumnNameDto sjExcelColumnNameDto) {
		this.sjExcelColumnNameDto = sjExcelColumnNameDto;
	}

	public OWExcelColumnNameDto getOwExcelColumnNameDto() {
		return owExcelColumnNameDto;
	}

	public void setOwExcelColumnNameDto(OWExcelColumnNameDto owExcelColumnNameDto) {
		this.owExcelColumnNameDto = owExcelColumnNameDto;
	}

	public WOExcelColumnNameDto getWoExcelColumnNameDto() {
		return woExcelColumnNameDto;
	}

	public void setWoExcelColumnNameDto(WOExcelColumnNameDto woExcelColumnNameDto) {
		this.woExcelColumnNameDto = woExcelColumnNameDto;
	}

	public RMAExcelColumnNameDto getRmaExcelColumnNameDto() {
		return rmaExcelColumnNameDto;
	}

	public void setRmaExcelColumnNameDto(RMAExcelColumnNameDto rmaExcelColumnNameDto) {
		this.rmaExcelColumnNameDto = rmaExcelColumnNameDto;
	}

	public String getRunCount() {
		return runCount;
	}

	public void setRunCount(String runCount) {
		this.runCount = runCount;
	}


	public String getRmaCO() {
		return rmaCO;
	}

	public void setRmaCO(String rmaCO) {
		this.rmaCO = rmaCO;
	}

	

	public String getRmaOM() {
		return rmaOM;
	}

	public boolean isAutoStart() {
		return isAutoStart;
	}

	public void setAutoStart(boolean isAutoStart) {
		this.isAutoStart = isAutoStart;
	}

	public void setRmaOM(String rmaOM) {
		this.rmaOM = rmaOM;
	}

	public String getRmaCOStatus() {
		return rmaCOStatus;
	}

	public void setRmaCOStatus(String rmaCOStatus) {
		this.rmaCOStatus = rmaCOStatus;
	}

	public String getRmaOMStatus() {
		return rmaOMStatus;
	}

	public void setRmaOMStatus(String rmaOMStatus) {
		this.rmaOMStatus = rmaOMStatus;
	}

	public String getTmsOrder() {
		return tmsOrder;
	}

	public void setTmsOrder(String tmsOrder) {
		this.tmsOrder = tmsOrder;
	}

	


	public boolean isStRunStatus() {
		return stRunStatus;
	}

	public void setStRunStatus(boolean stRunStatus) {
		this.stRunStatus = stRunStatus;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Long getTestRunId() {
		return testRunId;
	}

	public void setTestRunId(Long testRunId) {
		this.testRunId = testRunId;
	}

	public boolean isRunStatus() {
		return runStatus;
	}

	public void setRunStatus(boolean runStatus) {
		this.runStatus = runStatus;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public String getCurrentRunninTime() {
		return currentRunninTime;
	}

	public void setCurrentRunninTime(String currentRunninTime) {
		this.currentRunninTime = currentRunninTime;
	}

	public String getPreviousOrder() {
		return previousOrder;
	}

	public void setPreviousOrder(String previousOrder) {
		this.previousOrder = previousOrder;
	}

	public String getLoadId() {
		return loadId;
	}

	public void setLoadId(String loadId) {
		this.loadId = loadId;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public Long getRunningId() {
		return runningId;
	}

	public void setRunningId(Long runningId) {
		this.runningId = runningId;
	}

	public boolean isStart() {
		return start;
	}

	public void setStart(boolean start) {
		this.start = start;
	}

	public boolean isRunReport() {
		return runReport;
	}

	public void setRunReport(boolean runReport) {
		this.runReport = runReport;
	}

	public String getSettingsId() {
		return settingsId;
	}

	public void setSettingsId(String settingsId) {
		this.settingsId = settingsId;
	}

	public String getReasonFail() {
		return reasonFail;
	}

	public void setReasonFail(String reasonFail) {
		this.reasonFail = reasonFail;
	}

	public String getOrderNo1() {
		return orderNo1;
	}

	public void setOrderNo1(String orderNo1) {
		this.orderNo1 = orderNo1;
	}

	public String getTypeTest() {
		return typeTest;
	}

	public void setTypeTest(String typeTest) {
		this.typeTest = typeTest;
	}

	public String getEnvType() {
		return envType;
	}

	public void setEnvType(String envType) {
		this.envType = envType;
	}

	public SOExcelColumnNameDto getSoExcelColumnNameDto() {
		return soExcelColumnNameDto;
	}

	public void setSoExcelColumnNameDto(SOExcelColumnNameDto soExcelColumnNameDto) {
		this.soExcelColumnNameDto = soExcelColumnNameDto;
	}

	public STExcelColumnNameDto getStExcelColumnNameDto() {
		return stExcelColumnNameDto;
	}

	public void setStExcelColumnNameDto(STExcelColumnNameDto stExcelColumnNameDto) {
		this.stExcelColumnNameDto = stExcelColumnNameDto;
	}

	public SIExcelColumnNameDto getSiExcelColumnNameDto() {
		return siExcelColumnNameDto;
	}

	public void setSiExcelColumnNameDto(SIExcelColumnNameDto siExcelColumnNameDto) {
		this.siExcelColumnNameDto = siExcelColumnNameDto;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getUntilId() {
		return untilId;
	}

	public void setUntilId(String untilId) {
		this.untilId = untilId;
	}

	public String getRestorePoint() {
		return restorePoint;
	}

	public void setRestorePoint(String restorePoint) {
		this.restorePoint = restorePoint;
	}

	public String getCaptureScreenPath() {
		return captureScreenPath;
	}

	public void setCaptureScreenPath(String captureScreenPath) {
		this.captureScreenPath = captureScreenPath;
	}
}
