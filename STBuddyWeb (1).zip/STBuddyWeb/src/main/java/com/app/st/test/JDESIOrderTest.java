package com.app.st.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SIExcelColumnNameDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDESIOrderTest {

	private Logger logger = LogManager.getLogger(JDESIOrderTest.class);

	WebDriver driver;

	/*@Autowired
	private JDESIExcelReaderService excelReaderService;*/
	SIExcelColumnNameDto siExcelDto;
	@Autowired
	Environment env;
	@Autowired
	private JDEStatusCheckTest statusReports;
	@Autowired
	private JDEOMRReportsTest omrReportsTest;
	
	@Autowired
	private JDELoginTest commonLoginTest;
	
	@Autowired
	private CommonTestUtilService commonTestUtilService;
	
	@Autowired
	private JDAAutoPlanOptTest autoPlan;
	
	@Autowired
	private JDESpeedStatusTest speedStatusTest;
	/***
	 * Test 2 SI Creation
	 */
	public ResponseDto createSI(ResponseDto responseDto) {

		try {

			logger.info("******************************* Login SI Starting*********************************");
			//siExcelDto = excelReaderService.getExcelData(responseDto.getFileName()).get(0);
			siExcelDto = responseDto.getSiExcelColumnNameDto();
			driver = commonLoginTest.login();

			logger.info("******************************* Create SI Starting*********************************");
			AppUtil.pauseInSecond(2);

			commonTestUtilService.commonMenu(driver,env);

			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("si.create.url.link.1.key"))).click();

			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("si.create.url.link.2.key"))).click();
			AppUtil.pauseInSecond(2);
			// Switch to
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			AppUtil.pauseInSecond(5);

			driver.findElement(By.xpath(env.getProperty("so.create.add.link.key"))).click();

			AppUtil.pauseInSecond(2);

			logger.info("From Plant Id:" + siExcelDto.getFromPlantId());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("si.create.from.branch.plantid.key"),
					siExcelDto.getFromPlantId());
			
			AppUtil.pauseInSecond(2);
			logger.info("To Plant/Branch Id : " + siExcelDto.getToPlantId());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("si.create.to.branch.plantid.key"),
					siExcelDto.getToPlantId());
			
			AppUtil.pauseInSecond(2);

			List<String> orderQntyList = siExcelDto.getOrderQnty();
			List<String> itemNoList = siExcelDto.getItemNo();

			logger.info("Order Qnty size : " +orderQntyList.size());
			logger.info("Item No size : " + itemNoList.size());
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			 
	        js.executeScript("scroll(0,500);");
             
			if (orderQntyList.size() == itemNoList.size()
					) {
				
				for (int i = 0; i < orderQntyList.size(); i++) {
					
					commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("si.create.qnty.key"),orderQntyList.get(i));
					AppUtil.pauseInSecond(2);

					commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("si.create.item.key"),itemNoList.get(i));
					AppUtil.pauseInSecond(2);
					
					driver.findElement(By.xpath(env.getProperty("si.create.item.key"))).sendKeys(Keys.ENTER);
					AppUtil.pauseInSecond(2);
				}
			}

			js.executeScript("scroll(0,-550);");
			AppUtil.pauseInSecond(2);

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
				AppUtil.pauseInSecond(1);
			}
			
			commonTestUtilService.checkError(driver,env); // Checking error
			
			AppUtil.pauseInSecond(2);
			
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
				AppUtil.pauseInSecond(1);
			}
			
			AppUtil.pauseInSecond(2);
			
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("si.create.click.btn1.key"))) {
				driver.findElement(By.xpath(env.getProperty("si.create.click.btn1.key"))).click();
				AppUtil.pauseInSecond(1);
			}
			
			AppUtil.pauseInSecond(2);

			String siOrder = "";
			if(commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("si.create.si.order.no.key"))) {
				siOrder=	driver.findElement(By.xpath(env.getProperty("si.create.si.order.no.key")))
					.getAttribute("value").toString();
			}
			logger.info("SI Order no: " + siOrder);
			//responseDto.setStOrdeNo(siOrder);
			String oiOrder="";
   		    AppUtil.pauseInSecond(2);
			if(commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("si.create.oi.order.no.key"))) {
				oiOrder=	driver.findElement(By.xpath(env.getProperty("si.create.oi.order.no.key")))
					.getAttribute("value").toString();
			}

			AppUtil.pauseInSecond(2);
			logger.info("OI Order no: " + oiOrder);
			//responseDto.setOtOrderNo(oiOrder);
			responseDto.setRestorePoint("SI Created");
			
			if(!oiOrder.isEmpty() && !oiOrder.isEmpty()) {
				
			logger.info("******************************* Running OMR for SI *********************************");
			
			omrReportsTest.runOmr(siOrder, driver, env, siExcelDto.getOmrBatchVal(), siExcelDto.getOmrVersionVal(),"notomr");
			AppUtil.pauseInSecond(5);
			responseDto.setRestorePoint("SI OMR");
			logger.info("******************************* Running Reports for SI *********************************");

			String status=statusReports.commonReports(driver, env, siOrder,"SI");
			responseDto.setOrderNo(siOrder);
			responseDto.setOrderNo1(oiOrder);
			responseDto.setCurrentStatus(status);
			responseDto.setTmsOrder("SI"+siOrder);
			responseDto.setRestorePoint("JDE Completed");
			logger.info("******************************* Create SI completed *********************************");
			responseDto.setRunStatus(true);
			}else {
				logger.info("******************************* Create SI Failed due to incorrect input in xls *********************************");
				responseDto.setRunStatus(false);
			}
			AppUtil.pauseInSecond(5);
		} catch (NoSuchElementException e) {
			responseDto.setRunStatus(false);
			responseDto.setReasonFail(e.getMessage());
			logger.error("******************************* SI Creation Failed *********************************");
			logger.error("Error {} ", e.getMessage());

		} finally {
			commonTestUtilService.quit(driver);
			
			if ("JDE-JDA".equalsIgnoreCase(responseDto.getUntilId())) {
				logger.info("STBuddy will run till JDE-JDA {}");
				// After quitting JDE, TMS Optimization will run

						if("530".equals(responseDto.getCurrentStatus())) {
							autoPlan.autoPlanOpt(responseDto);
							logger.info("TMS work finished!!!");
						 }else {
								logger.info("Status not reached to 535 so autoPlanOpt wont run {}");
							}
						
						if("535".equals(responseDto.getCurrentStatus())) {
							AppUtil.pauseInSecond(5);
							logger.info("Status reached to 535 so running speed status");
							speedStatusTest.doSpeedStatus(responseDto);
							logger.info("Speed status finished");
						} else{
							logger.info("Status not reached to 535 so doSpeedStatus wont run {}");
						}
			}else {
				logger.info("STBuddy will run till JDE {}");
			}
						
		}
		return responseDto;

	}

	

}