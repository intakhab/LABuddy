package com.app.st.component;

import java.time.LocalTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.app.st.common.AppUtil;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SIExcelColumnNameDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.service.JDESIExcelReaderService;
import com.app.st.service.RegisterTestCaseService;
import com.app.st.test.JDESIOrderTest;

/***
 * @author intakhabalam.s@hcl.com
 * @see ApplicationContext {@link ApplicationContext}
 * @see Component
 * @see CommonMailService {@link CommonMailService}
 * @see Environment {@link Environment}
 */
@Component
public class JDESIComponent {
	private Logger logger = LogManager.getLogger(JDESIComponent.class);

	@Autowired
	JDESIOrderTest siOrderCreationTest;
	@Autowired
	private JDESIExcelReaderService jdSIExcelReaderService;
	@Autowired
	RegisterTestCaseService registerTestCaseService;
	
	
	/***
	 * Auto
	 */
	public ResponseDto invokeSICreate(ResponseDto responseDto) {
		
	
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("SI Test case Starting Time [ " + LocalTime.now() + " ]");
			try {
				List<SIExcelColumnNameDto> edtoList=jdSIExcelReaderService.getExcelData(responseDto.getFileName());
				for(SIExcelColumnNameDto  soDto:edtoList) {
					logger.info("Sheet name:"+soDto.getSheetName());
					//
					responseDto.setRunningId(null);
					responseDto.setOrderNo("");
					responseDto.setCurrentRunninTime(AppUtil.currentTime());
					responseDto.setSheetName(soDto.getSheetName());
					responseDto.setSiExcelColumnNameDto(soDto);//Test here
					responseDto.setStart(true);
					TestCaseDto tr = registerTestCaseService.saveStatusTest(responseDto);
					responseDto.setRunningId(tr.getRunningId());
					responseDto= siOrderCreationTest.createSI(responseDto);
					responseDto.setStart(false);
					registerTestCaseService.saveStatusTest(responseDto);
				   
				}
				
				
			} catch (Exception e) {
				logger.error("Error at invokeSICreate {} ", e.getMessage());
			}
			//

		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("InvokeSICreate Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
		return responseDto;
	}

	

}
