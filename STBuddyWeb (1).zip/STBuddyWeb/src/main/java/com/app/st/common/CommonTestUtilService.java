package com.app.st.common;

import java.io.File;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class CommonTestUtilService {

	private  Logger logger = LogManager.getLogger(CommonTestUtilService.class);
	
	@Autowired
	Environment env;

   /***
    * 
    * @param driver
    * @param fileName`
    */
	
	public  String saveScreen(WebDriver driver, String fileName) {
		String path=env.getProperty("screen.shot.path").concat(fileName).concat(".png");
		try {
			logger.info("Capturing screen shot at location ==> "+path);
			File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshotFile, new File(path));
		} catch (Exception e) {
			logger.debug("Error in capturing screenshot {} ", e.fillInStackTrace());
		}
		return path;
	}
	
	/***
	 * 
	 * @param key
	 * @return
	 */
	public  boolean checkResultAvailableOrNot(WebDriver driver,String key) {
		logger.info("Scanning element on client{}");
		boolean checkresultGrid;
		try {
			WebElement tf = driver.findElement(By.xpath(key));
			tf.isDisplayed();
			checkresultGrid = true;
			logger.info("Element found on client{}");
		} catch (NoSuchElementException e) {
			logger.info("Element not found on client{}");
			checkresultGrid = false;
		} finally {
			// driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		}
		return checkresultGrid;
	}

	
	public void quit(WebDriver driver) {
		driver.close();
		driver.quit();
	}
	/***
	 * 
	 * @param path
	 */
	public  void closeScreen(WebDriver driver,String path) {
		if (checkResultAvailableOrNot(driver,path)) {
			driver.findElement(By.xpath(path)).click();
		}
		
	}
	

	/***
	 * This method will check the response time of server
	 * @param driver
	 */
	public  boolean checkLoader(WebDriver driver) {
		boolean isEnabled=false;
		try {
			WebElement tf = driver.findElement(By.xpath("//*[@id='procIndicatorFloatLyr']/table/tbody/tr/td"));
			logger.info("Loader found, Checking response time {}");
			for(int i = 0;i<100;i++) {
				  Thread.sleep(1000);
				  tf = driver.findElement(By.xpath("//*[@id='procIndicatorFloatLyr']/table/tbody/tr/td"));
				  if(tf.isDisplayed()) {
					  isEnabled=true;
					  continue;
				  }else {
					  isEnabled=false;
					  break;
					  
				  }
			}
		} catch (Exception e) {
			logger.info("Loader not found {} ");
		} 
		return isEnabled;
	}
	/***
	 * 
	 * @param key
	 * @param value
	 */
	public  void clearTextAndsendKeys(WebDriver driver,String key, String value) {
		logger.info("Clearing text box{}");
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(key)).clear();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(key)).sendKeys("");
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(key)).sendKeys(value);
		AppUtil.pauseInSecond(1);
		logger.info("Cleared  text box with value ::"+value);
	}
	
	/***
	 * 
	 */
	public void commonMenu(WebDriver driver,Environment env) {
		logger.info("*************Common Menu Starting**************");
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.2.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.3.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.4.key"))).click();
		logger.info("*************Common Menu End**************");

	}
	
	/***
	 * 
	 * @param driver
	 * @param env
	 */
	public  void deleteCheckBox(WebDriver driver,Environment env) {
		List<WebElement> checkBoxList = driver
				.findElements(By.xpath(env.getProperty("so.create.order.check.box.list.key")));
		AppUtil.pauseInSecond(1);
		for (int i = 1; i < checkBoxList.size(); i++) {
			logger.info("Clicking select check box id: " + (i + 1));
			driver.findElement(By.xpath("//*[@id='Select" + (i + 1) + "']")).click();
			AppUtil.pauseInSecond(1);
		}
		AppUtil.pauseInSecond(1);
		logger.info("Deleting selected checkbox");
		driver.findElement(By.xpath(env.getProperty("so.create.order.check.box.del.key"))).click();
	}

	/***
	 * 
	 */
	public  void commonVersionSelection(WebDriver driver,Environment env,String type) {
		logger.info("Version selection starting........");
		AppUtil.pauseInSecond(1);
		deleteCheckBox(driver,env);
		// AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.left.drop.down.key"))).click();
		// AppUtil.pauseInSecond(1);
		Select leftSelect = new Select(
				driver.findElement(By.xpath(env.getProperty("so.create.order.left.drop.down.key"))));
		// AppUtil.pauseInSecond(1);
		 String dropDownVal="";
		 if("omr".equals(type)) {
			 dropDownVal= env.getProperty("so.create.order.left.drop.down.omr.value");
		 }else {
			 dropDownVal= env.getProperty("so.create.order.left.drop.down.value");
		 }
		logger.info("Selecting value: " + dropDownVal);

		leftSelect.selectByVisibleText(dropDownVal);
		
		// AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.comparison.drop.down.key"))).click();

		// AppUtil.pauseInSecond(1);
		Select midSelect = new Select(
				driver.findElement(By.xpath(env.getProperty("so.create.order.comparison.drop.down.key"))));

		//AppUtil.pauseInSecond(1);
		logger.info("Selecting value: " + env.getProperty("so.create.order.comparison.drop.down.value"));
		
		midSelect.selectByVisibleText(env.getProperty("so.create.order.comparison.drop.down.value"));

		//AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.right.drop.down.key"))).click();

		// AppUtil.pauseInSecond(1);
		Select rightSelect = new Select(
				driver.findElement(By.xpath(env.getProperty("so.create.order.right.drop.down.key"))));

		// AppUtil.pauseInSecond(1);
		logger.info("Selecting value: " + env.getProperty("so.create.order.right.drop.down.value"));

		rightSelect.selectByVisibleText(env.getProperty("so.create.order.right.drop.down.value"));
		
		AppUtil.pauseInSecond(1);
		logger.info("Version selection end........");
	}

	
	
	public  void checkError(WebDriver driver,Environment env) {
		logger.info("Checking for error present else proceed.");
		if(checkResultAvailableOrNot(driver,"//*[@id='jdeINYFE']")){
			AppUtil.pauseInSecond(1);
			WebElement element = driver.findElement(By.xpath("//*[@id='jdeINYFE']"));
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].scrollIntoView();", element); 
		}
	}
}
