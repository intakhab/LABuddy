package com.app.st.dto;

import java.util.List;

/**
 * 
 * @author ISIDDIQUI
 *
 */
public class SOExcelColumnNameDto {

	String shipValue; // Index =0
	String customerPoValue;// Index =1
	String branchId;// Index =2
	List<String> orderQty;// Index =3
	List<String> itemNumber;// Index =4
	String batchAppSearch1;// Index =5
	String batchAppSearch2;// Index =6
	String batchAppSearch3;// Index =7
	String batchVer1;// Index =8
	String batchVer2;// Index =9
	String batchVer3;// Index =10
	String omrBatchAppSearch;//Index =11
	String omrBatchVer;//Index =12
	String sheetName;

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

	public String getOmrBatchAppSearch() {
		return omrBatchAppSearch;
	}

	public void setOmrBatchAppSearch(String omrBatchAppSearch) {
		this.omrBatchAppSearch = omrBatchAppSearch;
	}

	public String getOmrBatchVer() {
		return omrBatchVer;
	}

	public void setOmrBatchVer(String omrBatchVer) {
		this.omrBatchVer = omrBatchVer;
	}

	public String getShipValue() {
		return shipValue;
	}

	public void setShipValue(String shipValue) {
		this.shipValue = shipValue;
	}

	public String getCustomerPoValue() {
		return customerPoValue;
	}

	public void setCustomerPoValue(String customerPoValue) {
		this.customerPoValue = customerPoValue;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public List<String> getOrderQty() {
		return orderQty;
	}

	public void setOrderQty(List<String> orderQty) {
		this.orderQty = orderQty;
	}

	public List<String> getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(List<String> itemNumber) {
		this.itemNumber = itemNumber;
	}

	public String getBatchAppSearch1() {
		return batchAppSearch1;
	}

	public void setBatchAppSearch1(String batchAppSearch1) {
		this.batchAppSearch1 = batchAppSearch1;
	}

	public String getBatchAppSearch2() {
		return batchAppSearch2;
	}

	public void setBatchAppSearch2(String batchAppSearch2) {
		this.batchAppSearch2 = batchAppSearch2;
	}

	public String getBatchAppSearch3() {
		return batchAppSearch3;
	}

	public void setBatchAppSearch3(String batchAppSearch3) {
		this.batchAppSearch3 = batchAppSearch3;
	}

	public String getBatchVer1() {
		return batchVer1;
	}

	public void setBatchVer1(String batchVer1) {
		this.batchVer1 = batchVer1;
	}

	public String getBatchVer2() {
		return batchVer2;
	}

	public void setBatchVer2(String batchVer2) {
		this.batchVer2 = batchVer2;
	}

	public String getBatchVer3() {
		return batchVer3;
	}

	public void setBatchVer3(String batchVer3) {
		this.batchVer3 = batchVer3;
	}

}
