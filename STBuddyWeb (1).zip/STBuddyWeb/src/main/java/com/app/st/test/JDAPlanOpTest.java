package com.app.st.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.ResponseDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDAPlanOpTest {

	private Logger logger = LogManager.getLogger(JDAPlanOpTest.class);
	@Autowired
	JDALoginTest jdaLoginTest;

	WebDriver driver;
	@Autowired
	Environment env;
	@Autowired
	CommonTestUtilService commonTestUtilService;
	public ResponseDto createPlanOpt(ResponseDto responseDto) {

		try {
            logger.info("****************************************TMS login starting*************************************");
			driver = jdaLoginTest.login();
			logger.info("****************************************TMS login Successfully*************************************");
			AppUtil.pauseInSecond(1);
			driver.navigate().refresh();
			AppUtil.pauseInSecond(1);
			driver.switchTo().frame(env.getProperty("jda.frame1.key"));
			driver.switchTo().frame(env.getProperty("jda.frame2.key"));
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.tree.cell.img4.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.result.99.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame.result.key"));
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.principal.id.key"))).clear();
			AppUtil.pauseInSecond(1);

			// Code needs to be added to get the Shipment id.
			 logger.info("Putting Order no::"+responseDto.getTmsOrder());
			driver.findElement(By.xpath(env.getProperty("jda.principal.id.key"))).sendKeys(responseDto.getTmsOrder()); // Order
																														// input
																														// needed
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("jda.refresh.key"))).click();
			// ***Plan id code needs to be written *** /
			AppUtil.pauseInSecond(5);
			 logger.info("Finding Plan Id...");
			String planID = driver.findElement(By.xpath(env.getProperty("jda.planid.key"))).getText();//

			logger.info("Plan Id :: "+planID);
			
			responseDto.setPlanId(planID);

			// If plan Id doesn't not exist then code execution will stop.

			// Plan ID code starts
			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame2.key"));
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("jda.tree.cell.img7.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.tree.cell.img71.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.tree.cell.img714.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.result.104.key"))).click();

			AppUtil.pauseInSecond(1);
			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame.results.key"));

			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.save.search.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.option.2414.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.img.style.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.plan.name.key"))).clear();
			AppUtil.pauseInSecond(1);
			 logger.info("Putting Plan Id...");
			driver.findElement(By.xpath(env.getProperty("jda.plan.name.key"))).sendKeys(planID);
			AppUtil.pauseInSecond(1);
			 logger.info("Searching with Plan Id...");
			driver.findElement(By.xpath(env.getProperty("jda.container.img.key"))).click();

			AppUtil.pauseInSecond(5);
			 logger.info("Finding Plan Id...");
			boolean isPlanIdFound = commonTestUtilService.checkResultAvailableOrNot(driver,
					env.getProperty("jda.row.name.key"));
			 logger.info("Finding Plan Id..."+isPlanIdFound);
			
			if (isPlanIdFound) {
				
				driver.findElement(By.xpath(env.getProperty("jda.row.name.key"))).click();
				AppUtil.pauseInSecond(5);

				driver.findElement(By.xpath(env.getProperty("jda.emphasized.key"))).click();
				AppUtil.pauseInSecond(5);

				driver.findElement(By.xpath(env.getProperty("jda.yes.popup.key"))).click(); // yes pop up
				AppUtil.pauseInSecond(5);

				logger.info("Plan id is " + planID + " successfully selected");
				
			} else {

				// Plan ID does not exist
				logger.info("Plan id not found ");
				logger.info("User Plan Authorization starting");

				driver.switchTo().parentFrame();
				driver.switchTo().frame(env.getProperty("jda.frame2.key"));

				AppUtil.pauseInSecond(5);
				driver.findElement(By.xpath(env.getProperty("jda.result.113.key"))).click();

				driver.switchTo().parentFrame();
				driver.switchTo().frame(env.getProperty("jda.frame.result.key"));

				AppUtil.pauseInSecond(5);

				driver.findElement(By.xpath(env.getProperty("jda.emphasized.tr.key"))).click();

				AppUtil.pauseInSecond(1);

				driver.findElement(By.xpath(env.getProperty("jda.plan.name1.key"))).clear();
				driver.findElement(By.xpath(env.getProperty("jda.plan.name1.key"))).sendKeys(planID);

				AppUtil.pauseInSecond(1);

				driver.findElement(By.xpath(env.getProperty("jda.img.plan.id.refresh.key"))).click();

				AppUtil.pauseInSecond(1);

				driver.findElement(By.xpath(env.getProperty("jda.auth.user.id.key")))
						.sendKeys(env.getProperty("jda.auth.user.id.val"));

				AppUtil.pauseInSecond(1);

				driver.findElement(By.xpath(env.getProperty("jda.img.user.id.refresh.key"))).click();

				AppUtil.pauseInSecond(1);

				driver.findElement(By.xpath(env.getProperty("jda.select.current.plan.key"))).click();

				AppUtil.pauseInSecond(1);

				driver.findElement(By.xpath(env.getProperty("jda.emphasized.key"))).click();

				logger.info("Plan id: " + planID + " successfully selected");

			}

			// Plan id code ends
			// Load build
			logger.info("Load Id building");
			driver.navigate().refresh();

			AppUtil.pauseInSecond(1);

			driver.switchTo().frame(env.getProperty("jda.frame1.key"));
			driver.switchTo().frame(env.getProperty("jda.frame2.key"));

			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("jda.tree.cell.img7.key"))).click();
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("jda.tree.cell.img71.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.tree.cell.img714.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.result.106.key"))).click();
			AppUtil.pauseInSecond(1);

			// content frame
			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame.results.key"));
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.save.search.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.option.2448.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.shipment.number.key"))).clear();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.shipment.number.key"))).sendKeys(responseDto.getTmsOrder()); // order
																															// entry
			// needed
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.refresh.key"))).click();
			AppUtil.pauseInSecond(5);
			driver.findElement(By.xpath(env.getProperty("jda.td.row.name.key"))).click();// Why this code broken?//Des
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.regular.btn9.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.switchTo().parentFrame();

			driver.switchTo().frame(env.getProperty("jda.frame2.key"));
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.result.110.key"))).click();
			AppUtil.pauseInSecond(5);
			//
			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame.result.key"));
			AppUtil.pauseInSecond(1);
			boolean found=false;
			if(commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("jda.regular.btn7.key"))) {
				driver.findElement(By.xpath(env.getProperty("jda.regular.btn7.key"))).click();
				found=true;
			}
			if(!found && commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("jda.regular.btn6.key"))) {
				driver.findElement(By.xpath(env.getProperty("jda.regular.btn6.key"))).click();
			}
			AppUtil.pauseInSecond(5);
			driver.findElement(By.xpath(env.getProperty("jda.emphasized.key"))).click();
			logger.info("Waiting for 25 second(s)");
			AppUtil.pauseInSecond(25);
			logger.info("Waiting for 25 second(s)");
			AppUtil.pauseInSecond(25);
			logger.info("Waiting for 25 second(s)");
			
			AppUtil.pauseInSecond(25);
			driver.findElement(By.xpath(env.getProperty("jda.tr.row.name.key"))).click(); // 1st value
			AppUtil.pauseInSecond(5);
			logger.info("Shipment Optimizised and Load id generated");
			driver.findElement(By.xpath(env.getProperty("jda.regular.btn2.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.menu.text.key"))).click();
			
			AppUtil.pauseInSecond(1);
			String loadId = driver.findElement(By.xpath(env.getProperty("jda.load.id.1.key"))).getText();

			logger.info("Load ID is " + loadId + " for Order.");
			
			responseDto.setLoadId(loadId);
			AppUtil.pauseInSecond(1);
			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame2.key"));
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.result.105.key"))).click();
			AppUtil.pauseInSecond(5);

			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame.results.key"));
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.principal.id.key"))).sendKeys(loadId);
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("jda.refresh.key"))).click();
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("jda.row.name.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.btn.border7.key"))).click(); // set to planned uncomment
			// Here will message display in TMS "Load 1473529 set to 'Planned' and auto
			// tendered."
			logger.info("Load set to 'Planned' and auto Tendered");
			// Tender Response and Accpet Tender Request.
			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame2.key"));

			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.tree.cell.img14.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.result.166.key"))).click();
			AppUtil.pauseInSecond(5);

			driver.switchTo().parentFrame();
			driver.switchTo().frame(env.getProperty("jda.frame.results.key"));

			driver.findElement(By.xpath(env.getProperty("jda.tab.index2.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.option.2444.key"))).click();
			AppUtil.pauseInSecond(5);
			driver.findElement(By.xpath(env.getProperty("jda.tab.index3.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.load.name.key"))).sendKeys(loadId);
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.refresh.key"))).click();
			AppUtil.pauseInSecond(5);
			// testing

			driver.findElement(By.xpath(env.getProperty("jda.td.row.name.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("jda.regular.btn11.key"))).click();
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("jda.emphasized.tr.key"))).click();
			AppUtil.pauseInSecond(1);
			logger.info("Tender Accepted for Load ID: " + loadId);
			AppUtil.pauseInSecond(1);
			logger.info("Check for order status in JDE is 535.");
			AppUtil.pauseInSecond(1);
			logger.info("Appointment and Traffic details sent to WMS");
			AppUtil.pauseInSecond(1);
			logger.info("Thanks for automation !!");
			//
			responseDto.setPlanId(planID);
			responseDto.setLoadId(loadId);
			responseDto.setRunStatus(true);
			//
		} catch (NoSuchElementException e) {
			responseDto.setRunStatus(false);
			responseDto.setReasonFail(e.getMessage());
			logger.error("******************************* PlanId Optmization Creation Failed *********************************");
			logger.error("Error {} ", e.fillInStackTrace());
		} finally {
			quit();
		}

		return responseDto;
	}

	public void quit() {
		driver.close();
		driver.quit();
	}

}
