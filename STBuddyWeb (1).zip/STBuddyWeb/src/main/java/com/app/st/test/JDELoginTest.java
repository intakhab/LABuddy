package com.app.st.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.dto.TestCaseDto;
import com.app.st.service.RegisterTestCaseService;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDELoginTest {
	@Autowired
	private Environment env;
	
	@Autowired
	private RegisterTestCaseService registerTestCaseService;
	
	public WebDriver login() {
		TestCaseDto tdo=registerTestCaseService.loadSettings();
		WebDriver driver = null;
		 if("chrome".equalsIgnoreCase(tdo.getBrowserType())) {
		   driver=new ChromeDriver();
		 }else if("firefox".equalsIgnoreCase(tdo.getBrowserType())) {
		   driver=new FirefoxDriver();
		 }else if("ie".equalsIgnoreCase(tdo.getBrowserType())) {
			 driver=new InternetExplorerDriver();
		 }else {
			 driver=new ChromeDriver();
		 }
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.navigate().to(tdo.getJdeURL());
		driver.manage().window().maximize();
		driver.findElement(By.xpath(env.getProperty("jde.user.path"))).sendKeys(tdo.getJdeUserId());
		driver.findElement(By.xpath(env.getProperty("jde.pass.path"))).sendKeys(tdo.getJdeUserPass());
		driver.findElement(By.xpath(env.getProperty("jde.login.path"))).click();
		
		return driver;
		
		
	}

}
