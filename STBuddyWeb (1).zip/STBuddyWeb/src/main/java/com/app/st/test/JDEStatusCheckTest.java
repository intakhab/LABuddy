package com.app.st.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDEStatusCheckTest {

	private Logger logger = LogManager.getLogger(JDEStatusCheckTest.class);
	@Autowired
	CommonTestUtilService commonTestUtilService;

	public String commonReports(WebDriver driver, Environment env, String orderNo, String type) {

		AppUtil.pauseInSecond(1);
		logger.info("******************************* Status check starting *****************************");
		driver.switchTo().parentFrame();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
		AppUtil.pauseInSecond(1);
		commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.av.link.key"), env.getProperty("so.fastpath.P4210"));
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
		AppUtil.pauseInSecond(5);

		logger.info("Putting value order no : " + orderNo);
		logger.info("Putting Type : " + type);
		
		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.order.batch.application.search.textbox.key"), orderNo);
		if("SF".equals(type)) {
			if(commonTestUtilService.checkResultAvailableOrNot(driver, 
					env.getProperty("so.create.order.batch.application.search.type.key"))) {
				commonTestUtilService.clearTextAndsendKeys(driver, 
						env.getProperty("so.create.order.batch.application.search.type.key"), type);
			}
		}if("ST".equals(type)) {
			if(commonTestUtilService.checkResultAvailableOrNot(driver, 
					env.getProperty("so.create.order.batch.application.search.type.key"))) {
				commonTestUtilService.clearTextAndsendKeys(driver, 
						env.getProperty("so.create.order.batch.application.search.type.key"), type);
			}
		}
		if("SI".equalsIgnoreCase(type)) {
			if(commonTestUtilService.checkResultAvailableOrNot(driver, 
					env.getProperty("so.create.order.batch.application.search.type.key"))) {
				commonTestUtilService.clearTextAndsendKeys(driver, 
						env.getProperty("so.create.order.batch.application.search.type.key"), type);
			}
		}
		AppUtil.pauseInSecond(2);
		
		driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.key"))).click();

		AppUtil.pauseInSecond(2);

		String status = driver.findElement(By.xpath(env.getProperty("so.create.order.final.status.key"))).getText();
		AppUtil.pauseInSecond(2);
		if(status.isEmpty()) {
			status = driver.findElement(By.xpath(env.getProperty("so.create.order.final.status.key"))).getText();
		}
		logger.info("Status Value::" + status);
		AppUtil.pauseInSecond(2);
		logger.info("****************************** Status check completed  ******************************");
		return status;
	}

}
