package com.app.st.service;


import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.dto.SIExcelColumnNameDto;

/**
 * 
 * @author intakhabalam.s
 *
 */
@Service
public class JDESIExcelReaderService {

	@Autowired
	private FilePathService filePathService;
	/***
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public List<SIExcelColumnNameDto> getExcelData(String excelFilePath)  {
		
		List<SIExcelColumnNameDto> colList = new ArrayList<>();
		Workbook wb;
		try {
			wb = AppUtil.getWorkbook(filePathService.loadFile(excelFilePath), excelFilePath);
			int totalNoOfSheet = wb.getNumberOfSheets();
			for (int i = 0; i < totalNoOfSheet; i++) {
				SIExcelColumnNameDto dto = getSheetValues(wb, i);
				dto.setSheetName(wb.getSheetName(i));
				colList.add(dto);	
			}

		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return colList;
	}

	/***
	 * 
	 * @return
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	private SIExcelColumnNameDto getSheetValues(Workbook wb, int sheet) 
			throws URISyntaxException, IOException {

		SIExcelColumnNameDto dto = new SIExcelColumnNameDto();
		Sheet firstSheet = wb.getSheetAt(sheet);
		Iterator<Row> iterator = firstSheet.iterator();
		List<String> orderQtyList = new ArrayList<>();
		List<String> itemNoList = new ArrayList<>();
		//
		try {
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				int rowCount = nextRow.getRowNum();
				if (rowCount == 0) {//Header
					continue;
				}
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
						case 0:
							dto.setFromPlantId(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 1:
							dto.setToPlantId(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 2:
							orderQtyList.add(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							dto.setOrderQnty(orderQtyList);
							break;
						case 3:
							itemNoList.add(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							dto.setItemNo(itemNoList);
							break;
						case 4:
							dto.setOmrBatchVal(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 5:
							dto.setOmrVersionVal(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;	
							//
						case 6:
							dto.setOmarWarehoseBatchVal(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;	
						case 7:
							dto.setOmarWarehoseVersion(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;	
						case 8:
							dto.setLocation(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;	
						case 9:
							dto.setLot(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;		
						
					}
				}
			}
		} finally {
			if (wb != null) {
			    wb.close();
			}
		}
		return dto;
	}
	
	
}

