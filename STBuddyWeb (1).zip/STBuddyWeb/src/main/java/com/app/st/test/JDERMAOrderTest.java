package com.app.st.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.RMAExcelColumnNameDto;
import com.app.st.dto.ResponseDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDERMAOrderTest {

	private Logger logger = LogManager.getLogger(JDERMAOrderTest.class);
	private WebDriver driver;
	//@Autowired
	//private JDERMAExcelReaderService excelReaderService;
	private RMAExcelColumnNameDto excelDto;
	@Autowired
	private Environment env;
	@Autowired
	private JDELoginTest commonLoginTest;
	@Autowired
	CommonTestUtilService commonTestUtilService;

	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto createRMA(ResponseDto responseDto) {

		try {

			logger.info("******************************* Login RMA Starting*********************************");
			
		//	excelDto = excelReaderService.getExcelData(responseDto.getFileName()).get(0);
			excelDto = responseDto.getRmaExcelColumnNameDto();
			driver = commonLoginTest.login();

			logger.info("******************************* Create RMA Starting*********************************");
			AppUtil.pauseInSecond(1);

			commonTestUtilService.commonMenu(driver,env);
			AppUtil.pauseInSecond(1);
			commonRMAMenu();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("rma.create.link.301.ib.key"))).click();// Link
			AppUtil.pauseInSecond(1);
			// Switch to
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));

			AppUtil.pauseInSecond(5);

			driver.findElement(By.xpath(env.getProperty("so.create.add.link.key"))).click();

			AppUtil.pauseInSecond(2);

			logger.info("Customer :" + excelDto.getCustomer());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.create.customer.key"),
					excelDto.getCustomer());

			logger.info("Ship To : " + excelDto.getShipTo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.create.shipto.key"), excelDto.getShipTo());

			AppUtil.pauseInSecond(2);

			logger.info("Claim PO : " + excelDto.getClaimPo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.create.claimpo.key"),
					excelDto.getClaimPo());

			AppUtil.pauseInSecond(2);

			logger.info("RMA IB : " + excelDto.getRmaIb());
			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("jda.rma.ib.key"), excelDto.getRmaIb());
			AppUtil.pauseInSecond(2);

			logger.info("RMA IB  Val : " + excelDto.getRmaIbVal());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("jda.rma.ib.val.key"), excelDto.getRmaIbVal());

			AppUtil.pauseInSecond(2);

			logger.info("Plant Id : " + excelDto.getPlantId());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.create.plantid.key"),
					excelDto.getPlantId());

			AppUtil.pauseInSecond(2);

			List<String> crrList = excelDto.getCrrList();
			List<String> qntyList = excelDto.getRmaQntyList();
			List<String> itemList = excelDto.getRmaItemList();
			List<String> reasonList = excelDto.getReturnReasonList();

			logger.info("CRR  Size  : " + crrList.size());
			logger.info("Item Size  : " + itemList.size());
			logger.info("Qnty Size  : " + qntyList.size());
			logger.info("Return Reason Size   : " + reasonList.size());

			for (int i = 0; i < crrList.size(); i++) {

				commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.create.crr.key"), crrList.get(i));

				AppUtil.pauseInSecond(2);

				commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.create.item.key"), itemList.get(i));

				AppUtil.pauseInSecond(2);
				commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.create.qnty.key"), qntyList.get(i));

				AppUtil.pauseInSecond(2);
				WebElement element = driver.findElement(By.id("jdeGridBack0_1"));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft += 5300", element);
				AppUtil.pauseInSecond(2);
				if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("rma.create.rma.key"))) {
					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.create.rma.key"),
							reasonList.get(i));

					AppUtil.pauseInSecond(2);

				}

			}
			AppUtil.pauseInSecond(1);

			String rmaNo = "";
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("rma.create.rmano.key"))) {
				rmaNo = driver.findElement(By.xpath(env.getProperty("rma.create.rmano.key"))).getAttribute("value")
						.toString();
			}
			AppUtil.pauseInSecond(1);

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
				AppUtil.pauseInSecond(1);
			}
			if (rmaNo.isEmpty()
					&& commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("rma.create.rmano.key"))) {
				rmaNo = driver.findElement(By.xpath(env.getProperty("rma.create.rmano.key"))).getAttribute("value")
						.toString();
			}

			AppUtil.pauseInSecond(1);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
			}

			AppUtil.pauseInSecond(2);

			if (rmaNo.isEmpty()
					&& commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("rma.create.rmano.key"))) {
				rmaNo = driver.findElement(By.xpath(env.getProperty("rma.create.rmano.key"))).getAttribute("value")
						.toString();
			}

			AppUtil.pauseInSecond(2);
			logger.info("RMA no: " + rmaNo);

			responseDto.setOrderNo(rmaNo);
			responseDto.setRestorePoint("RMA Created");
			checkStatusForRMA(responseDto,rmaNo);
		
			logger.info("**************** Ist Report Starting ***************************");
			driver.switchTo().parentFrame();
			commonTestUtilService.commonMenu(driver,env);
			commonRMAMenu();// common Reports
			driver.findElement(By.xpath(env.getProperty("rma.create.link.sync.co.om.key"))).click();// link
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			
			commonReports(responseDto.getRmaCO());
			AppUtil.pauseInSecond(1);
			responseDto.setRestorePoint("Report-1");
			logger.info("**************** Ist Report End ***************************");
			// here reports 2 will run ############################################# 2
			logger.info("**************** 2nd Report Starting ***************************");
			driver.switchTo().parentFrame();
			commonTestUtilService.commonMenu(driver,env);
			commonRMAMenu();// common Reports
			driver.findElement(By.xpath(env.getProperty("rma.create.proof.order.link.key"))).click();
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			
			commonReports(responseDto.getRmaCO());
			
			logger.info("Waiting for here for status change....");
			AppUtil.pauseInSecond(30);
			logger.info("Waiting for here for status change....");
			AppUtil.pauseInSecond(30);
			logger.info("Waiting for here for status change....");
			AppUtil.pauseInSecond(30);
			responseDto.setRestorePoint("Report-2");
			logger.info("**************** 2nd Report End ***************************");
			logger.info("**************** BV Report Starting ***************************");
			driver.switchTo().parentFrame();
			driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("so.create.order.av.link.key")))
					.sendKeys(env.getProperty("so.create.order.av.link.value"));
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();
			AppUtil.pauseInSecond(2);
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));

			driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.key")))
					.sendKeys(excelDto.getRmaBatchVal());
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.key"))).click();
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("rma.create.previous.order.search.key")))
					.sendKeys(excelDto.getRmaBatchVersion());
			AppUtil.pauseInSecond(5);
			driver.findElement(By.xpath(env.getProperty("so.create.order.lookup.order.key"))).click();
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("rma.craete.lookup.next.key"))).click();
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
			
			commonReports(responseDto.getRmaOM());
			
			AppUtil.pauseInSecond(2);
			responseDto.setRestorePoint("BV Report");
			logger.info("**************** BV Report End ***************************");
			// FInal Reports #########################################################
			logger.info("**************** Final Report Starting ***************************");
			driver.switchTo().parentFrame();
			AppUtil.pauseInSecond(2);
			commonTestUtilService.commonMenu(driver,env);
			commonRMAMenu();// common Reports
			driver.findElement(By.xpath(env.getProperty("rma.create.update.transmit.link.key"))).click();
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));

			driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.submit.key"))).click();// *[@id="hc0"]
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
			
			logger.info("**************** Final Report Ending ***************************");
			responseDto.setRestorePoint("Final Report");
			
			logger.info("**************** Again need to check the status for CO/OM  ***************************");
			driver.switchTo().parentFrame();
			commonTestUtilService.commonMenu(driver,env);
			commonRMAMenu();// common Reports
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("rma.create.link.301.ib.key"))).click();// Link
			AppUtil.pauseInSecond(2);
			// Switch to
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			responseDto=checkStatusForRMA(responseDto,rmaNo);
			//
			
			responseDto.setRunStatus(true);
			
			responseDto.setOrderNo(rmaNo);
			responseDto.setOrderNo1(responseDto.getRmaCO() + "/" + responseDto.getRmaOM());
			responseDto.setCurrentStatus(responseDto.getRmaCOStatus() + "/" + responseDto.getRmaOMStatus());
			responseDto.setRestorePoint("RMA Completed");
			logger.info("*******************************  RMA Creation completed *********************************");

		} catch (NoSuchElementException e) {
			responseDto.setRunStatus(false);
			responseDto.setReasonFail(e.getMessage());
			logger.error("******************************* RMA Creation Failed *********************************");
			logger.error("Error {} ", e.getMessage());

		} finally {
			commonTestUtilService.quit(driver);
		}
		return responseDto;

	}

	
	
	private ResponseDto checkStatusForRMA(ResponseDto responseDto,String rmaNo) {
		
		logger.info("******************************* Searching RMA *********************************");
		// clearing
		logger.info("Clearing RMA IB");

		driver.findElement(By.xpath(env.getProperty("rma.clear.ib.key"))).clear();

		AppUtil.pauseInSecond(1);

		logger.info("Clearing RMA IB Val");

		driver.findElement(By.xpath(env.getProperty("rma.clear.ib.val.key"))).clear();
		AppUtil.pauseInSecond(1);

		logger.info("Clearing Plant Id");

		driver.findElement(By.xpath(env.getProperty("rma.clear.plant.id.key"))).clear();
		AppUtil.pauseInSecond(1);

		logger.info("Putting RMA and Searching ");

		commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("rma.search.key"), rmaNo);

		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.lookup.order.key"))).click();
		AppUtil.pauseInSecond(1);

		WebElement element = driver.findElement(By.id("jdeGridBack0_1"));
		String scrollMo = env.getProperty("rma.scroll.mo.key");

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft += " + scrollMo + "", element);
		AppUtil.pauseInSecond(1);
		String co = driver.findElement(By.xpath(env.getProperty("rma.create.so.key"))).getText();
		
		responseDto.setRmaCO(co);
		logger.info("CO:: "+co);
		
		// find here so status//
		String scrollSo = env.getProperty("rma.scroll.so.key");
		AppUtil.pauseInSecond(1);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft += " + scrollSo + "", element);
		AppUtil.pauseInSecond(1);
		String om = driver.findElement(By.xpath(env.getProperty("rma.create.po.key"))).getText();
		logger.info("OM:: "+om);
		responseDto.setRmaOM(om);
		//
		String coStatus = driver.findElement(By.xpath(env.getProperty("rma.create.so.status.580.key"))).getText();
		logger.info("CO status::  "+coStatus);
		responseDto.setRmaCOStatus(coStatus);
		
		AppUtil.pauseInSecond(1);
		String scroll400 = env.getProperty("rma.scroll.400.key");
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft += " + scroll400 + "", element);
		AppUtil.pauseInSecond(1);

		String omStatus = driver.findElement(By.xpath(env.getProperty("rma.create.po.status.400.key"))).getText();

		logger.info("OM Status ::"+omStatus);
		responseDto.setRmaOMStatus(omStatus);
		
		logger.info("**************** Ist Report End ***************************");
		
		return responseDto;
	}
	/**
	 * 
	 * @param coOM
	 */
	public void commonReports(String coOM) {
		
		logger.info("****************Common Reporting ***************************");
        logger.info("CO/OM nos ::"+coOM);
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.op.pass.key"))).click();
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.submit.key"))).click();// *[@id="hc0"]
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath("//*[@id='RightOperand3']")).sendKeys("Lit");
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath("//*[@id='LITtf']")).clear();
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath("//*[@id='LITtf']")).sendKeys(coOM);// CO Order numberso.create.order.select.next.key
		AppUtil.pauseInSecond(2);
		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
		}
		AppUtil.pauseInSecond(1);

		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		logger.info("****************Common Reporting Finished ***************************");

	}

	/***
	 * 
	 */
	private void commonRMAMenu() {
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.4.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("rma.create.credit.return.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("rma.create.jde.wms.key"))).click();
		AppUtil.pauseInSecond(1);

	}

	


}
