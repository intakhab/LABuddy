package com.app.st.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SJExcelColumnNameDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDESJOrderTest {

	private Logger logger = LogManager.getLogger(JDESJOrderTest.class);

	private WebDriver driver;
	private SJExcelColumnNameDto excelDto;
	@Autowired
	private Environment env;
	@Autowired
	private JDELoginTest commonLoginTest;
	
	@Autowired
	private CommonTestUtilService commonTestUtilService;

	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto createSJ(ResponseDto responseDto) {

		try {

			logger.info("******************************* Login SJ Starting*********************************");
			//excelDto = excelReaderService.getExcelData(responseDto.getFileName()).get(0);
			excelDto = responseDto.getSjExcelColumnNameDto();
			driver = commonLoginTest.login();

			logger.info("******************************* Create ST Starting*********************************");
			AppUtil.pauseInSecond(2);

			commonTestUtilService.commonMenu(driver,env);

			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("sj.create.url.link.1.key"))).click();

			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("sj.create.url.link.2.key"))).click();
			AppUtil.pauseInSecond(2);
			// Switch to
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			AppUtil.pauseInSecond(10);

			driver.findElement(By.xpath(env.getProperty("so.create.add.link.key"))).click();

			AppUtil.pauseInSecond(2);

			logger.info("Sold To : " + excelDto.getSoldTo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sj.create.sold.to.key"),
					excelDto.getSoldTo());

			AppUtil.pauseInSecond(2);

			logger.info("Ship To:" + excelDto.getShipTo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sj.create.ship.to.key"),
					excelDto.getShipTo());

			logger.info("Cust PO : " + excelDto.getCustPo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sj.create.cust.po.key"),
					excelDto.getCustPo());

			AppUtil.pauseInSecond(2);
			
			
			logger.info("Plant/Branch Id : " + excelDto.getPlantId());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("sj.create.branch.plantid.key"),
					excelDto.getPlantId());

			AppUtil.pauseInSecond(2);
			

			List<String> orderQntyList = excelDto.getOrderQnty();
			List<String> itemNoList = excelDto.getItemNo();

			logger.info("Order Qnty size : " + excelDto.getOrderQnty().size());
			logger.info("Item No size : " + excelDto.getItemNo().size());

			if (orderQntyList.size() == itemNoList.size()
					) {
				
				for (int i = 0; i < orderQntyList.size(); i++) {
					
					commonTestUtilService.clearTextAndsendKeys(driver, 
							env.getProperty("sj.create.qnty.key"),excelDto.getOrderQnty().get(i));
					
					AppUtil.pauseInSecond(2);

					commonTestUtilService.clearTextAndsendKeys(driver, 
							env.getProperty("sj.create.item.key"),excelDto.getItemNo().get(i));
					
					AppUtil.pauseInSecond(2);
					driver.findElement(By.xpath(env.getProperty("sj.create.item.key"))).sendKeys(Keys.ENTER);
					AppUtil.pauseInSecond(2);
				}
			}

			AppUtil.pauseInSecond(2);

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
				AppUtil.pauseInSecond(2);
			}

			AppUtil.pauseInSecond(2);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
			}

			AppUtil.pauseInSecond(2);

			String sjOrder = "";
			if(commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("sj.create.order.no.key"))) {
				sjOrder=	driver.findElement(By.xpath(env.getProperty("sj.create.order.no.key")))
					.getAttribute("value").toString();
			}

			AppUtil.pauseInSecond(2);
			logger.info("SJ Order no: " + sjOrder);

			responseDto.setOrderNo(sjOrder);
			
			responseDto.setRunStatus(true);
			responseDto.setRestorePoint("SJ Created");
			logger.info("******************************* Create SJ completed *********************************");
		} catch (NoSuchElementException e) {
			responseDto.setRunStatus(false);
			responseDto.setReasonFail(e.getMessage());
			logger.error("******************************* SJ Creation Failed *********************************");
			logger.error("Error {} ", e.getMessage());

		} finally {
			commonTestUtilService.quit(driver);
		}
		return responseDto;

	}

	

}
