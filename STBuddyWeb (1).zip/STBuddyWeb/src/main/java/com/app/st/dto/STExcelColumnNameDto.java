package com.app.st.dto;

import java.util.List;

/**
 * 
 * @author ISIDDIQUI
 *
 */
public class STExcelColumnNameDto {
	private String fromBranchPlantNo;
	private String toBranchPlantNo;
	private List<String> orderQnty;
	private List<String> itemNo;
	private List<String> custItemNo;
	
	private String omrBatchVal;
	private String omrVersionVal;
	//
	private String omarWarehoseBatchVal;
	private String omarWarehoseVersion;
	private String location;
	private String lot;
	
	private String sheetName;
	
	
	
	public String getOmrBatchVal() {
		return omrBatchVal;
	}
	public void setOmrBatchVal(String omrBatchVal) {
		this.omrBatchVal = omrBatchVal;
	}
	public String getOmrVersionVal() {
		return omrVersionVal;
	}
	public void setOmrVersionVal(String omrVersionVal) {
		this.omrVersionVal = omrVersionVal;
	}
	public String getToBranchPlantNo() {
		return toBranchPlantNo;
	}
	public void setToBranchPlantNo(String toBranchPlantNo) {
		this.toBranchPlantNo = toBranchPlantNo;
	}
	public List<String> getOrderQnty() {
		return orderQnty;
	}
	public void setOrderQnty(List<String> orderQnty) {
		this.orderQnty = orderQnty;
	}
	public List<String> getItemNo() {
		return itemNo;
	}
	public void setItemNo(List<String> itemNo) {
		this.itemNo = itemNo;
	}
	public List<String> getCustItemNo() {
		return custItemNo;
	}
	public void setCustItemNo(List<String> custItemNo) {
		this.custItemNo = custItemNo;
	}
	
	public String getFromBranchPlantNo() {
		return fromBranchPlantNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getLot() {
		return lot;
	}
	public void setLot(String lot) {
		this.lot = lot;
	}
	public String getOmarWarehoseBatchVal() {
		return omarWarehoseBatchVal;
	}
	public void setOmarWarehoseBatchVal(String omarWarehoseBatchVal) {
		this.omarWarehoseBatchVal = omarWarehoseBatchVal;
	}
	public String getOmarWarehoseVersion() {
		return omarWarehoseVersion;
	}
	public void setOmarWarehoseVersion(String omarWarehoseVersion) {
		this.omarWarehoseVersion = omarWarehoseVersion;
	}
	public void setFromBranchPlantNo(String fromBranchPlantNo) {
		this.fromBranchPlantNo = fromBranchPlantNo;
	}
	public String getSheetName() {
		return sheetName;
	}
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	
	
}
