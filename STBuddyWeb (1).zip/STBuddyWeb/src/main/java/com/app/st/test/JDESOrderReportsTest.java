package com.app.st.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SOExcelColumnNameDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDESOrderReportsTest {

	private Logger logger = LogManager.getLogger(JDESOrderReportsTest.class);
	private WebDriver driver;
	@Autowired
	private Environment env;
	@Autowired
	private JDEOMRReportsTest omrReportsTest;
	@Autowired
	private JDEStatusCheckTest commonReportTest;
	
	@Autowired
	private JDELoginTest commonLoginTest;
	private SOExcelColumnNameDto excelDto;
	
	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto runReports(ResponseDto responseDto) {
		
		try {
			//excelDto = excelReaderService.getExcelData(fileName).get(0);
			excelDto = responseDto.getSoExcelColumnNameDto();
			logger.info("******************************* Login for Reports Starting*********************************");
			driver = commonLoginTest.login();
			AppUtil.pauseInSecond(2);
			boolean isRun = false;
			 String status=commonReportTest.commonReports(driver, env,
					 responseDto.getOrderNo(),responseDto.getTypeTest());
			 
			if (status.equals(responseDto.getCurrentStatus())) {
				isRun = true;
			} else {
				isRun = false;
			}
			logger.info("Assert :: " + isRun);
			AppUtil.pauseInSecond(2);
			logger.info("****************************** Reports Step Completd  ******************************");
			if(isRun && status.equals("560")  ) {
				
				logger.info("Status is 560, Therefore SO OMR should run");
				
				omrReportsTest.runOmr(responseDto.getOrderNo(),  driver, 
						env,excelDto.getOmrBatchAppSearch(),excelDto.getOmrBatchVer(),"omr");
				
				logger.info("OMR Pass::");
				
				if(responseDto.isRunReport()) {
					AppUtil.pauseInMins(5);
					logger.info("OMR Run successfully, therefore Report is running to see the status change.");
					//status=commonReportTest.commonReports(driver, env, responseDto.getOrderNo(),responseDto.getTypeTest());
					//logger.info("Now status:: "+status);
				}
		     }
			
			responseDto.setCurrentStatus(status);
			responseDto.setRunStatus(isRun);
			
	     }catch(NoSuchElementException e) {
				 logger.error("Reports  Failed for Order no :: "+responseDto.getOrderNo());
				 logger.error("Error {} ",e.getMessage());
			
		} finally {
			quit();
		}
		return responseDto;

	}

	
	boolean isLogin=false;
	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto runReportInSingleLogin(ResponseDto responseDto) {
		try {
			excelDto = responseDto.getSoExcelColumnNameDto();
			logger.info("******************************* Login for Reports Starting*********************************");
			
			 if(!isLogin)
				 driver = commonLoginTest.login();
			 isLogin=true;
			 AppUtil.pauseInSecond(2);
			 boolean isRun = false;
			 String status=commonReportTest.commonReports(driver, env, responseDto.getOrderNo(),responseDto.getTypeTest());
			 
			if (status.equals(responseDto.getCurrentStatus())) {
				isRun = true;
			} else {
				isRun = false;
			}
			logger.info("Assert :" + isRun);
			
			AppUtil.pauseInSecond(2);
			
			logger.info("****************************** Reports Step Completed  ******************************");
			
			if(isRun && status.equals("560")  ) {
				
				logger.info("Status is 560, Therefore SO OMR should run");
				
				omrReportsTest.runOmr(responseDto.getOrderNo(),  driver, 
						env,excelDto.getOmrBatchAppSearch(),excelDto.getOmrBatchVer(),"omr");
				
				logger.info("OMR Pass::");
				
				if(responseDto.isRunReport()) {
					AppUtil.pauseInMins(5);
					logger.info("OMR Run successfully, therefore Report is running to see the status change.");
					//status=commonReportTest.commonReports(driver, env, responseDto.getOrderNo(),responseDto.getTypeTest());
					//logger.info("Now status:: "+status);
				}
		     }
			
			responseDto.setCurrentStatus(status);
			responseDto.setRunStatus(isRun);
			
	     }catch(NoSuchElementException e) {
				 logger.error("Reports  Failed for Order no :: "+responseDto.getOrderNo());
				 logger.error("Error {} ",e.getMessage());
			
		} finally {
			quit();
		}
		return responseDto;

	}

	public void quit() {
		isLogin=false;
		driver.close();
		driver.quit();
	}

}

