package com.app.st.dto;

import java.util.List;

public class SJExcelColumnNameDto {
	
	private List<String> orderQnty;
	private List<String> itemNo;
	private String plantId;
	private String soldTo;
	private String shipTo;
	private String  custPo;
	private String sheetName;
	
	public List<String> getOrderQnty() {
		return orderQnty;
	}
	public void setOrderQnty(List<String> orderQnty) {
		this.orderQnty = orderQnty;
	}
	public List<String> getItemNo() {
		return itemNo;
	}
	public void setItemNo(List<String> itemNo) {
		this.itemNo = itemNo;
	}
	public String getPlantId() {
		return plantId;
	}
	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}
	public String getSoldTo() {
		return soldTo;
	}
	public void setSoldTo(String soldTo) {
		this.soldTo = soldTo;
	}
	public String getShipTo() {
		return shipTo;
	}
	public void setShipTo(String shipTo) {
		this.shipTo = shipTo;
	}
	public String getCustPo() {
		return custPo;
	}
	public void setCustPo(String custPo) {
		this.custPo = custPo;
	}
	public String getSheetName() {
		return sheetName;
	}
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	
}
