package com.app.st.service;


import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.dto.OWExcelColumnNameDto;

/**
 * 
 * @author intakhabalam.s
 *
 */
@Service
public class JDEOWExcelReaderService {

	
	@Autowired
	Environment env;

	@Autowired
	FilePathService filePathService;
	/***
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public List<OWExcelColumnNameDto> getExcelData(String excelFilePath)  {
		
		List<OWExcelColumnNameDto> colList = new ArrayList<>();
		Workbook wb;
		try {
			wb = AppUtil.getWorkbook(filePathService.loadFile(excelFilePath), excelFilePath);
			int totalNoOfSheet = wb.getNumberOfSheets();
			for (int i = 0; i < totalNoOfSheet; i++) {
				OWExcelColumnNameDto dto = getSheetValues(wb, i);
				dto.setSheetName(wb.getSheetName(i));
				colList.add(dto);	
			}

		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return colList;
	}

	/***
	 * 
	 * @return
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	private OWExcelColumnNameDto getSheetValues(Workbook wb, int sheet) 
			throws URISyntaxException, IOException {

		OWExcelColumnNameDto dto = new OWExcelColumnNameDto();
		
		Sheet firstSheet = wb.getSheetAt(sheet);
		
		Iterator<Row> iterator = firstSheet.iterator();
		List<String> orderQtyList = new ArrayList<>();
		List<String> itemNoList = new ArrayList<>();
		//
		try {
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				int rowCount = nextRow.getRowNum();
				if (rowCount == 0) {//Header
					continue;
				}
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
						case 0:
							dto.setPlantId(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 1:
							dto.setSupplier(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 2:
							dto.setShipTo(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						
						case 3:
							orderQtyList.add(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							dto.setQntyList(orderQtyList);
							break;
						case 4:
							itemNoList.add(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							dto.setItemList(itemNoList);
							break;
						
					}
				}
			}
		} finally {
			if (wb != null) {
			    wb.close();
			}
		}
		return dto;
	}
	
	
}

