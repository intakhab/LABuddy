package com.app.st.component;

import java.time.LocalTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.app.st.dto.ResponseDto;
import com.app.st.test.JDAPlanOpTest;

/***
 * @author intakhabalam.s@hcl.com
 * @see ApplicationContext {@link ApplicationContext}
 * @see Component
 * @see CommonMailService {@link CommonMailService}
 * @see Environment {@link Environment}
 */
@Component
public class JDAPlanOpComponent {
	private Logger logger = LogManager.getLogger(JDAPlanOpComponent.class);

	@Autowired
	private JDAPlanOpTest jdaPlanOpTest;

	/***
	 * Auto
	 */
	public ResponseDto invokePlanOptCreate(ResponseDto responseDto) {

		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("JDA Plan Opt Test case Starting Time [ " + LocalTime.now() + " ]");
		try {

			responseDto = jdaPlanOpTest.createPlanOpt(responseDto);

		} catch (Exception e) {
			logger.error("Error at invokePlanOptCreate {} ", e.getMessage());
		}
		//

		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("invokePlanOptCreate Finishing Time [ " + LocalTime.now()
				+ " ] => Total time taken to be completed  [ " + totalTimeTaken + "s ]");
		return responseDto;
	}

}
