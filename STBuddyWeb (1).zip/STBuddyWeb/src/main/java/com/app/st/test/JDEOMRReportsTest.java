package com.app.st.test;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDEOMRReportsTest {
	private Logger logger = LogManager.getLogger(JDEOMRReportsTest.class);

	@Autowired
	CommonTestUtilService commonTestUtilService;
	/***
	 * Test OMR SO Creation
	 */
	public String runOmr(String orderNo, WebDriver driver, Environment env, String serachVal,
			String searchVersion,String type) {
		try {
			AppUtil.pauseInSecond(1);
			driver.switchTo().parentFrame();
			logger.info("******************************* OMR Batch starting *********************************");
			//AppUtil.pauseInSecond(5);
			logger.info("Step OMR processing with batch application ::" + serachVal);
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
			AppUtil.pauseInSecond(2);
			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.av.link.key"),
					env.getProperty("so.create.order.av.link.value"));
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			AppUtil.pauseInSecond(1);
			logger.info("Putting value: " + serachVal);

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.batch.application.key"),
					serachVal);
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.textbox.key")))
					.click();
			AppUtil.pauseInSecond(2);

			String versionSearchKey = searchVersion;

			logger.info("Version Search value putting:: " + versionSearchKey);
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.version.serach.key")))
					.sendKeys(versionSearchKey);
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.textbox.key")))
					.click();// work
			// here//
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("so.create.order.version.check.key"))).click();// work here//

			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("so.create.order.select.key"))).click();
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.submit.key"))).click();

			logger.info("Going for version selection:");
			AppUtil.pauseInSecond(1);

			commonTestUtilService.commonVersionSelection(driver, env, type);
			AppUtil.pauseInSecond(1);

			logger.info("Putting Order no: " + orderNo);
			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.put.order.no.key"),
					orderNo);
			AppUtil.pauseInSecond(2);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
			}
			AppUtil.pauseInSecond(1);

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
			}

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
			}

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
			}

			AppUtil.pauseInSecond(1);

			logger.info("****************************** OMR Batch completed  *********************************");

		} catch (NoSuchElementException e) {
			logger.error("******************************* OMR Failed *********************************");
			logger.error("Error {} ", e.getMessage());

		}
		return orderNo;

	}

}
