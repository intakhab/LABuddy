package com.app.st.dto;

import java.util.List;

public class SFExcelColumnNameDto {

	private String plantId;
	private String shipTo;
	private String custPo;
	private List<String> orderQntyList;
	private List<String> uomList;
	private List<String> itemList;
	private List<String> custItemList;
	
	private String omrBatchVal;
	private String omrVersionVal;
	
	private String sheetName;
	
	public String getOmrBatchVal() {
		return omrBatchVal;
	}
	public void setOmrBatchVal(String omrBatchVal) {
		this.omrBatchVal = omrBatchVal;
	}
	public String getOmrVersionVal() {
		return omrVersionVal;
	}
	public void setOmrVersionVal(String omrVersionVal) {
		this.omrVersionVal = omrVersionVal;
	}
	public String getPlantId() {
		return plantId;
	}
	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}
	public String getShipTo() {
		return shipTo;
	}
	public void setShipTo(String shipTo) {
		this.shipTo = shipTo;
	}
	public String getCustPo() {
		return custPo;
	}
	public void setCustPo(String custPo) {
		this.custPo = custPo;
	}
	public List<String> getOrderQntyList() {
		return orderQntyList;
	}
	public void setOrderQntyList(List<String> orderQntyList) {
		this.orderQntyList = orderQntyList;
	}
	public List<String> getUomList() {
		return uomList;
	}
	public void setUomList(List<String> uomList) {
		this.uomList = uomList;
	}
	public List<String> getItemList() {
		return itemList;
	}
	public void setItemList(List<String> itemList) {
		this.itemList = itemList;
	}
	public List<String> getCustItemList() {
		return custItemList;
	}
	public void setCustItemList(List<String> custItemList) {
		this.custItemList = custItemList;
	}
	public String getSheetName() {
		return sheetName;
	}
	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}
	
}
