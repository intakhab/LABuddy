package com.app.st.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.app.st.domain.TestSettings;

@Repository
public interface TestSettingsRepo extends CrudRepository<TestSettings, Long> {

	

}
