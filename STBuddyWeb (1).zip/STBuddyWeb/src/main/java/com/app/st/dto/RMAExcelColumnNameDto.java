package com.app.st.dto;

import java.util.List;

/***
 * 
 * @author ISIDDIQUI
 *
 */
public class RMAExcelColumnNameDto {

	private String rmaIb;
	private String rmaIbVal;
	private String plantId;
	private String customer;
	private String shipTo;
	private String claimPo;
	private List<String> crrList;
	private List<String> rmaItemList;
	private List<String> rmaQntyList;
	private List<String> returnReasonList;
	private String rmaBatchVal;
	private String rmaBatchVersion;
	
	private String sheetName;

	public String getRmaBatchVal() {
		return rmaBatchVal;
	}

	public void setRmaBatchVal(String rmaBatchVal) {
		this.rmaBatchVal = rmaBatchVal;
	}

	public String getRmaBatchVersion() {
		return rmaBatchVersion;
	}

	public void setRmaBatchVersion(String rmaBatchVersion) {
		this.rmaBatchVersion = rmaBatchVersion;
	}

	public String getRmaIb() {
		return rmaIb;
	}

	public void setRmaIb(String rmaIb) {
		this.rmaIb = rmaIb;
	}

	public String getRmaIbVal() {
		return rmaIbVal;
	}

	public void setRmaIbVal(String rmaIbVal) {
		this.rmaIbVal = rmaIbVal;
	}

	public String getPlantId() {
		return plantId;
	}

	public void setPlantId(String plantId) {
		this.plantId = plantId;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getShipTo() {
		return shipTo;
	}

	public void setShipTo(String shipTo) {
		this.shipTo = shipTo;
	}

	public String getClaimPo() {
		return claimPo;
	}

	public void setClaimPo(String claimPo) {
		this.claimPo = claimPo;
	}

	public List<String> getCrrList() {
		return crrList;
	}

	public void setCrrList(List<String> crrList) {
		this.crrList = crrList;
	}

	public List<String> getRmaItemList() {
		return rmaItemList;
	}

	public void setRmaItemList(List<String> rmaItemList) {
		this.rmaItemList = rmaItemList;
	}

	public List<String> getRmaQntyList() {
		return rmaQntyList;
	}

	public void setRmaQntyList(List<String> rmaQntyList) {
		this.rmaQntyList = rmaQntyList;
	}

	public List<String> getReturnReasonList() {
		return returnReasonList;
	}

	public void setReturnReasonList(List<String> returnReasonList) {
		this.returnReasonList = returnReasonList;
	}

	public String getSheetName() {
		return sheetName;
	}

	public void setSheetName(String sheetName) {
		this.sheetName = sheetName;
	}

}
