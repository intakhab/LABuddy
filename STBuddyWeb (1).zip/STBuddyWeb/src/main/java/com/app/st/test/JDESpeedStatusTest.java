package com.app.st.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.ResponseDto;

@Service
public class JDESpeedStatusTest {
	private Logger logger = LogManager.getLogger(JDESpeedStatusTest.class);
	@Autowired
	Environment env;
	WebDriver driver;
	@Autowired
	JDELoginTest commonLoginTest;
	
	@Autowired
	CommonTestUtilService commonTestUtilService;
	
	@Autowired
	JDEShipmentConfirmNoTransTest shipmentConfirmNoTransTest;

	@Autowired
	JDEStatusCheckTest statusReports;
	
	@Autowired
	JDEOMRReportsTest omrReportsTest;
	

	public ResponseDto doSpeedStatus( ResponseDto responseDto) {
		
		
		logger.info("******************************* Login for Speed Status Starting*********************************");
		driver = commonLoginTest.login();

		AppUtil.pauseInSecond(2);

		commonTestUtilService.commonMenu(driver,env);
		
		driver.findElement(By.xpath(env.getProperty("so.sales.order.super.menu.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.sales.update.key"))).click();
		AppUtil.pauseInSecond(5);
		driver.switchTo().frame(env.getProperty("so.create.iframe1.key"));
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("speed.order.put.key"))).clear();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("speed.order.put.key"))).sendKeys(responseDto.getOrderNo());
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.lookup.order.key"))).click();
		AppUtil.pauseInSecond(2);
		runSpeedStatus(driver, "540");
		AppUtil.pauseInSecond(2);
		runSpeedStatus(driver, "560");
		
		logger.info("Going for shipment confirm non trans");
		shipmentConfirmNoTransTest.doShipmentConfir(driver, responseDto);//1
		logger.info("Finished for shipment confirm non trans");		
		AppUtil.pauseInSecond(2);
		
		String searchVal="";
		String searchVersion="";
		
		if("SI".equals(responseDto.getTypeTest())) {
			searchVal=responseDto.getSiExcelColumnNameDto().getOmarWarehoseBatchVal();
			searchVersion=responseDto.getSiExcelColumnNameDto().getOmarWarehoseVersion();
		}else {
			searchVal=responseDto.getStExcelColumnNameDto().getOmarWarehoseBatchVal();
			searchVersion=responseDto.getStExcelColumnNameDto().getOmarWarehoseVersion();
		}
		
		logger.info("Running OMR for {} "+responseDto.getTypeTest());
		//if("560".equals(status)) {
			omrReportsTest.runOmr(responseDto.getOrderNo(), driver, env, searchVal, searchVersion, "omr");
		//}
		logger.info("OMR finished for {} ");
		logger.info("Again running reports for {} ");
		String status=statusReports.commonReports(driver, env, responseDto.getOrderNo(), responseDto.getTypeTest());
		boolean isRun=false;
		logger.info("Finding status now..."+status);
		if (status.equals("571")) {
			isRun = true;
		} else {
			isRun = false;
		}
		logger.info("Assert :" + isRun);
		responseDto.setCurrentStatus(status);
		responseDto.setRunStatus(isRun);
		
		return responseDto;
	}

	private void runSpeedStatus(WebDriver driver, String status) {

		logger.info("Speed status will run for status :"+status);
		List<WebElement> checkBoxList = driver.findElements(By.xpath(env.getProperty("speed.status.table.key")));
		for (int i = 0; i < checkBoxList.size(); i++) {

			String path = "//*[@id='G0_1_R" + i + "']/td[1]/div/input";

			String LnType = driver.findElement(By.xpath("//*[@id='G0_1_R" + i + "']/td[9]/div")).getText();

			if ("S".equals(LnType)) {
				driver.findElement(By.xpath(path)).click();
				AppUtil.pauseInSecond(1);
			}
		}
		driver.findElement(By.xpath(env.getProperty("ow.create.plantid.key"))).clear();
		AppUtil.pauseInSecond(1);

		driver.findElement(By.xpath(env.getProperty("ow.create.plantid.key"))).sendKeys(status);
		AppUtil.pauseInSecond(1);

		driver.findElement(By.xpath(env.getProperty("so.create.order.select.key"))).click();
		//AppUtil.pauseInSecond(1);
		AppUtil.pauseInSecond(1);
		
		logger.info("Speed status done for :: "+status);
		
		

	}
}
