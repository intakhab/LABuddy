package com.app.st.component;

import java.time.LocalTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.app.st.common.AppUtil;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.STExcelColumnNameDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.repository.RunningTestCaseRepo;
import com.app.st.service.JDESTExcelReaderService;
import com.app.st.service.RegisterTestCaseService;
import com.app.st.test.JDESTOrderTest;

/***
 * @author intakhabalam.s@hcl.com
 * @see ApplicationContext {@link ApplicationContext}
 * @see Component
 * @see CommonMailService {@link CommonMailService}
 * @see Environment {@link Environment}
 */
@Component
public class JDESTComponent {
	private Logger logger = LogManager.getLogger(JDESTComponent.class);

	@Autowired
	JDESTOrderTest stOrderCreationTest;
	@Autowired
	RunningTestCaseRepo runningTestCaseRepo;
	@Autowired
	private JDESTExcelReaderService jdSTExcelReaderService;
	@Autowired
	RegisterTestCaseService registerTestCaseService;	
	
	/***
	 * Auto
	 */
	public ResponseDto invokeSTCreate(ResponseDto responseDto) {
		
	
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("ST Test case Starting Time [ " + LocalTime.now() + " ]");
			try {
				
				
				List<STExcelColumnNameDto> edtoList=jdSTExcelReaderService.getExcelData(responseDto.getFileName());
				for(STExcelColumnNameDto  soDto:edtoList) {
					logger.info("Sheet name:"+soDto.getSheetName());
					//
					responseDto.setRunningId(null);
					responseDto.setOrderNo("");
					responseDto.setCurrentRunninTime(AppUtil.currentTime());
					responseDto.setSheetName(soDto.getSheetName());
					responseDto.setStExcelColumnNameDto(soDto);//Test here
					responseDto.setStart(true);
					TestCaseDto tr = registerTestCaseService.saveStatusTest(responseDto);
					responseDto.setRunningId(tr.getRunningId());
					responseDto= stOrderCreationTest.createST(responseDto);
					responseDto.setStart(false);
					registerTestCaseService.saveStatusTest(responseDto);
				   
				}
				
				
			} catch (Exception e) {
				logger.error("Error at invokeSTCreate {} ", e.getMessage());
			}
			//

		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("InvokeSTCreate Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
		return responseDto;
	}

	

}
