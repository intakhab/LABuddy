package com.app.st.service;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.st.dto.SOExcelColumnNameDto;

/**
 * 
 * @author intakhabalam.s
 *
 */
@Service
public class JDESOExcelReaderService {

	@Autowired
	private FilePathService filePathService;
	/***
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public List<SOExcelColumnNameDto> getExcelData(String excelFilePath)  {
		
		List<SOExcelColumnNameDto> colList = new ArrayList<>();
		Workbook wb;
		try {
			wb = getWorkbook(filePathService.loadFile(excelFilePath), excelFilePath);
			int totalNoOfSheet = wb.getNumberOfSheets();
			for (int i = 0; i < totalNoOfSheet; i++) {
				SOExcelColumnNameDto dto = getSheetValues(wb, i);
				dto.setSheetName(wb.getSheetName(i));
				colList.add(dto);	
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return colList;
	}

	/***
	 * 
	 * @return
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	private SOExcelColumnNameDto getSheetValues(Workbook wb, int sheet) 
			throws URISyntaxException, IOException {

		SOExcelColumnNameDto dto = new SOExcelColumnNameDto();
		
		Sheet firstSheet = wb.getSheetAt(sheet);
		
		Iterator<Row> iterator = firstSheet.iterator();
		List<String> orderQtyList = new ArrayList<>();
		List<String> itemNoList = new ArrayList<>();
		//
		try {
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				int rowCount = nextRow.getRowNum();
				if (rowCount == 0) {//Header
					continue;
				}
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
						case 0:
							dto.setShipValue(String.valueOf(getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 1:
							dto.setCustomerPoValue(String.valueOf(getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 2:
							dto.setBranchId(String.valueOf(getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 3:
							orderQtyList.add(String.valueOf(getCellValue(nextCell)).split("\\.")[0]);
							dto.setOrderQty(orderQtyList);
							break;
						case 4:
							itemNoList.add(String.valueOf(getCellValue(nextCell)).split("\\.")[0]);
							dto.setItemNumber(itemNoList);
							break;
						case 5:
							dto.setBatchAppSearch1(String.valueOf(getCellValue(nextCell)));
							break;
						case 6:
							dto.setBatchAppSearch2(String.valueOf(getCellValue(nextCell)));
							break;
						case 7:
							dto.setBatchAppSearch3(String.valueOf(getCellValue(nextCell)));
							break;
						case 8:
							dto.setBatchVer1(String.valueOf(getCellValue(nextCell)));
							break;
						case 9:
							dto.setBatchVer2(String.valueOf(getCellValue(nextCell)));
							break;
						case 10:
							dto.setBatchVer3(String.valueOf(getCellValue(nextCell)));
							break;
						case 11:
							dto.setOmrBatchAppSearch(String.valueOf(getCellValue(nextCell)));
							break;
						case 12:
							dto.setOmrBatchVer(String.valueOf(getCellValue(nextCell)));
							break;
					}
				}
			}
		} finally {
			if (wb != null) {
			    wb.close();
			}
		}
		return dto;
	}
	

	/**
	 * Regards
	 * @return
	 */
	public List<Cell> getColumnValue() {
		List<Cell> cells = new ArrayList<Cell>(0);
		Workbook wb = null;
		try {

			String excelFilePath = filePathService.getXSLPath().getFileName().toString().toLowerCase();
			wb = getWorkbook(filePathService.loadFile(), excelFilePath);
			Sheet sheet = wb.getSheetAt(0);

			// we will search for column index containing string "Your Column Name" in the
			// row 0 (which is first row of a worksheet
			String columnWanted = "ORDER_QTY";
			Integer columnNo = null;
			// output all not null values to the list

			Row firstRow = sheet.getRow(0);

			for (Cell cell : firstRow) {
				if (cell.getStringCellValue().equals(columnWanted)) {
					columnNo = cell.getColumnIndex();
				}
			}

			if (columnNo != null) {
				for (Row row : sheet) {
					Cell c = row.getCell(columnNo);
					if (c == null || c.getCellType() == CellType.BLANK) {
						// Nothing in the cell in this row, skip it
					} else {
						cells.add(c);
					}
				}
			} else {
				System.out.println("could not find column " + columnWanted + " in first row of " + excelFilePath);
			}

		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			if (wb != null) {
				try {
					wb.close();
				} catch (IOException e) {
				}
			}
		}
		return cells;
	}

	/***
	 * 
	 * @param inputStream
	 * @param excelFilePath
	 * @return
	 * @throws IOException
	 */
	private Workbook getWorkbook(InputStream inputStream, String excelFilePath) throws IOException {
		Workbook workbook = null;
		if (excelFilePath.endsWith("xlsx")) {
			workbook = new XSSFWorkbook(inputStream);
		} else if (excelFilePath.endsWith("xls")) {
			workbook = new HSSFWorkbook(inputStream);
		} else {
			throw new IllegalArgumentException("The specified file is not Excel file");
		}
		return workbook;
	}

	/**
	 * 
	 * @param cell
	 * @return
	 */
	private static Object getCellValue(Cell cell) {
		switch (cell.getCellType()) {
		case STRING:
			return cell.getStringCellValue();

		case BOOLEAN:
			return cell.getBooleanCellValue();

		case NUMERIC:
			return cell.getNumericCellValue();
		default:
			break;
		}
		return null;

	}
	
}

