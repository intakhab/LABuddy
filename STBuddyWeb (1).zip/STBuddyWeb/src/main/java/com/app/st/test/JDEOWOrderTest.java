package com.app.st.test;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.OWExcelColumnNameDto;
import com.app.st.dto.ResponseDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDEOWOrderTest {

	private Logger logger = LogManager.getLogger(JDEOWOrderTest.class);

	private WebDriver driver;

	//@Autowired
	//private JDEOWExcelReaderService excelReaderService;
	private OWExcelColumnNameDto excelDto;
	@Autowired
	private Environment env;
	@Autowired
	private JDELoginTest commonLoginTest;
	@Autowired
	private CommonTestUtilService commonTestUtilService;

	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto createOW(ResponseDto responseDto) {

		try {

			logger.info("******************************* Login OW Starting*********************************");
			//excelDto = excelReaderService.getExcelData(responseDto.getFileName()).get(0);
			excelDto = responseDto.getOwExcelColumnNameDto();
			
			driver = commonLoginTest.login();

			logger.info("******************************* Create OW Starting*********************************");
			AppUtil.pauseInSecond(2);

			driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
			AppUtil.pauseInSecond(2);
			
			driver.findElement(By.xpath(env.getProperty("so.create.order.av.link.key"))).sendKeys(env.getProperty("so.fastpath.p4310"));
			AppUtil.pauseInSecond(2);
			driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();

			AppUtil.pauseInSecond(10);
			// Switch to
			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			
			AppUtil.pauseInSecond(5);

			driver.findElement(By.xpath(env.getProperty("so.create.add.link.key"))).click();

			AppUtil.pauseInSecond(2);

			logger.info("Supplier To:" + excelDto.getSupplier());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("ow.create.supplier.key"),
					excelDto.getSupplier());
			
			AppUtil.pauseInSecond(2);

			logger.info("Plant Id : " + excelDto.getPlantId());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("ow.create.plantid.key"),
					excelDto.getPlantId());

			AppUtil.pauseInSecond(2);
			
			logger.info("Ship To : " + excelDto.getShipTo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("ow.create.shipto.key"),
					excelDto.getShipTo());

			AppUtil.pauseInSecond(2);
			

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
				AppUtil.pauseInSecond(2);
			}

			AppUtil.pauseInSecond(10);

			List<String> orderQntyList = excelDto.getQntyList();
			List<String> itemNoList = excelDto.getItemList();

			logger.info("Order Qnty size : " + orderQntyList.size());
			logger.info("Item No size : " + itemNoList.size());

			if (orderQntyList.size() == itemNoList.size()) {

				for (int i = 0; i < orderQntyList.size(); i++) {

					
					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("ow.create.item.key"),
							itemNoList.get(i));
					AppUtil.pauseInSecond(2);


					commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("ow.create.qnty.key"),
							orderQntyList.get(i));

					AppUtil.pauseInSecond(2);
					driver.findElement(By.xpath(env.getProperty("ow.create.item.key"))).sendKeys(Keys.ENTER);
					AppUtil.pauseInSecond(2);
				}
			}

			AppUtil.pauseInSecond(2);

			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
				AppUtil.pauseInSecond(2);
			}

			AppUtil.pauseInSecond(2);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
			}

			AppUtil.pauseInSecond(2);

			String owOrder = "";
			
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("ow.create.orderno.key"))) {
				owOrder = driver.findElement(By.xpath(env.getProperty("ow.create.orderno.key")))
						.getAttribute("value").toString();
			}
			
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("ow.create.previous.orderno.key"))) {
				owOrder = driver.findElement(By.xpath(env.getProperty("ow.create.previous.orderno.key")))
						.getAttribute("value").toString();
			}
			
			

			AppUtil.pauseInSecond(2);
			
			logger.info("OW Order no: " + owOrder);
			responseDto.setRestorePoint("OW Created");
			responseDto.setOrderNo(owOrder);
			responseDto.setRunStatus(true);
			responseDto.setCurrentStatus("400");
			responseDto.setRestorePoint("OW Completed");
			logger.info("******************************* Create OW completed *********************************");
		} catch (NoSuchElementException e) {
			responseDto.setRunStatus(false);
			responseDto.setReasonFail(e.getMessage());
			logger.error("******************************* OW Creation Failed *********************************");
			logger.error("Error {} ", e.getMessage());

		} finally {
			commonTestUtilService.quit(driver);
		}
		return responseDto;

	}


}
