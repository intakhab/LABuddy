package com.app.st.repository;

import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.app.st.domain.RunningTestCase;
/***
 * 
 * @author ISIDDIQUI
 *
 */
@Repository
public interface RunningTestCaseRepo extends PagingAndSortingRepository <RunningTestCase, Long> {

	@Query("select t from RunningTestCase t where t.stauts='530' and t.registerTestCase.testCaseIndex='SO' and t.runCount='0'")
	public List<RunningTestCase> findRunningTestCase530Status();
	
	@Query("select t from RunningTestCase t where t.stauts='535' and t.registerTestCase.testCaseIndex='SO' and t.runCount='1'")
	public List<RunningTestCase> findRunningTestCase560Status();
	
	@Query("select t from RunningTestCase t where t.stauts='560' and t.registerTestCase.testCaseIndex='SO' and t.runCount='2'")
	public List<RunningTestCase> findRunningTestCase571Status();
	
	@Query("select t from RunningTestCase t where t.stauts='560' and t.orderNumber=?1")
	public List<RunningTestCase> findRunningTestCase571Status(String order);
	
	@Query("select t from RunningTestCase t where t.orderNumber=?1")
	public List<RunningTestCase> loadRunningTestCase(String order);
	
	@Query("select t from RunningTestCase t where t.stauts=?1 and t.runCount=?2 and t.orderNumber=?3")
	public List<RunningTestCase> findRunningTestCaseStatus(String staus,String runCount,String orderNo);
	
	@Query("select t from RunningTestCase t where t.registerTestCase.testCaseType=?1 order by t.id DESC")
	public List<RunningTestCase>  loadTestByType(String type,PageRequest pa);

}
