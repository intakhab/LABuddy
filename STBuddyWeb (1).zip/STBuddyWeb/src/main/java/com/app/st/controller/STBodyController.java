package com.app.st.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.component.JDAPlanOpComponent;
import com.app.st.component.JDEOWComponent;
import com.app.st.component.JDERMAComponent;
import com.app.st.component.JDESFComponent;
import com.app.st.component.JDESIComponent;
import com.app.st.component.JDESJComponent;
import com.app.st.component.JDESOComponent;
import com.app.st.component.JDESOSpeedComponent;
import com.app.st.component.JDESTComponent;
import com.app.st.component.JDEWOComponent;
import com.app.st.domain.TestSettings;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.dto.UserDto;
import com.app.st.repository.TestSettingsRepo;
import com.app.st.service.AlertService;
import com.app.st.service.RegisterTestCaseService;
import com.app.st.service.XMLUtilService;
import com.mchange.v2.cfg.PropertiesConfig;

/***
 * @author intakhabalam.s@hcl.com
 * @see Controller {@link Controller}
 * @see CrossOrigin {@link CrossOrigin}
 * @see AlertService {@link AlertService}
 * @see Environment {@link Environment}
 * @see XMLUtilService {@link XMLUtilService}
 * @see SettingsService {@link SettingsService}
 * @see CommonTestUtilService {@link CommonTestUtilService}
 * @see PropertiesConfig {@link PropertiesConfig}
 * @see RequestMapping {@link RequestMapping}
 * @see ResponseBody {@link ResponseBody}
 */
@Controller
@CrossOrigin
public class STBodyController {

	@Autowired
	private Environment env;
	@Autowired
	private JDESOComponent soComponent;
	@Autowired
	private JDESTComponent stComponent;

	@Autowired
	private JDESJComponent sjComponent;

	@Autowired
	private JDESFComponent sfComponent;

	@Autowired
	private JDESIComponent siComponent;

	@Autowired
	private JDEWOComponent woComponent;

	@Autowired
	private JDEOWComponent owComponent;

	@Autowired
	private JDERMAComponent rmaComponent;

	@Autowired
	private JDAPlanOpComponent jdaPlanOpComponent;
	
	@Autowired
	private JDESOSpeedComponent jdeSOSpeedComponent;

	@Autowired
	private AlertService alertService;
	@Autowired
	private RegisterTestCaseService registerTestCaseService;

	@Autowired
	private TestSettingsRepo testSettingsRepo;
	
	
	
	

	/***
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping("/calltestcases")
	@ResponseBody
	public ResponseDto invokeTest(HttpServletRequest req) {
		TestCaseDto tDto = registerTestCaseService.loadSettings();
		
		String index = req.getParameter("index");
		String id = req.getParameter("id");
		String untilId=req.getParameter("untilId");
		String fileName = env.getProperty("xsl.file.folder") + req.getParameter("name").concat(".xlsx");
		ResponseDto responseDto = new ResponseDto();
		responseDto.setFileName(fileName);
		responseDto.setTestRunId(Long.valueOf(id));
		responseDto.setEnvType(tDto.getEnvType());
		responseDto.setCurrentRunninTime(AppUtil.currentTime());
		responseDto.setSettingsId(tDto.getSettingsId());
		responseDto.setUntilId(untilId);
		switch (index) {
				case "SO":
					/*responseDto.setStart(true);
					TestCaseDto tr = registerTestCaseService.saveStatusTest(responseDto);
					responseDto.setRunningId(tr.getRunningId());*/
					responseDto.setTypeTest("SO");
					responseDto = soComponent.invokeSOCreate(responseDto);
					/*responseDto.setStart(false);
					registerTestCaseService.saveStatusTest(responseDto);*/
					break;
				case "ST":
					//responseDto.setStart(true);
					//TestCaseDto tr1 = registerTestCaseService.saveStatusTest(responseDto);
					//responseDto.setRunningId(tr1.getRunningId());
					responseDto.setTypeTest("ST");
					responseDto = stComponent.invokeSTCreate(responseDto);
					//responseDto.setStart(false);
					//registerTestCaseService.saveStatusTest(responseDto);
					break;
				case "SJ":
					//responseDto.setStart(true);
					//TestCaseDto tr2 = registerTestCaseService.saveStatusTest(responseDto);
					//responseDto.setRunningId(tr2.getRunningId());
					responseDto.setTypeTest("SJ");
					responseDto = sjComponent.invokeSJCreate(responseDto);
					//responseDto.setStart(false);
					//registerTestCaseService.saveStatusTest(responseDto);
		
					break;
				case "SF":
					//responseDto.setStart(true);
					//TestCaseDto tr3 = registerTestCaseService.saveStatusTest(responseDto);
					//responseDto.setRunningId(tr3.getRunningId());
					responseDto.setTypeTest("SF");
					responseDto = sfComponent.invokeSFCreate(responseDto);
					//responseDto.setStart(false);
					//registerTestCaseService.saveStatusTest(responseDto);
					break;
		
				case "SI":
					//TestCaseDto tr4 = registerTestCaseService.saveStatusTest(responseDto);
					//responseDto.setRunningId(tr4.getRunningId());
					responseDto.setTypeTest("SI");
					//responseDto.setStart(true);
					responseDto = siComponent.invokeSICreate(responseDto);
					//responseDto.setStart(false);
					//registerTestCaseService.saveStatusTest(responseDto);
					break;
				case "WO":
					//responseDto.setStart(true);
					//TestCaseDto tr5 = registerTestCaseService.saveStatusTest(responseDto);
					//responseDto.setRunningId(tr5.getRunningId());
					responseDto.setTypeTest("WO");
					responseDto = woComponent.invokeWOCreate(responseDto);
					//responseDto.setStart(false);
					//registerTestCaseService.saveStatusTest(responseDto);
					break;
				case "OW":
					//responseDto.setStart(true);
					//TestCaseDto tr6 = registerTestCaseService.saveStatusTest(responseDto);
					//responseDto.setRunningId(tr6.getRunningId());
					responseDto.setTypeTest("OW");
					responseDto = owComponent.invokeOWCreate(responseDto);
					//responseDto.setStart(false);
					//registerTestCaseService.saveStatusTest(responseDto);
					break;
				case "RMA":
					//responseDto.setStart(true);
					//TestCaseDto tr7 = registerTestCaseService.saveStatusTest(responseDto);
					//responseDto.setRunningId(tr7.getRunningId());
					responseDto.setTypeTest("RMA");
					responseDto = rmaComponent.invokeRMACreate(responseDto);
					//responseDto.setStart(false);
					//registerTestCaseService.saveStatusTest(responseDto);
					break;
		
				case "PO":
					responseDto.setStart(true);
					TestCaseDto tr8 = registerTestCaseService.saveStatusTest(responseDto);
					responseDto.setRunningId(tr8.getRunningId());
					responseDto.setTypeTest("PO");
					String orderNo = req.getParameter("orderNo");
					responseDto.setTmsOrder(orderNo);
					responseDto = jdaPlanOpComponent.invokePlanOptCreate(responseDto);
					responseDto.setStart(false);
					registerTestCaseService.saveStatusTest(responseDto);
					break;
				default:
					break;
				}
		return responseDto;
	}

	/***
	 * Test page
	 * 
	 * @param model {@link Model}
	 * @return {@link String}
	 */
	@RequestMapping("/jdetestcases")
	public String jdeTestPage(Model model) {
		List<TestCaseDto> testList = registerTestCaseService.loadTestCase("JDE");
		model.addAttribute("testList", testList);

		return "jdetestcases";
	}

	@RequestMapping("/welcome")
	public String welcome(Model model) {
		//TestCaseDto tDto = registerTestCaseService.loadSettings();
		return "welcome";
	}

	/***
	 * Status page
	 * 
	 * @param model {@link Model}
	 * @return {@link String}
	 */
	@RequestMapping("/jdeteststatus")
	public String jdeStatusPage(Map<String, Object> model) {
		List<TestCaseDto> testList = registerTestCaseService.loadStatusTestCaseByType("JDE");
		model.put("testList", testList);

		return "jdeteststatus";
	}

	/***
	 * Test page
	 * 
	 * @param model {@link Model}
	 * @return {@link String}
	 */
	@RequestMapping("/jdatestcases")
	public String jdaTestPage(Model model) {
		List<TestCaseDto> testList = registerTestCaseService.loadTestCase("JDA");
		model.addAttribute("testList", testList);

		return "jdatestcases";
	}

	/***
	 * Status page
	 * 
	 * @param model {@link Model}
	 * @return {@link String}
	 */
	@RequestMapping("/jdateststatus")
	public String jdaStatusPage(Map<String, Object> model) {
		List<TestCaseDto> testList = registerTestCaseService.loadStatusTestCaseByType("JDA");
		model.put("testList", testList);

		return "jdateststatus";
	}

	/***
	 * Status page
	 * 
	 * @param model {@link Model}
	 * @return {@link String}
	 */
	@RequestMapping("/regtestcase")
	public String regtestCase(HttpSession session, ModelMap model) {
		model.addAttribute("test", new TestCaseDto());
		return "regtestcase";
	}

	/**
	 * This will save user
	 * @param user   {@link UserDto}
	 * @param result {@link BindingResult}
	 * @param model  {@link Model}
	 * @return {@link String}
	 */

	@RequestMapping("/savetestcase")
	public String saveTestCase(@ModelAttribute("test") TestCaseDto test, BindingResult result, Model model) {
		try {
			registerTestCaseService.saveTest(test);
			model.addAttribute("msg", alertService.sucess("Test Case Information saved successfully"));
			model.addAttribute("test", test);
		} catch (Exception e) {
			return "redirect:/errorpage?msg=Test Case saving problem!!!" + e.getMessage();
		}
		return "redirect:/jdetestcases?msg=Test Case Information saved successfully!!!";
	}


	/***
	 * CronValidator
	 * @param req link {@link HttpServletRequest}
	 * @return {@link Boolean}
	 */
	@RequestMapping("/autostart")
	@ResponseBody
	public boolean autostart(HttpServletRequest req) {
		String status = req.getParameter("status");
		String id = req.getParameter("id");
		if ("true".equals(status)) {
			status = "false";
		} else if ("false".equals(status)) {
			status = "true";
		}
		registerTestCaseService.saveStatus(id, status);

		return true;
	}
	
	/***
	 * 
	 * @param req link {@link HttpServletRequest}
	 * @return
	 */
	@RequestMapping("/speedstatus")
	@ResponseBody
	public boolean speedStatus(HttpServletRequest req) {
		String id = req.getParameter("id");
		String ordrNo=req.getParameter("orderNo");
		String type=req.getParameter("type");
		if("535".equals(id)) {
		    jdeSOSpeedComponent.invoke535StatusBatch(ordrNo,type);
		}else if("560".equals(id)) {
			jdeSOSpeedComponent.invoke560StatusBatch(ordrNo,type);
		}else if("571".equals(id)) {
			jdeSOSpeedComponent.invoke571StatusBatch(ordrNo,type);
		}

		return true;
	}
	

	/***
	 * Status page
	 * 
	 * @param model {@link Model}
	 * @return {@link String}
	 */
	@RequestMapping("/settings")
	public String settings(@ModelAttribute("infoObj") TestCaseDto test,  ModelMap model) {
		
			TestCaseDto tDto = registerTestCaseService.loadSettings();
			model.addAttribute("infoObj", tDto);

		return "settings";
	}
	
	
	/***
	 * 
	 * @param test
	 * @param model
	 * @return
	 */
	@RequestMapping("/savesettings")
	public String savesettings(@ModelAttribute("infoObj") TestCaseDto test, ModelMap model) {
			TestSettings ts = new TestSettings();
			if(test.getSettingsId()!=null  && !test.getSettingsId().isEmpty()) {
			ts.setId(Long.valueOf(test.getSettingsId()));
			}
			ts.setJdaURL(test.getJdaURL());
			ts.setJdaUserName(test.getJdaUserId());
			ts.setJdaUserPass(test.getJdaUserPass());

			ts.setJdeURL(test.getJdeURL());
			ts.setJdeUserName(test.getJdeUserId());
			ts.setJdeUserPass(test.getJdeUserPass());

			ts.setBrowserType(test.getBrowserType());
			ts.setEnvType(test.getEnvType());
			ts.setStopBatch(test.getStopBatch());
			ts.setEnableMail(String.valueOf(test.getEnableMail()));
			ts.setDebugMail(String.valueOf(test.getDebugMail()));
			ts.setHost(test.getHost());
			ts.setPort(test.getPort());
			ts.setMailUserName(test.getMailUserName());
			ts.setMailPassword(test.getMailPassword());
			ts.setFromMail(test.getFromMail());
			ts.setToWhomEmail(test.getToWhomEmail());

			ts = testSettingsRepo.save(ts);
			
			model.addAttribute("msg", alertService.sucess("Information saved successfully"));

			
		return "settings";
	}
	// .jsp

}
