package com.app.st.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.domain.RegisterTestCase;
import com.app.st.domain.RunningTestCase;
import com.app.st.domain.TestSettings;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.repository.RegisterTestCaseRepo;
import com.app.st.repository.RunningTestCaseRepo;
import com.app.st.repository.TestSettingsRepo;

@Service
public class RegisterTestCaseService {
	@Autowired
	RegisterTestCaseRepo registerTestCaseRepo;

	@Autowired
	RunningTestCaseRepo runningTestCaseRepo;

	@Autowired
	TestSettingsRepo testSettingsRepo;

	/***
	 * 
	 * @param testDto
	 */
	public void saveTest(TestCaseDto testDto) {
		RegisterTestCase entity = new RegisterTestCase();
		entity.setRegDate(AppUtil.currentTime());
		entity.setTestCaseIndex(testDto.getTestCaseIndex());
		entity.setTestCaseName(testDto.getTestCaseName());
		entity.setTestFileName(testDto.getTestFileName());
		entity.setTestCaseType(testDto.getTestCaseType());
		registerTestCaseRepo.save(entity);
	}

	/***
	 * 
	 * @param rDto
	 */
	public TestCaseDto saveStatusTest(ResponseDto rDto) {
		RegisterTestCase entity = new RegisterTestCase();
		RunningTestCase childEntity = new RunningTestCase();
			childEntity.setOrderNumber(rDto.getOrderNo());
			childEntity.setLastRunningTime(rDto.getCurrentRunninTime());
			childEntity.setStauts(rDto.getCurrentStatus());
			childEntity.setRunStatus(String.valueOf(rDto.isRunStatus()));
			childEntity.setRunCount(rDto.getRunCount());
			childEntity.setOrderNumber1(rDto.getOrderNo1());
			childEntity.setAutoStart(String.valueOf(rDto.isAutoStart()));
			childEntity.setId(rDto.getRunningId());
			childEntity.setStart(String.valueOf(rDto.isStart()));
			childEntity.setEnvType(rDto.getEnvType());
			childEntity.setReasonFail(rDto.getReasonFail());//
			childEntity.setSubTestName(rDto.getSheetName());//
			childEntity.setReasonFail(rDto.getReasonFail());
			childEntity.setUntilTestRunId(rDto.getUntilId());
			childEntity.setRestorePoint(rDto.getRestorePoint());
			entity.setId(rDto.getTestRunId());
			
		childEntity.setRegisterTestCase(entity);
		RunningTestCase rt=runningTestCaseRepo.save(childEntity);

		return getDto(rt);
	}
	
	
	/**
	 * 
	 * @return
	 */
	@PostConstruct
	public TestCaseDto loadSettings() {
		Iterable<TestSettings> tsl = testSettingsRepo.findAll();
		for(TestSettings ts:tsl) {

			TestCaseDto tDto = new TestCaseDto();
			tDto.setSettingsId(String.valueOf(ts.getId()));
			tDto.setJdaURL(ts.getJdaURL());
			tDto.setJdaUserId(ts.getJdaUserName());
			tDto.setJdaUserPass(ts.getJdaUserPass());

			tDto.setJdeURL(ts.getJdeURL());
			tDto.setJdeUserId(ts.getJdeUserName());
			tDto.setJdeUserPass(ts.getJdeUserPass());

			tDto.setBrowserType(ts.getBrowserType());
			tDto.setEnvType(ts.getEnvType());
			
			tDto.setEnableMail(Boolean.valueOf(ts.getEnableMail()));
			tDto.setDebugMail(Boolean.valueOf(ts.getDebugMail()));
			tDto.setHost(ts.getHost());
			tDto.setPort(ts.getPort());
			tDto.setMailUserName(ts.getMailUserName());
			tDto.setMailPassword(ts.getMailPassword());
			tDto.setFromMail(ts.getFromMail());
			tDto.setToWhomEmail(ts.getToWhomEmail());
			
			return tDto;
		}
		
		return null;
	}
	
	

	/***
	 * 
	 * @return
	 */
	public List<TestCaseDto> loadTestCase(String type) {

		Iterable<RegisterTestCase> itbl = null;
		if("JDE".equalsIgnoreCase(type)) {
			itbl=registerTestCaseRepo.findJDERegister();
		}
		if("JDA".equalsIgnoreCase(type)) {
			itbl=registerTestCaseRepo.findJDARegister();
		}
		if("WMS".equalsIgnoreCase(type)) {
			itbl=registerTestCaseRepo.findWMSRegister();
		}
		
		List<RegisterTestCase> arrayList = StreamSupport.stream(itbl.spliterator(), false)
				.collect(Collectors.toList());

		List<TestCaseDto> list = new ArrayList<>();

		/* arrayList.forEachRemaining(list::add); */
		for (RegisterTestCase reg : arrayList) {
			TestCaseDto dt = new TestCaseDto();
			dt.setRegTestCaseId(reg.getId());
			dt.setRegDate(reg.getRegDate());
			dt.setTestCaseIndex(reg.getTestCaseIndex());
			dt.setTestCaseName(reg.getTestCaseName());
			dt.setTestFileName(reg.getTestFileName());
			
			list.add(dt);
		}

		return list;
	}
    /**
     * 
     * @param type
     * @return
     */
	public List<TestCaseDto> loadStatusTestCaseByType(String type) {
		PageRequest pa = PageRequest.of(0, 200);
		Iterable<RunningTestCase> itbl = runningTestCaseRepo.loadTestByType(type,pa);
		List<RunningTestCase> arrayList = StreamSupport.stream(itbl.spliterator(), false)
				.sorted((o2, o1) -> o1.getId().compareTo(o2.getId()))

				.collect(Collectors.toList());

		List<TestCaseDto> list = new ArrayList<>();
		for (RunningTestCase reg : arrayList) {
			TestCaseDto dt = new TestCaseDto();
			dt.setRegTestCaseId(reg.getId());
			dt.setOrderNo(reg.getOrderNumber());
			dt.setOrderNo1(reg.getOrderNumber1());
			dt.setStatus(reg.getStauts());
			dt.setTestCaseRunTime(reg.getLastRunningTime());
			dt.setRunCount(reg.getRunCount());
			dt.setRunStatus(reg.getRunStatus());
			dt.setTestCaseName(reg.getRegisterTestCase().getTestCaseName());
			dt.setEnvType(reg.getEnvType());
			//dt.setSettingsId(String.valueOf(reg.getTestSettings().getId()));
			dt.setAutoStart(reg.getAutoStart());
			dt.setStart(reg.getStart());
			dt.setSubTestName(reg.getSubTestName());
			dt.setReasonFail(reg.getReasonFail());
			dt.setUntilId(reg.getUntilTestRunId());
			dt.setRestorePoint(reg.getRestorePoint());
			list.add(dt);
		}

		return list;
	}
    /***
     * 
     * @param id
     * @param status
     */
	public void saveStatus(String id, String status) {
		RunningTestCase childEntity = runningTestCaseRepo.findById(Long.valueOf(id)).get();
		childEntity.setAutoStart(status);
		registerTestCaseRepo.save(childEntity.getRegisterTestCase());

	}
	
	/**
	 * 
	 * @param reg
	 * @return
	 */
	private TestCaseDto getDto(RunningTestCase reg) {
		
			TestCaseDto dt = new TestCaseDto();
			dt.setRegTestCaseId(reg.getId());
			dt.setOrderNo(reg.getOrderNumber());
			dt.setStatus(reg.getStauts());
			dt.setTestCaseRunTime(reg.getLastRunningTime());
			dt.setOrderNo1(reg.getOrderNumber1());
			dt.setRunCount(reg.getRunCount());
			dt.setRunStatus(reg.getRunStatus());
			dt.setTestCaseName(reg.getRegisterTestCase().getTestCaseName());
			dt.setAutoStart(reg.getAutoStart());
			dt.setEnvType(reg.getEnvType());
			dt.setRunningId(reg.getId());
			dt.setReasonFail(reg.getReasonFail());
			dt.setUntilId(reg.getUntilTestRunId());
			dt.setSubTestName(reg.getSubTestName());
		
		return dt;
		
	}
}
