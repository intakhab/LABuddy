package com.app.st.service;


import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.dto.WOExcelColumnNameDto;

/**
 * 
 * @author intakhabalam.s
 *
 */
@Service
public class JDEWOExcelReaderService {

	
	@Autowired
	Environment env;

	@Autowired
	FilePathService filePathService;
	/***
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	public List<WOExcelColumnNameDto> getExcelData(String excelFilePath)  {
		
		List<WOExcelColumnNameDto> colList = new ArrayList<>();
		Workbook wb;
		try {
			wb = AppUtil.getWorkbook(filePathService.loadFile(excelFilePath), excelFilePath);
		/*	WOExcelColumnNameDto dto = getSheetValues(wb, 0);
				colList.add(dto);	*/
			int totalNoOfSheet = wb.getNumberOfSheets();
			for (int i = 0; i < totalNoOfSheet; i++) {
				WOExcelColumnNameDto dto = getSheetValues(wb, i);
				dto.setSheetName(wb.getSheetName(i));
				colList.add(dto);	
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return colList;
	}

	/***
	 * 
	 * @return
	 * @throws URISyntaxException
	 * @throws IOException
	 */
	private WOExcelColumnNameDto getSheetValues(Workbook wb, int sheet) 
			throws URISyntaxException, IOException {

		WOExcelColumnNameDto dto = new WOExcelColumnNameDto();
		
		Sheet firstSheet = wb.getSheetAt(sheet);
		
		Iterator<Row> iterator = firstSheet.iterator();
		//
		try {
			while (iterator.hasNext()) {
				Row nextRow = iterator.next();
				int rowCount = nextRow.getRowNum();
				if (rowCount == 0) {//Header
					continue;
				}
				Iterator<Cell> cellIterator = nextRow.cellIterator();
				while (cellIterator.hasNext()) {
					Cell nextCell = cellIterator.next();
					int columnIndex = nextCell.getColumnIndex();
					switch (columnIndex) {
						/*case 0:
							   String v=(String) AppUtil.getCellValue(nextCell);
							    double d = Double.parseDouble(v);
							    BigDecimal bd = new BigDecimal(d);
							    v = bd.round(new MathContext(15)).toPlainString();
							    dto.setOrderNo(v);
							break;*/
						case 0:
							dto.setPlantId(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 1:
							dto.setItemNo(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 2:
							dto.setUomQnty(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 3:
							dto.setOmrBatch1Val(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 4:
							dto.setOmrBatch1Ver(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 5:
							dto.setOmrBatch2Val(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;
						case 6:
							dto.setOmrBatch2Ver(String.valueOf(AppUtil.getCellValue(nextCell)).split("\\.")[0]);
							break;		
					}
				}
			}
		} finally {
			if (wb != null) {
			    wb.close();
			}
		}
		return dto;
	}
	
	
}

