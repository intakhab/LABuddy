package com.app.st.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Lazy;

@Entity
@Table(name = "REG_TEST_CASE")
@Lazy(value=false)
public class RegisterTestCase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "TEST_CASE_TYPE")
	private String testCaseType="";
	
	@Column(name = "TEST_CASE_NAME")
	private String testCaseName="";
	
	@Column(name = "TEST_CASE_INDEX" ,length=10)
	private String testCaseIndex="";
	
	@Column(name = "TEST_FILE_NAME")
	private String testFileName="";
	
	@Column(name = "REG_DATE")
	private String regDate;

	
	public String getTestCaseType() {
		return testCaseType;
	}

	public void setTestCaseType(String testCaseType) {
		this.testCaseType = testCaseType;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTestCaseName() {
		return testCaseName;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	public String getTestCaseIndex() {
		return testCaseIndex;
	}

	public void setTestCaseIndex(String testCaseIndex) {
		this.testCaseIndex = testCaseIndex;
	}

	public String getTestFileName() {
		return testFileName;
	}

	public void setTestFileName(String testFileName) {
		this.testFileName = testFileName;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	
		
}
