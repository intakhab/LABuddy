package com.app.st.test;

import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.MailDto;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SOExcelColumnNameDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.service.PrepMailService;
import com.app.st.service.RegisterTestCaseService;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDESOrderTest  {
	private Logger logger = LogManager.getLogger(JDESOrderTest.class);

	private WebDriver driver;

	private String orderNo = "";
	
	
	private SOExcelColumnNameDto excelDto;
	@Autowired
	private Environment env;
	@Autowired
	private JDELoginTest commonLoginTest;
	
	@Autowired
	private JDAAutoPlanOptTest autoPlan;
	
	@Autowired
	private CommonTestUtilService commonTestUtilService;
	
	@Autowired
	private RegisterTestCaseService registerTestCaseService;
	
	@Autowired
	private PrepMailService prepMailService;
	TestCaseDto tcDto;
	@PostConstruct
	public void init() {
		tcDto=registerTestCaseService.loadSettings();
	}
	/***
	 * Test 2 SO Creation
	 */
	public ResponseDto createSO(ResponseDto responseDto) {

		
		try {
		    soCreate(responseDto);
		    responseDto.setRestorePoint("SO Created"); // SO created
			batchRun1();
			 responseDto.setRestorePoint("Batch-1 Run"); // batch1 created
			AppUtil.pauseInSecond(10);
			batchRun2();
			responseDto.setRestorePoint("Batch-2 Run"); // batch2 created 
			AppUtil.pauseInSecond(10);
			
			opRun();
			responseDto.setRestorePoint("OP Hold Run"); // op is created
			
			batchRun3();
			AppUtil.pauseInSecond(5);
			responseDto.setRestorePoint("Batch-3 Run"); // batch3 created
			
			finalReports(responseDto);
			String status=responseDto.getCurrentStatus();
			logger.info("Could not read the status thats why report will run once again{}");
			if("000".equals(status)) {
				finalReports(responseDto);
			}
			status=responseDto.getCurrentStatus();
			if("530".equals(status)) {
				responseDto.setRestorePoint("JDE Completed");
				
			}
			
				
	     }catch(NoSuchElementException e) {
		    	  responseDto.setRunStatus(false);	
		    	  responseDto.setReasonFail(e.getMessage());
				  logger.error("******************************* SO Creation Failed *********************************");
				  logger.error("Error: NoSuchElementException {} ",e.fillInStackTrace());
				  
		}catch(Exception e) {
	    	  responseDto.setRunStatus(false);			
			  logger.error("******************************* SO Creation Failed *********************************");
			  logger.error("Error: exception {} ",e.fillInStackTrace());

		
	     }
		finally {
			commonTestUtilService.quit(driver);
			try {
			
			if ("JDE-JDA".equalsIgnoreCase(responseDto.getUntilId())) {
				logger.info("STBuddy will run till JDE-JDA {}");
				// After quitting JDE, TMS Optimization will run
				if (responseDto.getCurrentStatus().equals("530")) {
					autoPlan.autoPlanOpt(responseDto);
				}
			} else {
				logger.info("STBuddy will run till JDE {}");
			}
			}finally {
				MailDto m=new MailDto(tcDto.getFromMail(), tcDto.getToWhomEmail());
				m.setMailFrom(tcDto.getFromMail());
				m.setInlineFilePath(responseDto.getCaptureScreenPath());
				prepMailService.prepareAndSendAPIsMails(responseDto,m);
			}
		}
		return responseDto;

	}
    /****
     * 
     * @param responseDto
     * @return
     */
	private ResponseDto soCreate(ResponseDto responseDto) {

		logger.info("******************************* SO XLS Loading*********************************");

		excelDto = responseDto.getSoExcelColumnNameDto();
		
		logger.info("******************************* SO XLS Loaded*********************************");
		orderNo = "";
		
		logger.info("******************************* Login SO Starting*********************************");
		driver=commonLoginTest.login();

		logger.info("******************************* Create SO Starting*********************************");
		AppUtil.pauseInSecond(1);

		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		AppUtil.pauseInSecond(1);

		commonTestUtilService.commonMenu(driver,env);
		
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.5.key"))).click();

		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.6.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.7.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
		// Switch to
		AppUtil.pauseInSecond(1);

		driver.findElement(By.xpath(env.getProperty("so.create.add.link.key"))).click();

		AppUtil.pauseInSecond(1);

		logger.info("Ship value : " + excelDto.getShipValue());

		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.ship.to.key"), excelDto.getShipValue());

		AppUtil.pauseInSecond(1);

		logger.info("PO number : " + excelDto.getCustomerPoValue());

		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.customer.po.key"), excelDto.getCustomerPoValue());

		AppUtil.pauseInSecond(1);

		logger.info("Branch id : " + excelDto.getBranchId());

		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.customer.branch.id.key"), excelDto.getBranchId());
		AppUtil.pauseInSecond(1);

		driver.findElement(By.xpath(env.getProperty("so.create.save.btn.link.key"))).click();

		AppUtil.pauseInSecond(1);

		if (commonTestUtilService.checkResultAvailableOrNot(driver,env.getProperty("so.create.save.btn.link.key"))) {
			logger.info("Clicking again ");
			driver.findElement(By.xpath(env.getProperty("so.create.save.btn.link.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		// Clicking item
		List<String> qntyList = excelDto.getOrderQty();
		List<String> itemList = excelDto.getItemNumber();
		logger.info("Putting Qnt and Item");
		logger.info("Qnt size: " + qntyList.size());
		logger.info("Item size:" + itemList.size());
		for (int i = 0; i < qntyList.size(); i++) {
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.new.order.entry.quantity.key")))
					.sendKeys(qntyList.get(i));
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.new.order.entry.item.no.key")))
					.sendKeys(itemList.get(i));
			AppUtil.pauseInSecond(1);

			driver.findElement(By.xpath(env.getProperty("so.create.new.order.entry.item.no.key")))
					.sendKeys(Keys.ENTER);
			//AppUtil.pauseInSecond(1);

		}
		AppUtil.pauseInSecond(1);
		
		js.executeScript("arguments[0].scrollIntoView();",
				driver.findElement(By.xpath(env.getProperty("so.create.order.save.close.key"))));

		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.save.close.key"))).click();

		AppUtil.pauseInSecond(1);
        // CommonTestUtil.checkError(driver, env);
        // AppUtil.pauseInSecond(1);
		if (commonTestUtilService.checkResultAvailableOrNot(driver,env.getProperty("so.create.order.save.close.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.save.close.key"))).click();
			//AppUtil.pauseInSecond(1);
		}
        AppUtil.pauseInSecond(1);

		if (commonTestUtilService.checkResultAvailableOrNot(driver,env.getProperty("so.create.order.save.close.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.save.close.key"))).click();
			//AppUtil.pauseInSecond(1);
		}
		AppUtil.pauseInSecond(1);
		
		boolean checkLoader=commonTestUtilService.checkLoader(driver);
		
		if (!checkLoader && commonTestUtilService.checkResultAvailableOrNot(driver,env.getProperty("so.create.order.no.key"))) {
			
			orderNo = (String) js.executeScript("return arguments[0].value;",
					driver.findElement(By.xpath(env.getProperty("so.create.order.no.key"))));
			if(orderNo==null || orderNo.isEmpty()) {
				orderNo = driver.findElement(By.xpath(env.getProperty("so.create.order.no.key"))).getAttribute("value");
			}
			logger.info("Order has Created  :: " + orderNo);
			responseDto.setOrderNo(orderNo);
		}else {
			logger.info(" Order has not been captured  ");
			responseDto.setOrderNo("");
			responseDto.setRunStatus(false);
			return responseDto;
		}
		AppUtil.pauseInSecond(1);
		commonTestUtilService.closeScreen(driver, env.getProperty("so.create.order.close.key"));

		logger.info("******************************* Create SO completed *********************************");
		return responseDto;
	}

	

	/**
	 * Test 3 Batch Run
	 */
	public void batchRun1() {
		AppUtil.pauseInSecond(1);
		driver.switchTo().parentFrame();
		logger.info("******************************* Step 1 starting *********************************");
		logger.info("Step 1 processing with batch application ::" + excelDto.getBatchAppSearch1());
		AppUtil.pauseInSecond(2);
		commonSteps(excelDto.getBatchAppSearch1(), "1");
		AppUtil.pauseInSecond(1);
		commonTestUtilService.closeScreen(driver, env.getProperty("so.create.order.close.key"));
		
		logger.info("******************************* Step 1 finished *********************************");
	}

	/**
	 * Test Batch Run
	 */
	public void batchRun2() {
		AppUtil.pauseInSecond(2);
		logger.info("******************************* Step 2 starting *********************************");
		driver.switchTo().parentFrame();
		//logger.info("Pause 15 Seconds for next step");
		AppUtil.pauseInSecond(5);//Let it be
		logger.info("Step 2 processing with batch application ::" + excelDto.getBatchAppSearch2());
		commonSteps(excelDto.getBatchAppSearch2(), "2");
		AppUtil.pauseInSecond(1);
		
		if (commonTestUtilService.checkResultAvailableOrNot(driver,env.getProperty("so.create.order.select.ok.key"))) {

			driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		commonTestUtilService.closeScreen(driver, env.getProperty("so.create.order.close.key"));
		logger.info("******************************* Step 2 finished *********************************");

	}

	/**
	 * Test OP Run
	 * 
	 */
	public void opRun() {

		AppUtil.pauseInSecond(1);

		logger.info("****************************** OP selection starting *****************************");
		//logger.info("Pause 1 mins for next step");
		AppUtil.pauseInSecond(2); //Let it be
		driver.switchTo().parentFrame(); // Frame repeating
		commonTestUtilService.commonMenu(driver,env);
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.8.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.9.key"))).click();
		AppUtil.pauseInSecond(1);
		// driver.switchTo().parentFrame(); //Frame repeating
		//AppUtil.pauseInSecond(2);
		driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
		AppUtil.pauseInSecond(1);
		logger.info("Putting Order no in search box :  " + orderNo);
		
		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.order.text.box.key"), orderNo);
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.lookup.order.key"))).click();
		AppUtil.pauseInSecond(2);

		driver.findElement(By.xpath(env.getProperty("so.create.order.op.check.box.key"))).click();

		String pass = driver.findElement(By.xpath(env.getProperty("so.create.order.op.text.key"))).getText();
		if (pass != null && !pass.isEmpty()) {
			logger.info("OP Pass putting :" + pass);
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.op.pass.key"))).sendKeys(pass);
			AppUtil.pauseInSecond(1);
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
		} else {
			logger.info("OP Is empty :");

		}
		// Repeat step 4 again
		AppUtil.pauseInSecond(1);
		commonTestUtilService.closeScreen(driver, env.getProperty("so.create.order.close.key"));
		logger.info("************************** OP selection finished ********************************");
	}

	/***
	 * Test 3 Batch Run
	 */
	public void batchRun3() {

		AppUtil.pauseInSecond(2);
		driver.switchTo().parentFrame();
		logger.info("******************************* Step 3 starting *********************************");
		logger.info("Pause  mins for before starting step 3");
		AppUtil.pauseInSecond(2);// Let it be
		logger.info("Step 3 processing with batch application ::" + excelDto.getBatchAppSearch3());
		commonSteps(excelDto.getBatchAppSearch3(), "3");
		AppUtil.pauseInSecond(1);
		commonTestUtilService.closeScreen(driver, env.getProperty("so.create.order.close.key"));
		
		logger.info("****************************** Step 3 completed  *********************************");
	}
	

	/***
	 * Test Status Check
	 */
	public ResponseDto finalReports(ResponseDto responseDto) {
		
		AppUtil.pauseInSecond(1);
		
		logger.info("******************************* Reports starting *****************************");
		driver.switchTo().parentFrame();
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
		AppUtil.pauseInSecond(1);
		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.order.av.link.key"), env.getProperty("so.fastpath.P4210"));
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
		AppUtil.pauseInSecond(1);
		
		logger.info("Putting value order no : " + orderNo);

		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.order.batch.application.search.textbox.key"), orderNo);
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.key"))).click();

		AppUtil.pauseInSecond(2);

		boolean isRun = false;
		String status ="000";// driver.findElement(By.xpath(env.getProperty("so.create.order.final.status.key"))).getText();
		if (commonTestUtilService.checkResultAvailableOrNot(driver,env.getProperty("so.create.order.final.status.key"))) {
			 status=driver.findElement(By.xpath(env.getProperty("so.create.order.final.status.key"))).getText();
		}
		
		logger.info("Status Value::" + status);
		AppUtil.pauseInSecond(1);

		if (status.equals("530")) {
			isRun = true;
		} else {
			isRun = false;
		}
		logger.info("Assert :: " + isRun);
		responseDto.setOrderNo(orderNo);
		responseDto.setCurrentStatus(status);
		responseDto.setRunStatus(isRun);
		//AppUtil.pauseInSecond(1);
		String tempOrder="SO"+orderNo;
		logger.info("SO order :: "+tempOrder);
		responseDto.setTmsOrder(tempOrder);
		String captureScreenPath=commonTestUtilService.saveScreen(driver, orderNo);
		responseDto.setCaptureScreenPath(captureScreenPath);
		AppUtil.pauseInSecond(1);
		logger.info("****************************** Reports completed  ******************************");
		return responseDto;
	}


	/***
	 * 
	 * @param val
	 * @param steps
	 */
	private void commonSteps(String val, String steps) {

		logger.info("Common Steps Starting for step :: " + steps);
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
		AppUtil.pauseInSecond(1);
		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.order.av.link.key"),
				env.getProperty("so.create.order.av.link.value"));
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();
		AppUtil.pauseInSecond(1);
		driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
		AppUtil.pauseInSecond(5);
		logger.info("Putting value: " + val);

		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.order.batch.application.key"), val);
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.textbox.key"))).click();
		AppUtil.pauseInSecond(2);

		String versionSearchKey = excelDto.getBatchVer1();

		if ("2".equals(steps)) {
			versionSearchKey = excelDto.getBatchVer2();
		}
		if ("3".equals(steps)) {
			versionSearchKey = excelDto.getBatchVer3();
		}
		if("4".equals(steps)) {
			versionSearchKey=excelDto.getOmrBatchVer();
		}
		logger.info("Version Search valueputting:: " + versionSearchKey);
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("so.create.order.version.serach.key"))).sendKeys(versionSearchKey);
		AppUtil.pauseInSecond(1);

		driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.textbox.key"))).click();// work
		// here//
		AppUtil.pauseInSecond(1);

		if(commonTestUtilService.checkResultAvailableOrNot(driver,env.getProperty("so.create.order.version.check.key"))){
			driver.findElement(By.xpath(env.getProperty("so.create.order.version.check.key"))).click();// work here//
		}

		AppUtil.pauseInSecond(1);
		if(commonTestUtilService.checkResultAvailableOrNot(driver,env.getProperty("so.create.order.select.key"))){
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		if(commonTestUtilService.checkResultAvailableOrNot(driver,
				env.getProperty("so.create.order.data.selection.key"))){
			driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		if(commonTestUtilService.checkResultAvailableOrNot(driver,
				env.getProperty("so.create.order.data.selection.submit.key"))){
		     driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.submit.key"))).click();
		}

		logger.info("Going for version selection:");
		AppUtil.pauseInSecond(1);

		commonTestUtilService.commonVersionSelection(driver, env,null);
		AppUtil.pauseInSecond(1);

		logger.info("Putting Order no: " + orderNo);

		commonTestUtilService.clearTextAndsendKeys(driver,env.getProperty("so.create.order.put.order.no.key"), orderNo);

		AppUtil.pauseInSecond(1);
		if(commonTestUtilService.checkResultAvailableOrNot(driver,
				env.getProperty("so.create.order.select.next.key"))){
		 driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		if(commonTestUtilService.checkResultAvailableOrNot(driver,
				env.getProperty("so.create.order.select.next.key"))){
		driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		if(commonTestUtilService.checkResultAvailableOrNot(driver,
				env.getProperty("so.create.order.select.next.key"))){
		driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		if(commonTestUtilService.checkResultAvailableOrNot(driver,
				env.getProperty("so.create.order.select.ok.key"))){
		driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
		}
		AppUtil.pauseInSecond(1);
		logger.info("Print Selection closed");
		// driver.findElement(By.xpath(prop.getProperty("so.create.order.close"))).click();
	}

	

}
