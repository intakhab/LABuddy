package com.app.st.test;

import java.nio.file.Paths;

import org.apache.commons.io.FilenameUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.service.RegisterTestCaseService;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDAAutoPlanOptTest {
	private Logger logger = LogManager.getLogger(JDAAutoPlanOptTest.class);
	@Autowired
	private RegisterTestCaseService registerTestCaseService;
	@Autowired
	private JDAPlanOpTest jdaPlanOpTest;
	@Autowired
	JDESOrderReportsTest jdesOrderReportsTest;
	public void autoPlanOpt(ResponseDto responseDto) {
		logger.info("Auto Optimization is runing for JDA TMS ");
		responseDto.setStart(true);
		TestCaseDto tr8 = registerTestCaseService.saveStatusTest(responseDto);
		responseDto.setRunningId(tr8.getRunningId());
		logger.info("Wait going to TMS for Opt ");
		logger.info("Waiting 20 sec");
		logger.info("Waiting 20 sec");
		logger.info("Waiting 20 sec");
		responseDto = jdaPlanOpTest.createPlanOpt(responseDto);
		responseDto.setStart(false);
		logger.info("Tms call finsihed");
		logger.info("File path: "+responseDto.getFileName());
		String fileName= Paths.get(responseDto.getFileName()).toFile().getName();
	    String fileBase=FilenameUtils.getBaseName(fileName);
		responseDto.setFileName(fileBase);
		logger.info("File Name: "+fileBase);
		registerTestCaseService.saveStatusTest(responseDto);
		logger.info("Going to check the status in JDEdward for 535{}");
		AppUtil.pauseInSecond(20);
		logger.info("Waiting 20 sec");
		AppUtil.pauseInSecond(20);
		logger.info("Waiting 20 sec");
		AppUtil.pauseInSecond(20);
		logger.info("Waiting 20 sec");
		AppUtil.pauseInSecond(20);
		logger.info("Waiting 20 sec");
		
		responseDto=jdesOrderReportsTest.runReports(responseDto);
		if("535".equals(responseDto.getCurrentStatus())) {
			responseDto.setRunCount("1");
		}
		if(responseDto.getTypeTest().equals("SO")) {
		     responseDto.setAutoStart(true);
		}else {
			 responseDto.setAutoStart(false);
		}
		registerTestCaseService.saveStatusTest(responseDto);
		
	}
		

}
