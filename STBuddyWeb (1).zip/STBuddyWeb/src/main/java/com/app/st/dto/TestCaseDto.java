package com.app.st.dto;
/**
 * 
 * @author ISIDDIQUI
 *
 */
public class TestCaseDto {
	private long regTestCaseId;
	private String testCaseName;
	private String testCaseIndex;
	private String testFileName;
	private String regDate;
	private String testCaseType;
	//
	private String orderNo="";
	private String orderNo1="";
	
	private String testCaseRunTime="";
	private String status="";
	private String runCount="";
	private String runStatus="";
	private String autoStart;
	
    private Long runningId;
    private String start="false";
    private String settingsId;
    
    private String jdaURL;
    private String jdaUserId;
    private String jdaUserPass;
    ////////////////
    private String jdeURL;
    private String jdeUserId;
    private String jdeUserPass;
    //
    private String browserType="chrome";
    private String envType="DEV";
  
    private String tabId;
    private String cronHit;
    private String reasonFail="";
    private String subTestName="";
    
    private String stopBatch="false";

    private String untilId="";
    private String restorePoint="";
    
    private boolean enableMail=false;
    private String toWhomEmail="";
    private String host="";
    private String port="";
    private String mailUserName="";
    private String mailPassword="";
    private String fromMail="";
    private boolean debugMail=false;
    
 
	public boolean getEnableMail() {
		return enableMail;
	}

	public void setEnableMail(boolean enableMail) {
		this.enableMail = enableMail;
	}

	public String getToWhomEmail() {
		return toWhomEmail;
	}

	public void setToWhomEmail(String toWhomEmail) {
		this.toWhomEmail = toWhomEmail;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getMailUserName() {
		return mailUserName;
	}

	public void setMailUserName(String mailUserName) {
		this.mailUserName = mailUserName;
	}

	public String getMailPassword() {
		return mailPassword;
	}

	public void setMailPassword(String mailPassword) {
		this.mailPassword = mailPassword;
	}

	public String getFromMail() {
		return fromMail;
	}

	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}

	public boolean getDebugMail() {
		return debugMail;
	}

	public void setDebugMail(boolean debugMail) {
		this.debugMail = debugMail;
	}

	public String getStopBatch() {
		return stopBatch;
	}

	public void setStopBatch(String stopBatch) {
		this.stopBatch = stopBatch;
	}

	public String getReasonFail() {
		return reasonFail;
	}

	public void setReasonFail(String reasonFail) {
		this.reasonFail = reasonFail;
	}

	public String getSubTestName() {
		return subTestName;
	}

	public void setSubTestName(String subTestName) {
		this.subTestName = subTestName;
	}

	public String getJdaURL() {
		return jdaURL;
	}

	public void setJdaURL(String jdaURL) {
		this.jdaURL = jdaURL;
	}

	public String getJdaUserId() {
		return jdaUserId;
	}

	public void setJdaUserId(String jdaUserId) {
		this.jdaUserId = jdaUserId;
	}

	public String getJdaUserPass() {
		return jdaUserPass;
	}

	public void setJdaUserPass(String jdaUserPass) {
		this.jdaUserPass = jdaUserPass;
	}

	public String getJdeURL() {
		return jdeURL;
	}

	public void setJdeURL(String jdeURL) {
		this.jdeURL = jdeURL;
	}

	public String getJdeUserId() {
		return jdeUserId;
	}

	public void setJdeUserId(String jdeUserId) {
		this.jdeUserId = jdeUserId;
	}

	public String getJdeUserPass() {
		return jdeUserPass;
	}

	public void setJdeUserPass(String jdeUserPass) {
		this.jdeUserPass = jdeUserPass;
	}

	public String getTabId() {
		return tabId;
	}

	public void setTabId(String tabId) {
		this.tabId = tabId;
	}

	public String getCronHit() {
		return cronHit;
	}

	public void setCronHit(String cronHit) {
		this.cronHit = cronHit;
	}

	public String getAutoStart() {
		return autoStart;
	}

	public void setAutoStart(String autoStart) {
		this.autoStart = autoStart;
	}


	public String getRunCount() {
		return runCount;
	}

	public void setRunCount(String runCount) {
		this.runCount = runCount;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getTestCaseRunTime() {
		return testCaseRunTime;
	}

	public void setTestCaseRunTime(String testCaseRunTime) {
		this.testCaseRunTime = testCaseRunTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getRegTestCaseId() {
		return regTestCaseId;
	}

	public void setRegTestCaseId(long regTestCaseId) {
		this.regTestCaseId = regTestCaseId;
	}

	public String getTestCaseName() {
		return testCaseName;
	}

	public void setTestCaseName(String testCaseName) {
		this.testCaseName = testCaseName;
	}

	public String getTestCaseIndex() {
		return testCaseIndex;
	}

	public void setTestCaseIndex(String testCaseIndex) {
		this.testCaseIndex = testCaseIndex;
	}

	public String getTestFileName() {
		return testFileName;
	}

	public void setTestFileName(String testFileName) {
		this.testFileName = testFileName;
	}

	public String getRegDate() {
		return regDate;
	}

	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}

	public String getRunStatus() {
		return runStatus;
	}

	public void setRunStatus(String runStatus) {
		this.runStatus = runStatus;
	}

	public String getTestCaseType() {
		return testCaseType;
	}

	public void setTestCaseType(String testCaseType) {
		this.testCaseType = testCaseType;
	}

	public Long getRunningId() {
		return runningId;
	}

	public void setRunningId(Long runningId) {
		this.runningId = runningId;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getBrowserType() {
		return browserType;
	}

	public void setBrowserType(String browserType) {
		this.browserType = browserType;
	}

	public String getSettingsId() {
		return settingsId;
	}

	public void setSettingsId(String settingsId) {
		this.settingsId = settingsId;
	}

	public String getEnvType() {
		return envType;
	}

	public void setEnvType(String envType) {
		this.envType = envType;
	}

	public String getOrderNo1() {
		return orderNo1;
	}

	public void setOrderNo1(String orderNo1) {
		this.orderNo1 = orderNo1;
	}

	public String getUntilId() {
		return untilId;
	}

	public void setUntilId(String untilId) {
		this.untilId = untilId;
	}

	public String getRestorePoint() {
		return restorePoint;
	}

	public void setRestorePoint(String restorePoint) {
		this.restorePoint = restorePoint;
	}

}

