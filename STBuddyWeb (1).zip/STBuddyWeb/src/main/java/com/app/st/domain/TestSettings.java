package com.app.st.domain;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Lazy;
/***
 * 
 * @author ISIDDIQUI
 *
 */
@javax.persistence.Entity
@Table(name = "TEST_SETTINGS")
@Lazy(value=false)
public class TestSettings {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "JDE_URL")
	private String jdeURL="";
	
	@Column(name = "JDE_USER_NAME")
	private String jdeUserName="";
	
	@Column(name = "JDE_USER_PASS")
	private String jdeUserPass="";
	
	@Column(name = "JDA_URL")
	private String jdaURL="";
	
	@Column(name = "JDA_USER_NAME")
	private String jdaUserName="";
	
	@Column(name = "JDA_USER_PASS")
	private String jdaUserPass="";
	
	@Column(name = "BROWSER_TYPE" ,length = 10)
	private String browserType="";
	
	@Column(name = "ENV_TYPE",length = 5)
	private String envType="";
	
	@Column(name = "STOP_BATCH",length = 5)
	private String stopBatch="false";
	
	@Column(name = "MAIL_ENABLE",length = 5)
	private String enableMail="false";
	
	@Column(name = "MAIL_TO" ,length = 1000)
    private String toWhomEmail="";
    
    @Column(name = "MAIL_HOST")
    private String host="";
    
    @Column(name = "MAIL_PORT")
    private String port="";
    
    @Column(name = "MAIL_USERNAME")
    private String mailUserName="";
    
    @Column(name = "MAIL_PASSWORD")
    private String mailPassword="";
    
    @Column(name = "MAIL_FROM")
    private String fromMail="";
    
    @Column(name = "DEBUG_MAIL",length = 5)
    private String debugMail="false";
	

	public String getStopBatch() {
		return stopBatch;
	}


	public void setStopBatch(String stopBatch) {
		this.stopBatch = stopBatch;
	}


	public String getEnvType() {
		return envType;
	}


	public void setEnvType(String envType) {
		this.envType = envType;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getJdeURL() {
		return jdeURL;
	}


	public void setJdeURL(String jdeURL) {
		this.jdeURL = jdeURL;
	}


	public String getJdeUserName() {
		return jdeUserName;
	}


	public void setJdeUserName(String jdeUserName) {
		this.jdeUserName = jdeUserName;
	}


	public String getJdeUserPass() {
		return jdeUserPass;
	}


	public void setJdeUserPass(String jdeUserPass) {
		this.jdeUserPass = jdeUserPass;
	}


	public String getJdaURL() {
		return jdaURL;
	}


	public void setJdaURL(String jdaURL) {
		this.jdaURL = jdaURL;
	}


	public String getJdaUserName() {
		return jdaUserName;
	}


	public void setJdaUserName(String jdaUserName) {
		this.jdaUserName = jdaUserName;
	}


	public String getJdaUserPass() {
		return jdaUserPass;
	}


	public void setJdaUserPass(String jdaUserPass) {
		this.jdaUserPass = jdaUserPass;
	}


	public String getBrowserType() {
		return browserType;
	}


	public void setBrowserType(String browserType) {
		this.browserType = browserType;
	}


	public String getEnableMail() {
		return enableMail;
	}


	public void setEnableMail(String enableMail) {
		this.enableMail = enableMail;
	}


	public String getToWhomEmail() {
		return toWhomEmail;
	}


	public void setToWhomEmail(String toWhomEmail) {
		this.toWhomEmail = toWhomEmail;
	}


	public String getHost() {
		return host;
	}


	public void setHost(String host) {
		this.host = host;
	}


	public String getPort() {
		return port;
	}


	public void setPort(String port) {
		this.port = port;
	}


	public String getMailUserName() {
		return mailUserName;
	}


	public void setMailUserName(String mailUserName) {
		this.mailUserName = mailUserName;
	}


	public String getMailPassword() {
		return mailPassword;
	}


	public void setMailPassword(String mailPassword) {
		this.mailPassword = mailPassword;
	}


	public String getFromMail() {
		return fromMail;
	}


	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}


	public String getDebugMail() {
		return debugMail;
	}


	public void setDebugMail(String debugMail) {
		this.debugMail = debugMail;
	}
	
}
