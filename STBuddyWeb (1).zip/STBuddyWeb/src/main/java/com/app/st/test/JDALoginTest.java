package com.app.st.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.dto.TestCaseDto;
import com.app.st.service.RegisterTestCaseService;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDALoginTest {
	@Autowired
	private Environment env;
	@Autowired
	private RegisterTestCaseService registerTestCaseService;
	public WebDriver login() {
		TestCaseDto tdo=registerTestCaseService.loadSettings();
		WebDriver driver = null;
		 if("chrome".equalsIgnoreCase(tdo.getBrowserType())) {
		   driver=new ChromeDriver();
		 }else if("firefox".equalsIgnoreCase(tdo.getBrowserType())) {
		   driver=new FirefoxDriver();
		 }else if("ie".equalsIgnoreCase(tdo.getBrowserType())) {
			 driver=new InternetExplorerDriver();
		 }else {
			 driver=new ChromeDriver();
		 }
		// Puts an Implicit wait, Will wait for 10 seconds before throwing exception
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.navigate().to(tdo.getJdaURL());
		driver.manage().window().maximize();
		//driver.manage().deleteAllCookies();
		driver.switchTo().frame(env.getProperty("jda.frame1.key"));
		AppUtil.pauseInSecond(1);
		driver.switchTo().frame(env.getProperty("jda.frame.result.key"));
		AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(env.getProperty("jda.user.path"))).sendKeys(tdo.getJdaUserId());
		driver.findElement(By.xpath(env.getProperty("jda.pass.path"))).sendKeys(tdo.getJdaUserPass());
		driver.findElement(By.xpath(env.getProperty("jda.login.path"))).click();
		
		return driver;
		
		
	}

}
