package com.app.st.component;

import java.time.LocalTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.app.st.common.AppUtil;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SFExcelColumnNameDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.service.JDESFExcelReaderService;
import com.app.st.service.RegisterTestCaseService;
import com.app.st.test.JDESFOrderTest;

@Component
public class JDESFComponent {
	private Logger logger = LogManager.getLogger(JDESFComponent.class);

	@Autowired
	JDESFOrderTest sfOrderCreationTest;
	@Autowired
	private JDESFExcelReaderService jdSFExcelReaderService;
	@Autowired
	private RegisterTestCaseService registerTestCaseService;
	/***
	 * Auto
	 */
	public ResponseDto invokeSFCreate(ResponseDto responseDto) {
		
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("SF Test case Starting Time [ " + LocalTime.now() + " ]");
			try {
				
				//responseDto=sfOrderCreationTest.createSF(responseDto);
				List<SFExcelColumnNameDto> edtoList=jdSFExcelReaderService.getExcelData(responseDto.getFileName());
				for(SFExcelColumnNameDto  soDto:edtoList) {
					logger.info("Sheet name:"+soDto.getSheetName());
					//
					responseDto.setRunningId(null);
					responseDto.setOrderNo("");
					responseDto.setCurrentRunninTime(AppUtil.currentTime());
					responseDto.setSheetName(soDto.getSheetName());
					responseDto.setSfExcelColumnNameDto(soDto);//Test here
					responseDto.setStart(true);
					TestCaseDto tr = registerTestCaseService.saveStatusTest(responseDto);
					responseDto.setRunningId(tr.getRunningId());
					responseDto= sfOrderCreationTest.createSF(responseDto);
					responseDto.setStart(false);
					registerTestCaseService.saveStatusTest(responseDto);
				   
				}
				
			} catch (Exception e) {
				logger.error("Error at invokeSFCreate {} ", e.getMessage());
			}
			//

		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("InvokeSFCreate Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
		return responseDto;
	}

	

}
