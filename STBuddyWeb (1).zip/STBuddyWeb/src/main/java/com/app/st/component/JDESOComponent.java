package com.app.st.component;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.app.st.common.AppUtil;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.SOExcelColumnNameDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.repository.RunningTestCaseRepo;
import com.app.st.service.JDESOExcelReaderService;
import com.app.st.service.RegisterTestCaseService;
import com.app.st.test.JDESOrderReportsTest;
import com.app.st.test.JDESOrderTest;

/***
 * @author intakhabalam.s@hcl.com
 * @see ApplicationContext {@link ApplicationContext}
 * @see Component
 * @see CommonMailService {@link CommonMailService}
 * @see Environment {@link Environment}
 */
@Component
@Scope("prototype")
public class JDESOComponent {
	private Logger logger = LogManager.getLogger(JDESOComponent.class);

	@Autowired
	private JDESOrderTest sorderCreationTest;
	
	@Autowired
	private JDESOrderReportsTest sorderReportsTest;

	@Autowired
	private RunningTestCaseRepo runningTestCaseRepo;
	
	@Autowired
	 private JDESOExcelReaderService jdSOExcelReaderService;
	
	@Autowired
	private RegisterTestCaseService registerTestCaseService;
	private TestCaseDto tcDto;
	
	@PostConstruct
	public void init() {
		tcDto=registerTestCaseService.loadSettings();
	}
	
	/***
	 * 
	 */
	/*
	private void stopBatch() {
		if(tcDto.getStopBatch()!=null && "false".equalsIgnoreCase(tcDto.getStopBatch())){
			logger.info("Batch is stopped {} for enable change in settings.");
			return;
		}
		
	}*/
	
	/*@Scheduled(fixedRateString = "${poll.535.time}", initialDelayString = "10000")
	public void invoke535StatusBatch() {
		
		stopBatch();
		
		List<RunningTestCase> arrayList=runningTestCaseRepo.findRunningTestCase530Status();
		
		System.out.println(arrayList.size());
		if(arrayList.size()==0) {
		    logger.info("Poll 535 Invoking Status List size 0");
			return;
		}
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Batch running for statuss 535 Starting Time [ " + LocalTime.now() + " ]");
		String type="";
		for(RunningTestCase rtc:arrayList) {
			
			type=rtc.getRegisterTestCase().getTestCaseIndex();// Finding so,st,si
			
			if(rtc.getAutoStart()!=null && "false".equalsIgnoreCase(rtc.getAutoStart())){
				logger.info(type+" Batch 535 Auto Start "+rtc.getAutoStart() +" for Order no "+rtc.getOrderNumber());
				continue;
			}
			
			ResponseDto responseDto=new ResponseDto();
			responseDto.setOrderNo(rtc.getOrderNumber());
			responseDto.setCurrentStatus("535");
			responseDto.setFileName(rtc.getRegisterTestCase().getTestFileName());
			responseDto.setTypeTest(type);
			sorderReportsTest.runReportInSingleLogin(responseDto);
			
			logger.info("Status :: "+responseDto.getCurrentStatus());
			if(responseDto.getCurrentStatus().equals("535")) {
				rtc.setStauts(responseDto.getCurrentStatus());
				rtc.setRunCount("1");
				rtc.setLastRunningTime(AppUtil.currentTime());
				runningTestCaseRepo.save(rtc);
			}
		}
		
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info(type+" Batch 535 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
		
	}
	
	*//***
	 *//*
	@Scheduled(fixedRateString = "${poll.560.time}", initialDelayString = "30000")
	public void invoke560StatusBatch() {
		stopBatch();
		List<RunningTestCase> arrayList =runningTestCaseRepo.findRunningTestCase560Status();
		if(arrayList.size()==0) {
		    logger.info("Poll 560 Invoking Status List size 0");
			return;
		}
		
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Batch running for status 560 Starting Time [ " + LocalTime.now() + " ]");

        String type="";
		for (RunningTestCase rtc : arrayList) {
			
			type = rtc.getRegisterTestCase().getTestCaseIndex();// Finding so,st,si
			
			if (rtc.getAutoStart() != null && "false".equalsIgnoreCase(rtc.getAutoStart())) {
				logger.info(
						type + " Batch 560 Auto Start " + rtc.getAutoStart() + " for Order no " + rtc.getOrderNumber());
				continue;
			}

			ResponseDto responseDto = new ResponseDto();
			responseDto.setOrderNo(rtc.getOrderNumber());
			responseDto.setFileName(rtc.getRegisterTestCase().getTestFileName());
			responseDto.setCurrentStatus("560");//// OMR will run as status is 560
			responseDto.setTypeTest(type);
			sorderReportsTest.runReportInSingleLogin(responseDto);
			logger.info("Status :: " + responseDto.getCurrentStatus());
			logger.info("It will run only one time for 560 :: " + responseDto.isRunStatus());
			
			if (responseDto.getCurrentStatus().equals("560")) {
				rtc.setStauts(responseDto.getCurrentStatus());
				rtc.setRunCount("2");
				rtc.setLastRunningTime(AppUtil.currentTime());
				rtc.setAutoStart(""+false);
				runningTestCaseRepo.save(rtc);
			}
			runningTestCaseRepo.save(rtc);
		}	
		
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info(type+" Batch 560 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
		
	}

	*//***
	 * 
	 *//*
	@Scheduled(fixedRateString = "${poll.571.time}", initialDelayString = "30000")
	public void invoke571StatusBatch() {
		stopBatch();
		List<RunningTestCase> arrayList =runningTestCaseRepo.findRunningTestCase571Status();
		
		if(arrayList.size()==0) {
		    logger.info("Poll 571 Invoking Status List size 0");
			return;
		}
		
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Batch running for status 571 Starting Time [ " + LocalTime.now() + " ]");
         String type="";
		for(RunningTestCase rtc:arrayList) {
			type=rtc.getRegisterTestCase().getTestCaseIndex();// Finding so,st,si
			if(rtc.getAutoStart()!=null && "false".equalsIgnoreCase(rtc.getAutoStart())){
				logger.info(type+" Batch 571 Auto Start "+rtc.getAutoStart() +" for Order no "+rtc.getOrderNumber());
				continue;
			}
			
		    ResponseDto responseDto=new ResponseDto();
			responseDto.setOrderNo(rtc.getOrderNumber());
			responseDto.setCurrentStatus("571"); 
			responseDto.setFileName(rtc.getRegisterTestCase().getTestFileName());
			responseDto.setRunReport(true);
			responseDto.setTypeTest(type);
			sorderReportsTest.runReportInSingleLogin(responseDto);
			logger.info("Status :: "+responseDto.getCurrentStatus());
			logger.info("It will run only one time for 571:: "+responseDto.isRunStatus());
			//if(responseDto.getCurrentStatus().equals("571") || responseDto.isRunStatus()) {
				rtc.setStauts(responseDto.getCurrentStatus());
				rtc.setRunCount("3");
				rtc.setAutoStart("false");
				rtc.setLastRunningTime(AppUtil.currentTime());
				runningTestCaseRepo.save(rtc);
		//	}
		
		}
		
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info(type+" Batch 571 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
	}*/


	/***
	 * Auto
	 */
	public ResponseDto invokeSOCreate(ResponseDto responseDto) {
		
	
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("SO Test case Starting Time [ " + LocalTime.now() + " ]");
		List<ResponseDto> mailList=new ArrayList<>(0);
			try {
				List<SOExcelColumnNameDto> edtoList=jdSOExcelReaderService.getExcelData(responseDto.getFileName());
				for(SOExcelColumnNameDto  soDto:edtoList) {
					logger.info("Sheet name:"+soDto.getSheetName());
					//
					responseDto.setRunningId(null);
					responseDto.setOrderNo("");
					responseDto.setCurrentRunninTime(AppUtil.currentTime());
					responseDto.setSheetName(soDto.getSheetName());
					//
					responseDto.setSoExcelColumnNameDto(soDto);//Test here
					responseDto.setStart(true);
					TestCaseDto tr = registerTestCaseService.saveStatusTest(responseDto);
					responseDto.setRunningId(tr.getRunningId());
					responseDto= sorderCreationTest.createSO(responseDto);
					responseDto.setStart(false);
					registerTestCaseService.saveStatusTest(responseDto);
					mailList.add(responseDto);
				}
				
			} catch (Exception e) {
				logger.error("Error at invokeSOCreate {} ", e.getMessage());
			}
			//

		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("InvokeSOCreate Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
		return responseDto;
	}

	

}
