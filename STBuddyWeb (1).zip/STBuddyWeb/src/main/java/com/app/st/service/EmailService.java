package com.app.st.service;

import java.io.UnsupportedEncodingException;
import java.nio.file.Paths;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.app.st.dto.MailDto;
import com.app.st.dto.TestCaseDto;
/***
 * 
 * @author intakhabalam.s@hcl.com
 * Common Mail Service use this class for mail sending  
 * @see Service
 * @see DataLoaderComponent  {@link DataLoaderComponent}
 */
@Service
public class EmailService {

	private final Logger logger = LogManager.getLogger(this.getClass());
	//private JavaMailSender mailSender;
	public final String GREET_MSG = "HCL STBuddy";
	
	@Autowired
	private RegisterTestCaseService registerTestCaseService;
	TestCaseDto tcDto;
	@PostConstruct
	public void init() {
		tcDto=registerTestCaseService.loadSettings();
	}

	@PostConstruct
	public JavaMailSender getJavaMailSender() {
		
		JavaMailSenderImpl  mailSender = new JavaMailSenderImpl();
          
			mailSender.setHost(tcDto.getHost());
			mailSender.setPort(Integer.valueOf(tcDto.getPort()));
			mailSender.setUsername(tcDto.getMailUserName());
			mailSender.setPassword(tcDto.getMailPassword());
			Properties props = mailSender.getJavaMailProperties();
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.auth", "false");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.debug", tcDto.getDebugMail());

		return mailSender;
	}
    /**
     * 
     * @param eParams {@link MailDto}
     */
	public void send(MailDto eParams) {

		if (eParams.isHtml()) {
			try {
				sendHtmlMail(eParams);
			} catch (MessagingException e) {
				logger.error("Could not send email to : {} Error1 = {}", eParams.getToAsList(), e.getMessage());
			} catch (UnsupportedEncodingException e) {
				logger.error("Could not send email to : {} Error2 = {}", eParams.getToAsList(), e.getMessage());

			}
		} else {
			sendPlainTextMail(eParams);
		}

	}
    /****
     */
	private void sendHtmlMail(MailDto eParams) throws MessagingException, UnsupportedEncodingException {

		boolean isHtml = true;

		MimeMessage message = getJavaMailSender().createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		helper.setTo(eParams.getTo().toArray(new String[eParams.getTo().size()]));
		helper.setReplyTo(eParams.getFrom());
		helper.setPriority(1);
		helper.setFrom(eParams.getFrom(),GREET_MSG);
		helper.setSubject(eParams.getSubject());

		helper.setText(eParams.getMessage(), isHtml);
		
		if(!eParams.getInlineFilePath().isEmpty()) {
           helper.addInline("screenShotImage", Paths.get(eParams.getInlineFilePath()).toFile());
		}

		if (eParams.getCc().size() > 0) {
			helper.setCc(eParams.getCc().toArray(new String[eParams.getCc().size()]));
		}
		if (eParams.getFileURL() != null && eParams.getFileURL().exists()) {
			helper.addAttachment(eParams.getFileURL().getName(), eParams.getFileURL());
		}
		getJavaMailSender().send(message);
	}

	
	/***
	 * 
	 * @param eParams
	 */
	private void sendPlainTextMail(MailDto eParams) {

		SimpleMailMessage mailMessage = new SimpleMailMessage();

		eParams.getTo().toArray(new String[eParams.getTo().size()]);
		mailMessage.setTo(eParams.getTo().toArray(new String[eParams.getTo().size()]));
		mailMessage.setReplyTo(eParams.getFrom());
		mailMessage.setFrom(eParams.getFrom());
		mailMessage.setSubject(eParams.getSubject());
		mailMessage.setText(eParams.getMessage());

		if (eParams.getCc().size() > 0) {
			mailMessage.setCc(eParams.getCc().toArray(new String[eParams.getCc().size()]));
		}

		getJavaMailSender().send(mailMessage);

	}
	
	

}
