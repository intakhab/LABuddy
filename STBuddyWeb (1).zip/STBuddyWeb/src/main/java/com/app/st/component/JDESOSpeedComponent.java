package com.app.st.component;

import java.time.LocalTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.app.st.common.AppUtil;
import com.app.st.domain.RunningTestCase;
import com.app.st.dto.ResponseDto;
import com.app.st.repository.RunningTestCaseRepo;
import com.app.st.test.JDESOrderReportsTest;

/***
 * @author intakhabalam.s@hcl.com
 * @see ApplicationContext {@link ApplicationContext}
 * @see Component
 * @see CommonMailService {@link CommonMailService}
 * @see Environment {@link Environment}
 */
@Component
public class JDESOSpeedComponent {
	private Logger logger = LogManager.getLogger(JDESOSpeedComponent.class);

	@Autowired
	JDESOrderReportsTest sorderReportsTest;

	@Autowired
	private RunningTestCaseRepo runningTestCaseRepo;
	
	
	/***
	 * 
	 * 
	 *  String status=commonReportTest.commonReports(driver, env, responseDto.getOrderNo(),"");
			if (status.equals(responseDto.getCurrentStatus())) {
				isRun = true;
			} else {
				isRun = false;
			}
	 */
	
	public void invoke535StatusBatch(String orderNo,String typeTest) {
		
		List<RunningTestCase> arrayList=runningTestCaseRepo.findRunningTestCaseStatus("530","0",orderNo);
		
		if(arrayList.size()==0) {
		    logger.info("Speed 535 Invoking Status List size 0");
			return;
		}
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Speed Batch running for statuss 535 Starting Time [ " + LocalTime.now() + " ]");
		
		for(RunningTestCase rtc:arrayList) {
			if(orderNo.equals(rtc.getOrderNumber())) {
			ResponseDto responseDto=new ResponseDto();
			responseDto.setOrderNo(rtc.getOrderNumber());
			responseDto.setCurrentStatus("535");
			responseDto.setFileName(rtc.getRegisterTestCase().getTestFileName());
			responseDto.setTypeTest(typeTest);
			responseDto=sorderReportsTest.runReports(responseDto);
			logger.info("Status :: "+responseDto.getCurrentStatus());
			if(responseDto.getCurrentStatus().equals("535")) {
				rtc.setStauts(responseDto.getCurrentStatus());
				rtc.setRunCount("1");
				rtc.setLastRunningTime(AppUtil.currentTime());
				runningTestCaseRepo.save(rtc);
			}
		}
		}
		
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("Speed Batch 535 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
		
	}
	
	/***
	 */
	public void invoke560StatusBatch(String orderNo,String typeTest) {

		List<RunningTestCase> arrayList=runningTestCaseRepo.findRunningTestCaseStatus("535","1",orderNo);
		if(arrayList.size()==0) {
		    logger.info("Speed 560 Invoking Status List size 0");
			return;
		}
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Speed Batch running for status 560 Starting Time [ " + LocalTime.now() + " ]");


		for(RunningTestCase rtc:arrayList) {
			
			if(orderNo.equals(rtc.getOrderNumber())) {
				ResponseDto responseDto=new ResponseDto();
				responseDto.setOrderNo(rtc.getOrderNumber());
				responseDto.setFileName(rtc.getRegisterTestCase().getTestFileName());
				responseDto.setCurrentStatus("560");////OMR will run as status is 560
				responseDto.setTypeTest(typeTest);
				// OMR will run if status reach to 560 
				responseDto=sorderReportsTest.runReports(responseDto);
				
				logger.info("Status :: "+responseDto.getCurrentStatus());
	
				if(responseDto.getCurrentStatus().equals("560")) {
					rtc.setStauts(responseDto.getCurrentStatus());
					rtc.setRunCount("2");
					rtc.setLastRunningTime(AppUtil.currentTime());
					runningTestCaseRepo.save(rtc);
				}
			}
		}
		
		
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("Speed Batch 560 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
		
	}

	/***
	 * 
	 */
	public void invoke571StatusBatch(String orderNo,String typeTest) {
		
		//List<RunningTestCase> arrayList =runningTestCaseRepo.findRunningTestCase571Status();
		List<RunningTestCase> arrayList=runningTestCaseRepo.findRunningTestCaseStatus("560","2",orderNo);
		if(arrayList.size()==0) {
		    logger.info("Speed 571 Invoking Status List size 0");
			return;
		}
		
		final long startTime = System.currentTimeMillis();
		logger.info("=======================================================================");
		logger.info("Speed Batch running for status 571 Starting Time [ " + LocalTime.now() + " ]");
		

		for(RunningTestCase rtc:arrayList) {
			if(orderNo.equals(rtc.getOrderNumber())) {
				ResponseDto responseDto = new ResponseDto();
				responseDto.setOrderNo(rtc.getOrderNumber());
				responseDto.setTypeTest(typeTest);
				responseDto.setCurrentStatus("560");//// OMR will run as status is 560
				responseDto.setFileName(rtc.getRegisterTestCase().getTestFileName());
				responseDto.setRunReport(true);
				responseDto = sorderReportsTest.runReports(responseDto);

				logger.info("Status :: " + responseDto.getCurrentStatus());

				if (responseDto.getCurrentStatus().equals("571")) {
					rtc.setStauts(responseDto.getCurrentStatus());
					rtc.setRunCount("3");
					rtc.setLastRunningTime(AppUtil.currentTime());
					runningTestCaseRepo.save(rtc);
				}
			}
		}
		
		
		final long endTime = System.currentTimeMillis();
		final double totalTimeTaken = (endTime - startTime) / (double) 1000;
		logger.info("Speed Batch 571 Finishing Time [ " + LocalTime.now() + " ] => Total time taken to be completed  [ "
				+ totalTimeTaken + "s ]");
	}

}
