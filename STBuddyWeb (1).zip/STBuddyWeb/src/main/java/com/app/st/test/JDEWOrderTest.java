package com.app.st.test;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.app.st.common.AppUtil;
import com.app.st.common.CommonTestUtilService;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.WOExcelColumnNameDto;
import com.google.common.annotations.VisibleForTesting;

@Service
@VisibleForTesting
public class JDEWOrderTest {

	private Logger logger = LogManager.getLogger(JDEWOrderTest.class);
	private SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
	@Autowired
	private CommonTestUtilService commonTestUtilService;
	private WebDriver driver;
	
	private  WOExcelColumnNameDto woOrderDto;
	@Autowired
	private Environment env;
	
	@Autowired
	private JDELoginTest commonLoginTest;
   
	/***
	 * Test 2 SO Creation
	 */
	private String getNextMonthDate() {
		Calendar cal = Calendar.getInstance(); 
		cal.add(Calendar.MONTH, 1);

		return format .format(cal.getTime());

	}

	public ResponseDto createWO(ResponseDto responseDto) {

		try {
			logger.info("******************************* Login WO Starting*********************************");
			//woOrderDto = excelReaderService.getExcelData(responseDto.getFileName()).get(0);
			woOrderDto = responseDto.getWoExcelColumnNameDto();
			
			driver = commonLoginTest.login();

			logger.info("******************************* Create WO Starting*********************************");

			AppUtil.pauseInSecond(2);

			driver.switchTo().parentFrame();

			AppUtil.pauseInSecond(2);

			driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
			AppUtil.pauseInSecond(2);

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.av.link.key"),
					env.getProperty("so.fastpath.P48013"));
			AppUtil.pauseInSecond(2);

			driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();
			AppUtil.pauseInSecond(2);

			driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
			AppUtil.pauseInSecond(2);

			driver.findElement(By.xpath(env.getProperty("so.create.add.link.key"))).click();

			AppUtil.pauseInSecond(10);

			//logger.info("Putting value order no : " + woOrderDto.getOrderNo());

			/*CommonTestUtil.clearTextAndsendKeys(driver, env.getProperty("wo.create.order.no.key"),
					woOrderDto.getOrderNo());*/
			AppUtil.pauseInSecond(2);

			logger.info("Putting plant val : " + woOrderDto.getPlantId());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("wo.create.branch.plantid.key"),
					woOrderDto.getPlantId());
			AppUtil.pauseInSecond(2);

			logger.info("Putting Item val : " + woOrderDto.getItemNo());

			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("wo.create.item.no.key"),
					woOrderDto.getItemNo());
			AppUtil.pauseInSecond(2);

			driver.findElement(By.xpath(env.getProperty("wo.create.current.date.key"))).sendKeys(getNextMonthDate());

			AppUtil.pauseInSecond(2);

			driver.findElement(By.xpath(env.getProperty("wo.create.order.uom.key"))).sendKeys(woOrderDto.getUomQnty());

			AppUtil.pauseInSecond(2);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
			}
		
			AppUtil.pauseInSecond(2);
			
			String previousOrder = "";
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("wo.create.previous.order.key"))) {
				previousOrder = driver.findElement(By.xpath(env.getProperty("wo.create.previous.order.key")))
						.getAttribute("value");
			}
			
			if (previousOrder.isEmpty() && commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
			}
			AppUtil.pauseInSecond(2);
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("wo.create.previous.order.key"))) {
				previousOrder = driver.findElement(By.xpath(env.getProperty("wo.create.previous.order.key")))
						.getAttribute("value");
			}
			AppUtil.pauseInSecond(2);
			if (previousOrder.isEmpty() && commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
				driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
			}
			AppUtil.pauseInSecond(2);
			
			if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("wo.create.previous.order.key"))) {
				previousOrder = driver.findElement(By.xpath(env.getProperty("wo.create.previous.order.key")))
						.getAttribute("value");
			}
			AppUtil.pauseInSecond(5);
			// INPUT[@id='C0_156']
			String status = checkStatus(previousOrder, "10");
			boolean isRun = false;
			if ("10".equals(status)) {
				isRun = true;
			} else {
				isRun = false;
			}
			AppUtil.pauseInSecond(5);
			// RunOMR here
			if (isRun) {
				omrSection(woOrderDto.getOmrBatch1Val(), woOrderDto.getOmrBatch1Ver(), previousOrder, "10");
			}
			AppUtil.pauseInSecond(5);
			status = checkStatus(previousOrder, "20");
			if ("20".equals(status)) {
				isRun = true;
			} else {
				isRun = false;
			}
			AppUtil.pauseInSecond(5);
			// RunOMR here
			if (isRun) {
				omrSection(woOrderDto.getOmrBatch2Val(), woOrderDto.getOmrBatch2Ver(), previousOrder, "20");
			}
			AppUtil.pauseInSecond(5);
			status = checkStatus(previousOrder, "30");
			if ("30".equals(status)) {
				isRun = true;
			} else {
				isRun = false;
			}
			AppUtil.pauseInSecond(5);
			logger.info("Assert :" + isRun);
			logger.info("Staus : " + status);
			responseDto.setCurrentStatus(status);
			responseDto.setOrderNo(previousOrder);
			responseDto.setRunStatus(isRun);

			AppUtil.pauseInSecond(5);

		} catch (NoSuchElementException e) {
			responseDto.setRunStatus(false);
			responseDto.setReasonFail(e.getMessage());
			logger.error("******************************* WO Creation Failed *********************************");
			logger.error("Error {} ", e.getMessage());

		} finally {
			commonTestUtilService.quit(driver);
		}
		return responseDto;

	}

	/***
	 * 
	 * @param previousOrder
	 * @param status
	 * @return
	 */
	public String checkStatus(String previousOrder, String status) {
		driver.switchTo().parentFrame();
		AppUtil.pauseInSecond(2);

		driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();

		AppUtil.pauseInSecond(2);
		commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.av.link.key"), 
				env.getProperty("so.fastpath.P48013"));
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();
		AppUtil.pauseInSecond(2);
		driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
		AppUtil.pauseInSecond(2);

		commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("wo.create.previous.order.search.key"),
				previousOrder);
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.lookup.order.key"))).click();
		AppUtil.pauseInSecond(2);

		WebElement element = driver.findElement(By.id("jdeGridBack0_1"));

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft += 800", element);

		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("wo.create.status.search.key"))) {
			commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("wo.create.status.search.key"), status);
		}

		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.lookup.order.key"))).click();

		AppUtil.pauseInSecond(2);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollLeft -= 800", element);

		AppUtil.pauseInSecond(2);
		String orderNo = "";
		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("wo.create.order.search2.key"))) {
			orderNo = driver.findElement(By.xpath(env.getProperty("wo.create.order.search2.key"))).getText();
			if (orderNo != "" && !orderNo.isEmpty()) {
				return status;
			} else {
				return "";
			}
		}
		return "";
	}

	/***
	 * 
	 * @param driver
	 * @param env
	 * @param type
	 */
	public void omrSection(String searchVal, String versionSearchKey, String orderNo, String staus) {

		driver.switchTo().parentFrame();

		AppUtil.pauseInSecond(2);

		driver.findElement(By.xpath(env.getProperty("so.create.url.link.1.key"))).click();
		AppUtil.pauseInSecond(5);
		commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.av.link.key"),
				env.getProperty("so.create.order.av.link.value"));
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.av.click.key"))).click();
		AppUtil.pauseInSecond(2);
		driver.switchTo().frame(driver.findElement(By.id(env.getProperty("so.create.iframe1.key"))));
		AppUtil.pauseInSecond(2);
		logger.info("Putting value: " + searchVal);

		commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.batch.application.key"),
				searchVal);
		AppUtil.pauseInSecond(5);

		driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.textbox.key"))).click();
		AppUtil.pauseInSecond(5);

		// String versionSearchKey = serachBatchVal;

		logger.info("Version Search value putting:: " + versionSearchKey);
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.version.serach.key"))).sendKeys(versionSearchKey);
		AppUtil.pauseInSecond(2);

		driver.findElement(By.xpath(env.getProperty("so.create.order.batch.application.search.textbox.key"))).click();// work
		// here//
		AppUtil.pauseInSecond(2);

		driver.findElement(By.xpath(env.getProperty("so.create.order.version.check.key"))).click();// work here//

		AppUtil.pauseInSecond(2);

		driver.findElement(By.xpath(env.getProperty("so.create.order.select.key"))).click();
		AppUtil.pauseInSecond(2);

		driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.key"))).click();
		AppUtil.pauseInSecond(2);
		driver.findElement(By.xpath(env.getProperty("so.create.order.data.selection.submit.key"))).click();

		logger.info("Going for version selection:");
		AppUtil.pauseInSecond(2);
		commonTestUtilService.deleteCheckBox(driver, env);

		String leftKey = env.getProperty("wo.create.order.left.drop.down.key");
		if ("20".equals(staus)) {
			leftKey = env.getProperty("wo.create.order.left.drop.down2.key");
		}
		driver.findElement(By.xpath(leftKey)).click();

		Select select = new Select(driver.findElement(By.xpath(leftKey)));

		// AppUtil.pauseInSecond(1);
		String dropDownVal = env.getProperty("wo.create.order.left.drop.down.value");

		logger.info("Selecting value: " + dropDownVal);

		select.selectByVisibleText(dropDownVal);

		String comparisonKey = env.getProperty("wo.create.order.comparison.drop.down.key");

		if ("20".equals(staus)) {
			comparisonKey = env.getProperty("wo.create.order.comparison.drop.down2.key");
		}
		// AppUtil.pauseInSecond(1);
		driver.findElement(By.xpath(comparisonKey)).click();

		String comparisonDownVal = env.getProperty("so.create.order.comparison.drop.down.value");
		logger.info("Selecting value: " + comparisonDownVal);
		// AppUtil.pauseInSecond(1);
		Select select3 = new Select(driver.findElement(By.xpath(comparisonKey)));

		select3.selectByVisibleText(comparisonDownVal);

		// AppUtil.pauseInSecond(1);
		String rightKey = env.getProperty("wo.create.order.right.drop.down.key");
		if ("20".equals(staus)) {
			rightKey = env.getProperty("wo.create.order.right.drop.down2.key");
		}
		driver.findElement(By.xpath(rightKey)).click();

		// AppUtil.pauseInSecond(1);
		Select select2 = new Select(driver.findElement(By.xpath(rightKey)));

		// AppUtil.pauseInSecond(1);
		String rightVal = env.getProperty("so.create.order.right.drop.down.value");
		logger.info("Selecting value: " + rightVal);

		select2.selectByVisibleText(rightVal);

		AppUtil.pauseInSecond(2);

		logger.info("Putting Order no: " + orderNo);

		commonTestUtilService.clearTextAndsendKeys(driver, env.getProperty("so.create.order.put.order.no.key"), orderNo);

		AppUtil.pauseInSecond(2);

		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}

		AppUtil.pauseInSecond(2);

		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}

		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.next.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.next.key"))).click();
		}

		if (commonTestUtilService.checkResultAvailableOrNot(driver, env.getProperty("so.create.order.select.ok.key"))) {
			driver.findElement(By.xpath(env.getProperty("so.create.order.select.ok.key"))).click();
		}

		AppUtil.pauseInSecond(5);
	}

	public void quit() {
		driver.close();
		driver.quit();
	}

}
