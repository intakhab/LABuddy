/*package com.app.st;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.env.Environment;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.Test;

import com.app.st.common.AppUtil;
import com.app.st.component.JDAPlanOpComponent;
import com.app.st.component.JDEOWComponent;
import com.app.st.component.JDERMAComponent;
import com.app.st.component.JDESFComponent;
import com.app.st.component.JDESIComponent;
import com.app.st.component.JDESJComponent;
import com.app.st.component.JDESOComponent;
import com.app.st.component.JDESOSpeedComponent;
import com.app.st.component.JDESTComponent;
import com.app.st.component.JDEWOComponent;
import com.app.st.dto.ResponseDto;
import com.app.st.dto.TestCaseDto;
import com.app.st.repository.TestSettingsRepo;
import com.app.st.service.AlertService;
import com.app.st.service.RegisterTestCaseService;
@SpringBootApplication
@ContextConfiguration(classes = { StBuddy2Application.class })
@ComponentScan(basePackages = "com.app")

public class STBuddyTest  extends AbstractTestNGSpringContextTests {

    @Autowired
	Environment env;
	
	@Autowired
	JDESOComponent soComponent;
	@Autowired
	JDESTComponent stComponent;

	@Autowired
	JDESJComponent sjComponent;

	@Autowired
	JDESFComponent sfComponent;

	@Autowired
	JDESIComponent siComponent;

	@Autowired
	JDEWOComponent woComponent;

	@Autowired
	JDEOWComponent owComponent;

	@Autowired
	JDERMAComponent rmaComponent;

	@Autowired
	JDAPlanOpComponent jdaPlanOpComponent;
	
	@Autowired
	JDESOSpeedComponent jdeSOSpeedComponent;

	@Autowired
	AlertService alertService;
	@Autowired
	RegisterTestCaseService registerTestCaseService;

	@Autowired
	TestSettingsRepo testSettingsRepo;

	@BeforeClass
	public void beforeClass() {

	}

	@BeforeTest
	public void init() {
		
	}
	

	
	*//***
	 * Test 2  SO Creation
	 *//*
	@Test
	public void createSO() {
		ResponseDto responseDto=invokeSOCreate("1","SO","SOTestCase");
		
	}

	
	private ResponseDto invokeSOCreate(String id,String index,String fn) {
		//String index = req.getParameter("index");
		//String id = req.getParameter("id");
		String fileName = env.getProperty("xsl.file.folder") + fn.concat(".xlsx");
		ResponseDto responseDto = new ResponseDto();
		responseDto.setFileName(fileName);
		responseDto.setTestRunId(Long.valueOf(id));
		responseDto.setCurrentRunninTime(AppUtil.currentTime());
		switch (index) {
		case "SO":
			responseDto.setStart(true);
			TestCaseDto tr = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr.getRunningId());
			responseDto = soComponent.invokeSOCreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);
			break;
		case "ST":
			responseDto.setStart(true);
			TestCaseDto tr1 = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr1.getRunningId());
			responseDto = stComponent.invokeSTCreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);
			break;
		case "SJ":
			responseDto.setStart(true);
			TestCaseDto tr2 = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr2.getRunningId());
			responseDto = sjComponent.invokeSJCreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);

			break;
		case "SF":
			responseDto.setStart(true);
			TestCaseDto tr3 = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr3.getRunningId());
			responseDto = sfComponent.invokeSFCreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);
			break;

		case "SI":
			TestCaseDto tr4 = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr4.getRunningId());
			responseDto.setStart(true);
			responseDto = siComponent.invokeSICreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);
			break;
		case "WO":
			responseDto.setStart(true);
			TestCaseDto tr5 = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr5.getRunningId());
			responseDto = woComponent.invokeWOCreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);
			break;
		case "OW":
			responseDto.setStart(true);
			TestCaseDto tr6 = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr6.getRunningId());
			responseDto = owComponent.invokeOWCreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);
			break;
		case "RMA":
			responseDto.setStart(true);
			TestCaseDto tr7 = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr7.getRunningId());
			responseDto = rmaComponent.invokeRMACreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);
			break;

		case "PO":
			responseDto.setStart(true);
			TestCaseDto tr8 = registerTestCaseService.saveStatusTest(responseDto);
			responseDto.setRunningId(tr8.getRunningId());
			//String orderNo = req.getParameter("orderNo");
			responseDto.setOrderNo(orderNo);
			responseDto = jdaPlanOpComponent.invokePlanOptCreate(responseDto);
			responseDto.setStart(false);
			registerTestCaseService.saveStatusTest(responseDto);
			break;
		default:
			break;
		}
		return responseDto;
	}
	
}
*/